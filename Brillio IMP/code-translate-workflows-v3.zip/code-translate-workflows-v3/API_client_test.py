import pandas as pd
import sempy.fabric as fabric

#Instantiate the client
client = fabric.FabricRestClient()

print(f"DEBUG: {client}")
import sqlite3

# Connect to the DB (creates it if doesn't exist)
conn = sqlite3.connect("your_sqlite.db")
cursor = conn.cursor()

# Create table if not exists (with 'date' column as TEXT)
# TEXT is the recommended storage class for dates in YYYY-MM-DD format in SQLite
cursor.execute("""
CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    milestone TEXT,
    amount REAL,
    date TEXT 
)
""")

# Sample data to insert (dates as TEXT in YYYY-MM-DD format)
payment_records = [
    ("Initial Setup", 10000.00, "2024-01-15"),
    ("Phase 1 Delivery", 25000.00, "2024-03-01"),
    ("Phase 2 Delivery", 30000.00, "2024-06-15"),
    ("Final Handover", 15000.00, "2024-09-30")
]

# Insert into table (using 'date' column)
cursor.executemany("""
INSERT INTO payments (milestone, amount, date)
VALUES (?, ?, ?)
""", payment_records)

conn.commit()
conn.close()

print("✅ Inserted payment records into 'payments' table (with 'date' column as TEXT).")
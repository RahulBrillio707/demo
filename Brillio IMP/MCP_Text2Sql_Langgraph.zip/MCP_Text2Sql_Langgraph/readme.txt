first step:

pip install -r requirements.txt


Second step:

strating the mcp serve

python mcp-serve.py


thrid step:

check whether server is woking or not


python mcp-check.py



So till now we have installed and started the server and conencted to server

now lets initiat the langgraph client 

python client_langrgraph.py

and ask questions like

When was the last payement made ?
how much amount has been paid in total ?


# MCP Workshop: LangGraph & Text2SQL Integration

This workshop demonstrates the Model Context Protocol (MCP) implementation with practical examples of LangGraph and Text2SQL capabilities for database interactions.

## Workshop Objectives

This hands-on workshop will teach you:

1. **Model Context Protocol (MCP)**: Understanding and implementing MCP servers for AI tool integration
2. **LangGraph**: Building conversational AI workflows with graph-based architectures  
3. **Text2SQL**: Converting natural language queries into SQL statements for database interactions
4. **End-to-End Integration**: Connecting AI clients to databases through MCP for real-world applications

## Workshop Structure

```
mcp-poc/
├── mcp_server.py          # MCP server implementation (Workshop Part 1)
├── mcp-check.py           # Server connectivity test
├── client_langgraph.py    # LangGraph client demo (Workshop Part 2)
├── client_strands.py      # Alternative AI client implementation
├── create_db.py           # Database setup for Text2SQL demos
├── your_sqlite.db         # Sample SQLite database with payment data
├── requirements.txt       # Workshop dependencies
├── MCP demo.pptx         # Workshop presentation slides
└── README.md             # Workshop instructions
```

## What You'll Learn

### Part 1: Model Context Protocol (MCP)
- Understanding MCP architecture and benefits
- Setting up and configuring MCP servers
- Creating database connections through MCP
- Testing server functionality and connectivity

### Part 2: LangGraph Integration
- Building conversational AI workflows
- Graph-based conversation management
- Integrating with MCP servers for data access
- Creating intelligent query routing

### Part 3: Text2SQL Capabilities
- Natural language to SQL conversion
- Database schema understanding
- Query optimization and validation
- Real-time data retrieval and presentation

## Workshop Setup Instructions

### Prerequisites
- Python 3.8+ installed
- Terminal/Command prompt access
- Text editor or IDE (VS Code recommended)

### Step 1: Install Workshop Dependencies

Install all required Python packages:

```bash
pip install -r requirements.txt
```

### Step 2: Start the MCP Server (Workshop Part 1)

Launch the MCP server to begin the demonstration:

```bash
python mcp_server.py
```

**🎯 Learning Focus**: Understanding how MCP servers initialize and connect to databases

### Step 3: Verify Server Connection

Test the server connectivity:

```bash
python mcp-check.py
```

**🎯 Learning Focus**: MCP communication protocols and health checks

### Step 4: Run the LangGraph Client (Workshop Part 2)

Start the interactive LangGraph client:

```bash
python client_langgraph.py
```

**🎯 Learning Focus**: Graph-based conversation flows and natural language processing

## Workshop Demo Queries (Text2SQL Examples)

Once the system is running, try these natural language queries to see Text2SQL in action:

### Basic Queries
- **"When was the last payment made?"**
  - *Demonstrates*: Date/time queries and SQL MAX functions
- **"How much amount has been paid in total?"**
  - *Demonstrates*: Aggregate functions (SUM) and data summarization

### Advanced Queries  
- **"Show me all payments made this year"**
  - *Demonstrates*: Date filtering and range queries
- **"What's the average payment amount?"**
  - *Demonstrates*: Statistical operations (AVG)
- **"List payments greater than $1000"**
  - *Demonstrates*: Conditional filtering (WHERE clauses)
- **"How many payments were made each month?"**
  - *Demonstrates*: GROUP BY operations and date functions

### Workshop Discussion Points
- How does the LangGraph agent understand the query intent?
- What SQL queries are generated behind the scenes?
- How does MCP facilitate the database communication?
- Error handling and query validation strategies

## Workshop Technology Stack

### Core MCP Components
- **fastmcp**: Core MCP server functionality and protocol implementation
- **mcp**: MCP client library for communication

### AI & LangGraph Components  
- **langchain-core**: Foundation for LangGraph workflows
- **langchain-ollama**: Integration with Ollama for local LLM processing
- **ollama**: Local language model client for Text2SQL generation

### Alternative Frameworks
- **strands-agents**: Alternative AI agents framework for comparison

## Workshop Outcomes

By the end of this workshop, participants will have:

- ✅ **MCP Understanding**: Practical knowledge of Model Context Protocol architecture
- ✅ **Server Implementation**: Hands-on experience setting up MCP servers
- ✅ **LangGraph Proficiency**: Built conversational AI workflows using graph structures
- ✅ **Text2SQL Skills**: Converted natural language to SQL queries effectively
- ✅ **Integration Experience**: Connected multiple components in a real-world scenario
- ✅ **Database Interaction**: Demonstrated practical database querying through AI

## Workshop Flow

1. **Introduction** (15 mins): MCP concepts and architecture overview
2. **Hands-on Setup** (20 mins): Install dependencies and start servers
3. **MCP Deep Dive** (20 mins): Explore server implementation and connections
4. **LangGraph Demo** (25 mins): Build and test conversational workflows
5. **Text2SQL Practice** (30 mins): Try various natural language queries
6. **Discussion & Q&A** (10 mins): Explore advanced use cases and troubleshooting

## Troubleshooting & Common Issues

### Server Issues
- **Port conflicts**: Check if port 3000 is already in use
- **Dependencies**: Ensure all packages from `requirements.txt` are installed
- **Database access**: Verify `your_sqlite.db` exists and is readable

### Client Connection Issues  
- **MCP connectivity**: Run `mcp-check.py` to verify server is responding
- **Ollama setup**: Ensure Ollama is running locally if using local models
- **Network**: Check firewall settings if clients can't connect

### Query Issues
- **SQL errors**: Check database schema matches expected structure
- **No results**: Verify sample data exists in the database
- **Timeout**: Complex queries may need longer processing time

## Next Steps & Extensions

- Extend to other database types (PostgreSQL, MySQL)
- Add authentication and security layers
- Implement more sophisticated LangGraph workflows
- Create custom MCP tools for specific business logic
- Integrate with external APIs and services

## Resources for Further Learning

- [MCP Documentation](https://modelcontextprotocol.io/)
- [LangGraph Official Guide](https://langchain-ai.github.io/langgraph/)
- [Text2SQL Best Practices](https://github.com/eosphoros-ai/DB-GPT)

---

*This workshop is designed for hands-on learning. Feel free to experiment with the code and ask questions during the session!*

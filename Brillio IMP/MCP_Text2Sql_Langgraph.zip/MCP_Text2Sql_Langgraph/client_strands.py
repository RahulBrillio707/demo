from mcp.client.streamable_http import streamablehttp_client
from strands import Agent
import asyncio
from fastmcp import Client, FastMCP
from strands.models.ollama import OllamaModel
import time
mcp_client = Client("http://localhost:8001/mcp")

# Add this function to check connection status
async def check_mcp_connection():
    """Check if MCP server is connected using ping method"""
    try:
        # Use the async context manager to establish connection
        async with mcp_client:
            # Use ping() method to test actual connectivity
            if mcp_client.ping():
                print("✅ MCP server responded to ping - connection is active")
                return True
            else:
                print("❌ MCP server did not respond to ping")
                return False
    except Exception as e:
        print(f"❌ Error checking connection: {e}")
        return False

# Remove this line - it creates a coroutine object without executing it
# status_of_mcp = check_mcp_connection()
# print("--------------------------------")
# print("status of mcp server")
# print(status_of_mcp)
# print("--------------------------------")


# Remove this problematic code - it won't work at top level
# print("list of tools")
# mcp_tools =  asyncio.run(mcp_client.list_tools())
# print("tools")
# print(tools)
# print("--------------------------------")


# Connect to your MCP server over HTTP
async def convert_mcp_tools_to_strands(mcp_tools):
    """Convert MCP Tool objects to a format that Strands can understand"""
    tools = await mcp_client.list_tools()
    return tools




ollama_model = OllamaModel(
    host="http://localhost:11434",
    model_id="mistral:latest",
)

# Global log stream for web interface
log_stream = []

def log_step(step, message, data=None):
    """Log a step with timestamp"""
    timestamp = time.strftime("%H:%M:%S")
    log_entry = {
        "timestamp": timestamp,
        "step": step,
        "message": message,
        "data": data
    }
    log_stream.append(log_entry)
    print(f"[{timestamp}] {step}: {message}")

Sql_generator_prompt = """You are an expert SQLite SQL query generator.

**Your ONLY task is to translate natural language questions into accurate, executable SQL queries.**
**Your response MUST contain ONLY the SQL query. Do NOT include any explanations, conversational text, markdown formatting (other than for the SQL itself), or comments.**

**Database Schema:**
Table: `payments`
Description: This table contains information related to payments made and payments yet to be paid to vendors.
Columns:
- `id`: INTEGER (Unique primary key for each payment record.)
- `milestone`: TEXT (Project milestone associated with this payment, e.g., "Initial Setup", "Phase 1 Delivery", "Phase 2 Delivery", "Final Handover")
- `amount`: REAL (Amount to be paid in USD.)
- `date`: TEXT (Payment date in YYYY-MM-DD format, e.g., "2024-01-15", "2024-03-01", "2024-06-15", "2024-09-30")

**Instructions:**
1.  **Analyze the Question:** Carefully understand the user's request, focusing on what data they want and from which column(s).
2.  **Generate SQL Only:** Provide ONLY the SQL query. No preamble, no postamble.
3.  **Strictly Adhere to Schema:** Use exact table (`payments`) and column names (`id`, `milestone`, `amount`, `date`).
4.  **SQLite Dialect:** All generated SQL must be valid for SQLite.
5.  **Date Column:** The `date` column is stored as TEXT in 'YYYY-MM-DD' format. Handle date comparisons and filtering as string operations.
6.  **No Execution:** Do NOT attempt to execute the query or provide any results.

**Examples:**
---
Question: What is the total amount paid?
SQL Query: SELECT SUM(amount) FROM payments;
---
Question: Show me the payments for 'Initial Setup'.
SQL Query: SELECT * FROM payments WHERE milestone = 'Initial Setup';
---
Question: What is the amount paid for payment ID 3?
SQL Query: SELECT amount FROM payments WHERE id = 3;
---
Question: When was the 'Final Handover' payment made?
SQL Query: SELECT date FROM payments WHERE milestone = 'Final Handover';
---
Question: List all payments made after 2024-05-01.
SQL Query: SELECT * FROM payments WHERE date > '2024-05-01';
---
Question: What are the milestones and amounts for payments made in March 2024?
SQL Query: SELECT milestone, amount FROM payments WHERE date LIKE '2024-03%';
---
Question: How many payments are there?
SQL Query: SELECT COUNT(*) FROM payments;
---
Question: Find the payment with ID 1.
SQL Query: SELECT * FROM payments WHERE id = 1;
---
Question: What is the largest payment amount?
SQL Query: SELECT MAX(amount) FROM payments;
"""

async def process_query(question):
    """Process a query with comprehensive logging and return structured result"""
    log_stream.clear()  # Clear previous logs
    
    try:
        # Step 1: User question received
        log_step("USER_INPUT", f"Received question: {question}")
        
        async with mcp_client:
            # Step 2: Connecting to MCP server
            log_step("MCP_CONNECTION", "Connecting to MCP server...")
            tools = await mcp_client.list_tools()
            log_step("MCP_CONNECTION", f"Connected successfully. Available tools: {len(tools)}")
            
            # Step 3: SQL processing
            log_step("SQL_PROCESSING", "Processing SQL query...")
            log_step("SQL_AGENT", "Invoking SQL generation agent...")
            
            # Fix: Await the convert_mcp_tools_to_strands function
            converted_tools = await convert_mcp_tools_to_strands(tools)
            
            text2_sql_agent = Agent(
                system_prompt=Sql_generator_prompt,
                tools=converted_tools,  # Use the awaited result
                model=ollama_model
            )
            sql_query = text2_sql_agent(question)
            log_step("SQL_GENERATION", f"Generated SQL query: {sql_query}")

            # Clean up the SQL (remove backticks, whitespace, and 'SQL Query:' prefix)
            if isinstance(sql_query, str):
                sql_query_clean = sql_query.strip().strip('`')
                if sql_query_clean.lower().startswith("sql query:"):
                    sql_query_clean = sql_query_clean[len("SQL Query:"):].strip()
            else:
                sql_query_clean = str(sql_query).strip().strip('`')
                if sql_query_clean.lower().startswith("sql query:"):
                    sql_query_clean = sql_query_clean[len("SQL Query:"):].strip()
            
            log_step("SQL_CLEANUP", f"Cleaned SQL query: {sql_query_clean}")

            # Execute SQL
            log_step("SQL_EXECUTION", "Executing SQL query against database...")
            result = await mcp_client.call_tool("query_db", {"sql": sql_query_clean})
            log_step("SQL_RESULT", "SQL query executed successfully")

            if hasattr(result, "structured_content") and result.structured_content and "result" in result.structured_content:
                sql_rows = result.structured_content["result"]
                log_step("SQL_DATA", f"Retrieved {len(sql_rows) if isinstance(sql_rows, list) else 1} rows")
                log_step("COMPLETION", "Query processing completed successfully")
                return {
                    "type": "SQL",
                    "query": sql_query_clean,
                    "result": sql_rows
                }
            else:
                log_step("SQL_DATA", "Retrieved raw result data")
                log_step("COMPLETION", "Query processing completed successfully")
                return {
                    "type": "SQL",
                    "query": sql_query_clean,
                    "result": result
                }
                
    except Exception as e:
        log_step("ERROR", f"Exception occurred: {str(e)}")
        raise e

async def main():
    """Original main function for command line usage"""
    
    # Check connection status first using ping
    print("--------------------------------")
    print("status of mcp server")
    connection_status = await check_mcp_connection()
    print(f"Connection status: {connection_status}")
    print("--------------------------------")
    
    if not connection_status:
        print("Cannot proceed without MCP server connection")
        return
    
    # List tools here - inside the async context
    try:
        async with mcp_client:
            print("list of tools")
            mcp_tools = await mcp_client.list_tools()
            print("tools")
            print(f"Found {len(mcp_tools)} tools:")
            for tool in mcp_tools:
                print(f"  - {tool.name}: {tool.description}")
            print("--------------------------------")
    except Exception as e:
        print(f"Error listing tools: {e}")
        return
    
    user_question = input("Enter your question: ")
    result = await process_query(user_question)
    
    if result["type"] == "SQL":
        print("********************SQL Query Result*******************************")
        print("SQL Query:", result["query"])
        print("SQL Query Result:", result["result"])
        print("***************************************************")
    else:
        print("Error:", result["message"])

if __name__ == "__main__":
    asyncio.run(main())

from mcp.client.streamable_http import streamablehttp_client
from langchain_core.messages import HumanMessage, AIMessage
from langchain_ollama import OllamaLLM
from langchain_core.prompts import ChatPromptTemplate
import asyncio
from fastmcp import Client
import time
from typing import List, Dict, Any
import json

# Connect to your MCP server over HTTP
mcp_client = Client("http://localhost:8001/mcp")

# Add MCP connection checking functionality
async def main():
    """Check if MCP server is connected using ping method"""
    try:
        # Use the async context manager to establish connection
        async with mcp_client:
            # Use ping() method to test actual connectivity
            if mcp_client.ping():
                print("✅ MCP server responded to ping - connection is active")
                return True
            else:
                print("❌ MCP server did not respond to ping")
                return False
    except Exception as e:
        print(f"❌ Error checking connection: {e}")
        return False

async def check_mcp_tools():
    """Get list of available MCP tools"""
    try:
        async with mcp_client:
            tools = await mcp_client.list_tools()
            print(f"✅ Retrieved {len(tools)} MCP tools")
            for tool in tools:
                print(tool)
            
            return tools
    except Exception as e:
        print(f"❌ Error retrieving MCP tools: {e}")
        return []

if __name__ == "__main__":
    asyncio.run(main())
    asyncio.run(check_mcp_tools())
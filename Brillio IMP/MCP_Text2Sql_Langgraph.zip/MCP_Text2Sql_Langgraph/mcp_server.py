from fastmcp import FastMCP, mcp_config
import sqlite3


mcp = FastMCP("DB Query Server")

@mcp.tool
def query_db(sql: str) -> list[dict]:
    """Execute a SQL query on the payments DB and return results as a list of dicts."""
    conn = sqlite3.connect("your_sqlite.db")
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    try:
        cursor.execute(sql)
        rows = cursor.fetchall()
        result = [dict(row) for row in rows]
    except Exception as e:
        result = [{"error": str(e)}]
    finally:
        conn.close()
    return result



if __name__ == "__main__":
    mcp.run(transport="http", port=8001, host="0.0.0.0")
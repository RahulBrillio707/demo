from mcp.client.streamable_http import streamablehttp_client
from langchain_core.messages import HumanMessage, AIMessage
from langchain_ollama import OllamaLLM
from langchain_core.prompts import ChatPromptTemplate
import asyncio
from fastmcp import Client
import time
from typing import List, Dict, Any
import json

# Connect to your MCP server over HTTP
mcp_client = Client("http://localhost:8001/mcp")

# Add MCP connection checking functionality
async def check_mcp_connection():
    """Check if MCP server is connected using ping method"""
    try:
        # Use the async context manager to establish connection
        async with mcp_client:
            # Use ping() method to test actual connectivity
            if mcp_client.ping():
                print("✅ MCP server responded to ping - connection is active")
                return True
            else:
                print("❌ MCP server did not respond to ping")
                return False
    except Exception as e:
        print(f"❌ Error checking connection: {e}")
        return False

async def get_mcp_tools():
    """Get list of available MCP tools"""
    try:
        async with mcp_client:
            tools = await mcp_client.list_tools()
            print(f"✅ Retrieved {len(tools)} MCP tools")
            return tools
    except Exception as e:
        print(f"❌ Error retrieving MCP tools: {e}")
        return []

ollama_llm = OllamaLLM(
    base_url="http://localhost:11434",
    model="mistral:latest",
)

# Global log stream for web interface
log_stream = []

def log_step(step, message, data=None):
    """Log a step with timestamp"""
    timestamp = time.strftime("%H:%M:%S")
    log_entry = {
        "timestamp": timestamp,
        "step": step,
        "message": message,
        "data": data
    }
    log_stream.append(log_entry)
    print(f"[{timestamp}] {step}: {message}")

# Single Agent Prompt
single_agent_prompt = ChatPromptTemplate.from_messages([
    ("system", """You are an expert SQLite SQL query generator and executor.

**Your task is to:**
1. Translate natural language questions into accurate, executable SQL queries
2. Execute the SQL query against the database
3. Provide a clear, formatted response with both the SQL query and results

**Database Schema:**
Table: `payments`
Description: This table contains information related to payments made and payments yet to be paid to vendors.
Columns:
- `id`: INTEGER (Unique primary key for each payment record.)
- `milestone`: TEXT (Project milestone associated with this payment, e.g., "Initial Setup", "Phase 1 Delivery", "Phase 2 Delivery", "Final Handover")
- `amount`: REAL (Amount to be paid in USD.)
- `date`: TEXT (Payment date in YYYY-MM-DD format, e.g., "2024-01-15", "2024-03-01", "2024-06-15", "2024-09-30")

**Instructions:**
1. **Analyze the Question:** Carefully understand the user's request
2. **Generate SQL:** Create a valid SQLite SQL query using exact table and column names
3. **Execute Query:** Run the query against the database
4. **Format Response:** Provide a clear response with the SQL query and results

**SQLite Dialect:** All generated SQL must be valid for SQLite.
**Date Column:** The `date` column is stored as TEXT in 'YYYY-MM-DD' format.

**Response Format:**
- Start with "SQL Query: [your SQL here]"
- Then show "Results: [formatted results]"
- If there's an error, explain what went wrong and suggest a solution

**Examples:**
Question: What is the total amount paid?
Response: SQL Query: SELECT SUM(amount) FROM payments;
Results: [Total amount will be shown here]

Question: Show me the payments for 'Initial Setup'.
Response: SQL Query: SELECT * FROM payments WHERE milestone = 'Initial Setup';
Results: [Payment details will be shown here]
"""),
    ("human", "{question}")
])

async def single_agent(question: str) -> Dict[str, Any]:
    """Single agent that handles SQL generation, execution, and response generation"""
    log_step("SINGLE_AGENT", f"Processing question: {question}")
    
    try:
        # Step 1: Generate SQL query
        log_step("SQL_GENERATION", "Generating SQL query...")
        response = ollama_llm.invoke(single_agent_prompt.format(question=question))
        
        # Extract SQL query from response
        if hasattr(response, 'content'):
            full_response = response.content.strip()
        else:
            full_response = str(response).strip()
        
        # Extract SQL query (look for "SQL Query:" pattern)
        if "SQL Query:" in full_response:
            sql_part = full_response.split("SQL Query:")[1].split("Results:")[0].strip()
            sql_query = sql_part.strip().strip('`')
        else:
            # Fallback: try to extract SQL from the response
            sql_query = full_response.strip().strip('`')
        
        log_step("SQL_GENERATION", f"Generated SQL query: {sql_query}")
        
        # Step 2: Execute SQL query
        log_step("SQL_EXECUTION", "Executing SQL query...")
        async with mcp_client:
            result = await mcp_client.call_tool("query_db", {"sql": sql_query})
            
            if hasattr(result, "structured_content") and result.structured_content and "result" in result.structured_content:
                sql_rows = result.structured_content["result"]
                log_step("SQL_EXECUTION", f"Query executed successfully. Retrieved {len(sql_rows) if isinstance(sql_rows, list) else 1} rows")
            else:
                sql_rows = result
                log_step("SQL_EXECUTION", "Query executed successfully. Retrieved raw result data")
        
        # Step 3: Generate final response
        log_step("RESPONSE_GENERATION", "Generating final response...")
        final_response = f"SQL Query: {sql_query}\n\nResults: {sql_rows}"
        
        log_step("COMPLETION", "Single agent processing completed successfully")
        
        return {
            "type": "SQL",
            "query": sql_query,
            "result": sql_rows,
            "response": final_response
        }
        
    except Exception as e:
        log_step("ERROR", f"Single agent failed: {str(e)}")
        error_response = f"I encountered an error while processing your request: {str(e)}. Please try rephrasing your question or check if the database is accessible."
        
        return {
            "type": "ERROR",
            "message": error_response
        }

async def process_query(question):
    """Process a query using the single agent"""
    log_stream.clear()  # Clear previous logs
    
    try:
        # Step 1: User question received
        log_step("USER_INPUT", f"Received question: {question}")
        
        # Step 2: Run the single agent
        log_step("SINGLE_AGENT", "Starting single agent processing...")
        result = await single_agent(question)
        
        # Step 3: Return results
        log_step("COMPLETION", f"Single agent processing completed. Type: {result['type']}")
        return result
                
    except Exception as e:
        log_step("ERROR", f"Exception occurred: {str(e)}")
        raise e

async def main():
    """Original main function for command line usage"""
    
    # Check MCP connection status first
    print("🔍 Checking MCP server connection...")
    connection_status = await check_mcp_connection()
    print(f"Connection Status: {'✅ Connected' if connection_status else '❌ Not Connected'}")
    print("-" * 50)
    
    # Get and display MCP tools
    print("🔧 Retrieving MCP tools...")
    tools = await get_mcp_tools()
    print(f"Number of available tools: {len(tools)}")
    print("Available tools:")
    for i, tool in enumerate(tools, 1):
        print(f"  {i}. {tool.name if hasattr(tool, 'name') else str(tool)}")
    print("-" * 50)
    
    # Continue with original functionality
    user_question = input("Enter your question: ")
    result = await process_query(user_question)
    
    if result["type"] == "SQL":
        print("********************SQL Query Result*******************************")
        print("SQL Query:", result["query"])
        print("SQL Query Result:", result["result"])
        print("Response:", result["response"])
        print("***************************************************")
    else:
        print("Error:", result["message"])

if __name__ == "__main__":
    asyncio.run(main())
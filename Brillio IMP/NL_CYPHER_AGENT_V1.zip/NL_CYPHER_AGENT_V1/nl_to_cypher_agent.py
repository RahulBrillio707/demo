"""
LangGraph Agent for Natural Language to Cypher Query Conversion
This agent converts natural language queries to Cypher queries using Neo4j schema context.
"""

import json
import re
from typing import Dict, List, Any, Optional, TypedDict
from langgraph.graph import StateGraph, END
import logging
import os
from dotenv import load_dotenv
load_dotenv()

from ambiguity_resolver import AmbiguityResolver
from langchain_openai import AzureChatOpenAI


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

schema_file_path = os.getenv('SCHEMA_FILE_PATH', "neo4j_data-lineage_schema.json")
api_key = os.getenv('OPENAI_API_KEY') 
azure_endpoint = os.getenv('OPENAI_API_KEY_ENDPOINT') 
azure_deployment = os.getenv('OPENAI_DEPLOYMENT') 
api_version = os.getenv('OPENAI_API_VERSION')

# agent
class AgentState(TypedDict):
    """State for the NL to Cypher agent"""
    messages: List[Any]
    natural_language_query: str
    cypher_query: str
    schema_context: Dict[str, Any]
    query_analysis: Dict[str, Any]
    validation_result: Dict[str, Any]
    final_query: str
    retry_count: int
    clarification_required: str
    clarification_questions:  List[Any]
    resolved_entities : Dict[str, Any]

class NLToCypherAgent:
    """Agent for converting natural language to Cypher queries"""
    
    def __init__(self, schema_file_path: str = schema_file_path):
        self.schema_file_path = schema_file_path       
 
        self.llm = AzureChatOpenAI(
            api_key= api_key,
            azure_endpoint=azure_endpoint,
            azure_deployment=azure_deployment,
            api_version=api_version
        )
        self.MAX_RETRIES  = 3
        self.schema_context = self._load_schema()
        self.graph = self._build_graph()

        self.ambiguity_handler = AmbiguityResolver() #QueryAmbiguityHandler()
        
    def _load_schema(self) -> Dict[str, Any]:
        """Load Neo4j schema from JSON file"""
        try:
            with open(self.schema_file_path, 'r') as f:
                schema = json.load(f)
            logger.info(f"Loaded schema with {len(schema)} entities")
            return schema
        except FileNotFoundError:
            logger.error(f"Schema file not found: {self.schema_file_path}")
            return {}
        except json.JSONDecodeError:
            logger.error(f"Invalid JSON in schema file: {self.schema_file_path}")
            return {}
    
    def _extract_schema_summary(self) -> str:
        """Extract a human-readable summary of the schema"""
        nodes = []
        relationships = []
        
        for entity_name, entity_data in self.schema_context.items():
            if entity_data.get('type') == 'node':
                properties = list(entity_data.get('properties', {}).keys())
                node_relationships = list(entity_data.get('relationships', {}).keys())
                nodes.append(f"- {entity_name}: properties={properties[:5]}, relationships={node_relationships}")
            elif entity_data.get('type') == 'relationship':
                relationships.append(f"- {entity_name}")
        
        return f"""
Neo4j Database Schema Summary:

NODES:
{chr(10).join(nodes)}

RELATIONSHIPS:
{chr(10).join(relationships)}

Key Patterns:
- Database nodes store Collections via STORES_IN relationship
- Applications contain Api_Endpoints via CONTAINS relationship  
- Api_Endpoints read from/write to Collections via READS_FROM/WRITES_TO
- Collections have Fields via HAS_FIELD relationship
- Applications define Collections via DEFINES relationship
- Applications use Api_Calls via USES relationship
- Api_Calls target Api_Endpoints via TARGETS relationship
"""

    def analyze_query(self, state: AgentState) -> AgentState:
        """Analyze the natural language query to understand intent and entities"""
        
        schema_summary = self._extract_schema_summary()
        
        try:
            
            analysis_system_prompt = f"""You are an expert at analyzing natural language queries for Neo4j databases.

Given a natural language query, analyze it to identify:
1. Main entities mentioned (Database, Application, Collection, Field, etc.)
2. Relationships being queried (connections, interactions, dependencies)
3. Query type (find paths, list entities, show relationships, etc.)
4. Specific names or patterns mentioned, Strictly extract names for the NODES available in the schema_summary, do not assume and extract other node types.
5. If name is not preceded or succeeded by node type, add that as 'Unknown' node type while adding to specific names.
6. Do not add additional entities and relarionships which are not mentioned in the query.
7. Do not add None in specific_names if no specific names are mentioned. Ex: 'Application': None

Schema context:
{schema_summary}

Return your analysis as a JSON object with keys: entities, relationships, query_type, specific_names, relationship_depth

Analyze this query: {state["natural_language_query"]}"""

            response = self.llm.invoke(analysis_system_prompt)

            # extract JSON from response
            content = response.content
            if "```json" in content:
                json_match = re.search(r'```json\s*(\{.*?\})\s*```', content, re.DOTALL)
                if json_match:
                    analysis = json.loads(json_match.group(1))
                else:
                    analysis = {"error": "Could not parse JSON from response"}
            else:
                # parse the entire content as JSON
                try:
                    analysis = json.loads(content)
                except:
                    analysis = {"raw_response": content}
            
            state["query_analysis"] = analysis
            logger.info(f"Query analysis completed: {analysis}")
            
        except Exception as e:
            logger.error(f"Error in query analysis: {e}")
            state["query_analysis"] = {"error": str(e)}
        
        return state

    def generate_cypher(self, state: AgentState) -> AgentState:
        """Generate Cypher query based on analysis"""

        schema_summary = self._extract_schema_summary()
        analysis = state.get("query_analysis", {})

        try:
            
            system_prompt = f"""You are an expert Neo4j Cypher query generator for data lineage systems.

Given a natural language query and its analysis, generate an accurate Cypher query.

Schema Information:
{schema_summary}

Key Guidelines:
1. Use exact node labels: Database, Application, Collection, Field, Api_Endpoint, Api_Call
2. Use exact relationship types: STORES_IN, CONTAINS, READS_FROM, WRITES_TO, DEFINES, USES, TARGETS, HAS_FIELD
3. For indirect relationships, use variable-length paths like [*1..2] or [*1..3]
4. Always use RETURN to specify what to return (nodes, relationships, or paths)
5. Use WHERE clauses for filtering by properties like name
6. For database names, they often include IP addresses in format "Name (IP:Port)"
7. Always ensure Cypher queries are constructed to return a graph visualization by default. Only return non-visual outputs (such as lists, tables, or counts) if the user explicitly requests them.

Query Analysis: {json.dumps(analysis, indent=2)}

Generate ONLY the Cypher query, no explanations.

Natural language query: {state["natural_language_query"]}"""

            response = self.llm.invoke(system_prompt)
            cypher_query = response.content


            # Clean up the query - remove markdown formatting if present
            if "```cypher" in cypher_query:
                cypher_match = re.search(r'```cypher\s*(.*?)\s*```', cypher_query, re.DOTALL)
                if cypher_match:
                    cypher_query = cypher_match.group(1).strip()
            elif "```" in cypher_query:
                cypher_match = re.search(r'```\s*(.*?)\s*```', cypher_query, re.DOTALL)
                if cypher_match:
                    cypher_query = cypher_match.group(1).strip()

            state["cypher_query"] = cypher_query
            logger.info(f"Generated Cypher query:- {cypher_query}")

        except Exception as e:
            logger.error(f"Error generating Cypher query: {e}")
            state["cypher_query"] = f"-- Error generating query: {e}"

        return state

    def validate_query(self, state: AgentState) -> AgentState:
        """Validate the generated Cypher query"""

        schema_summary = self._extract_schema_summary()
        cypher_query = state.get("cypher_query", "")

        try:
            
            validation_system_prompt = f"""You are a Cypher query validator. Check if the query is syntactically correct and uses valid node labels and relationships from the schema.

Schema Information:
{schema_summary}

Validation Criteria:
1. Syntax correctness
2. Valid node labels (Database, Application, Collection, Field, Api_Endpoint, Api_Call)
3. Valid relationship types (STORES_IN, CONTAINS, READS_FROM, WRITES_TO, DEFINES, USES, TARGETS, HAS_FIELD) between th nodes based on the schema summary.
4. Proper use of MATCH, WHERE, RETURN clauses
5. Logical relationship paths
6. Always ensure Cypher queries are constructed to return a graph visualization by default. Only return non-visual outputs (such as lists, tables, or counts) if the user explicitly requests them.

Return validation result as JSON with keys: is_valid, issues, suggestions

Validate this Cypher query: {cypher_query}"""

            response = self.llm.invoke(validation_system_prompt)

            content = response.content
            if "```json" in content:
                json_match = re.search(r'```json\s*(\{.*?\})\s*```', content, re.DOTALL)
                if json_match:
                    validation = json.loads(json_match.group(1))
                else:
                    validation = {"is_valid": True, "issues": [], "suggestions": []}
            else:
                try:
                    validation = json.loads(content)
                except:
                    validation = {"is_valid": True, "issues": [], "raw_response": content}

            if validation.get("is_valid", True):
                # Query is valid, use as final query
                state["final_query"] = state.get("cypher_query", "")

            state["validation_result"] = validation
            logger.info(f"Validation result: {validation}")

        except Exception as e:
            logger.error(f"Error validating query: {e}")
            state["validation_result"] = {"is_valid": False, "issues": [str(e)]}

        return state

    def refine_query(self, state: AgentState) -> AgentState:
        """Refine the query if validation found issues"""
        logger.info(f"*** Retry ***: {state.get('retry_count', 1)}")

        validation = state.get("validation_result", {})

        if validation.get("is_valid", True):
            # Query is valid, use as final query
            state["final_query"] = state.get("cypher_query", "")
            return state

        # Query has issues, try to refine it
        schema_summary = self._extract_schema_summary()

        try:
            
            refinement_system_prompt = f"""You are a Cypher query expert. Fix the issues in the provided query while maintaining its original intent and following the Instructions mentioned below.

Schema Information:
{schema_summary}

Original Query: {state.get("cypher_query", "")}
Validation Issues: {validation.get("issues", [])}
Suggestions: {validation.get("suggestions", [])}

==Instructions==
1.Always provide cyher query for visualization, unless it is not possible for the given user query.

Generate a corrected Cypher query that addresses all issues."""

            response = self.llm.invoke(refinement_system_prompt)

            refined_query = response.content
            # Clean up the query
            if "```cypher" in refined_query:
                cypher_match = re.search(r'```cypher\s*(.*?)\s*```', refined_query, re.DOTALL)
                if cypher_match:
                    refined_query = cypher_match.group(1).strip()
            elif "```" in refined_query:
                cypher_match = re.search(r'```\s*(.*?)\s*```', refined_query, re.DOTALL)
                if cypher_match:
                    refined_query = cypher_match.group(1).strip()

            state["final_query"] = refined_query
            state["retry_count"] = state.get("retry_count", 1) + 1
            logger.info(f"Refined query: {refined_query}")

        except Exception as e:
            logger.error(f"Error refining query: {e}")
            # Fall back to original query
            state["final_query"] = state.get("cypher_query", "")
            state["retry_count"] = state.get("retry_count", 1) + 1

        return state
    
    def route_after_validation(self, state: AgentState):
        """Decide where to go after validation"""
        if state.get("validation_result", {}).get("is_valid", False):
            logger.info(f"*********** VAlID **************")
            return END
        if state.get("retry_count", 1) >= self.MAX_RETRIES:
            logger.info(f"*********** Not VAlID **************")
            return END  # stop after max retries
        return "refine_query"
    

    def detect_ambiguity(self, state: AgentState) -> AgentState:
        """New node: Detect ambiguities before analysis"""
        
        # user_query = state["natural_language_query"]
        
        # Detect ambiguities
        resolved_entities = self.ambiguity_handler.resolve_ambiguity(state['query_analysis'])

        clarification_questions = []
        for ent in resolved_entities:
            resolved = ent.get("resolved", {})
            if resolved.get("status") == "ambiguous":
                candidates = resolved.get("candidates", [])
                ent_type = ent.get("type")
                ent_name = ent.get("name")

                q = f"Your query mentions an entity of type '{ent_type}'"
                if ent_name:
                    q += f" with name '{ent_name}'"
                q += f", but I found {len(candidates)} possible matches:\n"

                for i, opt in enumerate(candidates, 1):
                    q += f"  {i}. {opt['name']} (type={opt['node_type']}, repo={opt.get('repo_uuid')})\n"

                q += "Which one did you mean?"
                clarification_questions.append(q)

        if clarification_questions:
            state["clarification_required"] = True
            state["clarification_questions"] = clarification_questions
        else:
            state["clarification_required"] = False
            state["clarification_questions"] = []

        state['resolved_entities'] = resolved_entities
        # logger.info(f"clarification_questions :{state['clarification_questions']}")
        
        return state

    def convert_query(self, natural_language_query: str) -> Dict[str, Any]:
        """Convert natural language query to Cypher query"""

        initial_state = {
            "messages": [],
            "natural_language_query": natural_language_query,
            "cypher_query": "",
            "schema_context": self.schema_context,
            "query_analysis": {},
            "validation_result": {},
            "final_query": "",
             "retry_count": 0 
        }

        try:
            result = self.graph.invoke(initial_state)

            return {
                "natural_language_query": natural_language_query,
                "cypher_query": result.get("final_query", ""),
                "analysis": result.get("query_analysis", {}),
                "validation": result.get("validation_result", {}),
                "success": True
            }

        except Exception as e:
            logger.error(f"Error in query conversion: {e}")
            return {

                "natural_language_query": natural_language_query,
                "cypher_query": "",
                "analysis": {},
                "validation": {},
                "success": False,
                "error": str(e)
            }
        
    def _build_graph(self) -> StateGraph:
        """Build the LangGraph workflow with ambiguity detection after analysis"""

        workflow = StateGraph(AgentState)

        # Nodes
        workflow.add_node("analyze_query", self.analyze_query)
        workflow.add_node("detect_ambiguity", self.detect_ambiguity)
        workflow.add_node("generate_cypher", self.generate_cypher)
        workflow.add_node("validate_query", self.validate_query)
        workflow.add_node("refine_query", self.refine_query)

        # Entry Point
        workflow.set_entry_point("analyze_query")

        # Analyze → Detect Ambiguity
        workflow.add_edge("analyze_query", "detect_ambiguity")

        # Ambiguity Branching
        workflow.add_conditional_edges(
            "detect_ambiguity",
            lambda state: (
                "clarification_needed"
                if state.get("clarification_required", False)
                else "continue"
            ),
            {
                "clarification_needed": END,    # Stop → return questions to user
                "continue": "generate_cypher",  # Continue normally
            }
        )

        # Normal NL → Cypher Flow
        workflow.add_edge("generate_cypher", "validate_query")

        # Validation & Refinement Loop
        workflow.add_conditional_edges(
            "validate_query",
            self.route_after_validation,
            {
                END: END,
                "refine_query": "refine_query",
            }
        )
        workflow.add_edge("refine_query", "validate_query")

        return workflow.compile()

    def build_rephrase_prompt(self, org_query: str, clarification_question: str, user_input: str) -> str:
        return f"""
    You are an expert in interpreting and rephrasing natural language queries.

    The user asked the following original query:
    {org_query}

    During processing, the system asked this clarification question:
    {clarification_question}

    The user responded with:
    {user_input}

    Rephrase the **original query** to incorporate the user’s clarification so that it becomes precise, unambiguous, and ready for downstream processing.
    Only rephrase; do not add extra assumptions.
    """


        
    def interactive_convert_query(self, natural_language_query: str):
        """Run pipeline, ask clarification if needed, then re-run"""

        state = {
            "messages": [],
            "natural_language_query": natural_language_query,
            "cypher_query": "",
            "schema_context": self.schema_context,
            "query_analysis": {},
            "validation_result": {},
            "final_query": "",
            "retry_count": 1,
            'resolved_entities' : {},
            'clarification_required': False,
            'clarification_questions':[]

        }

        result = self.graph.invoke(state)

        print("clarification_required : ",result.get("clarification_required"))

        # --- Case 1: Needs clarification ---
        if result.get("clarification_required"):
            print("Ambiguity detected!")
           
            for question in result['clarification_questions']:
                print("\nClarification required:")
                print(question)

                while True:
                    try:
                        choice = int(input("Enter your choice (number): ").strip())
                        break
                    except ValueError:
                        print("Please enter a valid number.")

                for ent in result["resolved_entities"]:
                    resolved = ent.get("resolved", {})
    
                    if resolved.get("status") == "ambiguous":
                        candidates = resolved["candidates"]
                        if 1 <= choice <= len(candidates):
                            chosen = candidates[choice - 1]
                            logger.info(f"nl query org : {natural_language_query}")
                            logger.info(f"chosen : {chosen}")
                        
                            chosen = candidates[choice-1]
                            rephase_prompt = self.build_rephrase_prompt(org_query= natural_language_query,
                                                                clarification_question=question,
                                                                user_input= chosen)
                            logger.info(f"rephase_prompt : {rephase_prompt}")
                            response = self.llm.invoke(rephase_prompt)
                            logger.info(f"rephrased_query res : {response}")
                            rephrased_query = response.content

                print("\nClarification received, re-running pipeline...\n")

                # Re-run pipeline with resolved entities
                # state["query_analysis"] = result["query_analysis"]
                state['natural_language_query'] = rephrased_query
                logger.info(f"nl qury : {state['natural_language_query']}")
                result = self.graph.invoke(state)

        # Final Output
        return {
            "natural_language_query": natural_language_query,
            "cypher_query": result.get("final_query", ""),
            "analysis": result.get("query_analysis", {}),
            "validation": result.get("validation_result", {}),
            "success": True
        }

    def convert_query_with_clarification(self, natural_language_query: str) -> Dict[str, Any]:
        """Enhanced convert_query method with clarification handling"""
        
        initial_state = {
            "messages": [],
            "natural_language_query": natural_language_query,
            "cypher_query": "",
            "schema_context": self.schema_context,
            "query_analysis": {},
            "validation_result": {},
            "final_query": "",
            "retry_count": 1,
            "ambiguities_detected": [],
            "clarification_questions": [],
            "resolved_query": "",
            "needs_user_clarification": False,
        }
        
        # Run the workflow
        result = self.graph.invoke(initial_state)
        logger.info(f"result : {result['clarification_questions']}")
        
        # Check if clarification is needed
        if result["needs_user_clarification"]:
            logger.info(f"Needs clarification.......{result['clarification_questions']}")
            return {
                "success": False,
                "needs_clarification": True,
                "clarification_questions": result["clarification_questions"],
                "ambiguities": result["ambiguities_detected"],
                "message": "Please clarify your query before I can generate Cypher."
            }
        
        # Normal processing if no ambiguity
        return {
            "success": True,
            "needs_clarification": False,
            "cypher_query": result.get("final_query", ""),
            "resolved_query": result.get("resolved_query", ""),
            "analysis": result.get("query_analysis", {}),
        }


def main():
    """Example usage of the NL to Cypher Agent"""

    # Initialize the agent
    agent = NLToCypherAgent()

    # Example queries
    # example_queries = [
    #     "How is database OneInsights (172.23.75.4:27017) interacting with the application?",
    #     "Show me all applications that read from any collection",
    #     "What fields are available in collections stored in the database?",
    #     "Find all API endpoints that write to collections",
    #     "Show the path from database to application through collections",
    #     "Which applications define collections?",
    #     "What are all the relationships between databases and applications?"
    # ]

    example_queries  = ["How is database 'OneInsights (172.23.75.4:27017)' interacting with the application?"]
    print("Natural Language to Cypher Query Agent \n")

    # for i, query in enumerate(example_queries, 1):
    #     print(f"Example {i}: {query}")
    #     result = agent.convert_query(query)

    #     if result["success"]:
    #         print(f"Generated Cypher Query:")
    #         print(f"```cypher\n{result['cypher_query']}\n```")

    #         if result["analysis"]:
    #             print(f"Analysis: {result['analysis']}")

    #         if result["validation"] and not result["validation"].get("is_valid", True):
    #             print(f"Validation Issues: {result['validation'].get('issues', [])}")
    #     else:
    #         print(f"Error: {result.get('error', 'Unknown error')}")

    #     print("-" * 80)

    # Interactive mode
    print("\n=== Interactive Mode ===")
    print("Enter your natural language queries (type 'quit' to exit):")

    while True:
        try:
            user_query = input("\nQuery: ").strip()

            if user_query.lower() in ['quit', 'exit', 'q']:
                break

            if not user_query:
                continue

            result = agent.interactive_convert_query(user_query)

            # return result

            if result["success"]:
                print(f"\nGenerated Cypher Query:")
                print(f"```cypher\n{result['cypher_query']}\n```")

                # Show analysis if available
                analysis = result.get("analysis", {})
                if analysis and "entities" in analysis:
                    print(f"\nDetected Entities: {analysis.get('entities', [])}")
                    print(f"Query Type: {analysis.get('query_type', 'Unknown')}")
                    print(f"Relationship Depth: {analysis.get('relationship_depth', 'Direct')}")
            else:
                print(f"\nError: {result.get('error', 'Unknown error')}")

        except KeyboardInterrupt:
            print("\nExiting...")
            break
        except Exception as e:
            print(f"Error: {e}")


if __name__ == "__main__":
    main()

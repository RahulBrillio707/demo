from dotenv import load_dotenv
from neo4j import GraphDatabase
import json
import os
load_dotenv()

uri =  os.getenv('NEO4J_DB2_URI', 'bolt://localhost:7687')
username = os.getenv('NEO4J_DB2_USERNAME', 'neo4j')
password = os.getenv('NEO4J_DB2_PASSWORD', 'password')
database_name =  os.getenv('NEO4J_DB2_DATABASE', 'data-lineage')


def get_db_schema_from_neo4j():
    driver = GraphDatabase.driver(uri, auth=(username, password))

    with driver.session(database= database_name) as session: 
        schema = session.run("CALL apoc.meta.schema()").single().value()
        with open(f"neo4j_{database_name}_schema2.json", "w") as f:
            json.dump(schema, f, indent=2)


if __name__=="__main__":
    get_db_schema_from_neo4j()


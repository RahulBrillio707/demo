from collections import defaultdict
import rapidfuzz
from rapidfuzz import fuzz, process
import json
# from nl_to_cypher_agent import AgentState


class SchemaIndex:
    """Searchable index over schema nodes for ambiguity resolution"""

    def __init__(self):
        self.by_name = defaultdict(list)
        self.all_nodes = []
        self.name_index = defaultdict(list)
        self.schema_nodes = self._load_schema("main_data_lineage.json")
    
        for node in self.schema_nodes:
            name = node.get("name")
            if not name:
                continue
            self.all_nodes.append(node)
            self.name_index[name.lower()].append(node)

    def exact_lookup(self, name: str) -> list[dict]:
        """Return nodes with exact lowercase match"""
        return self.name_index.get(name.lower(), [])

    def fuzzy_lookup(self, name: str, limit: int = 5, score_cutoff: int = 60) -> list[dict]:
        """Return closest fuzzy matches using RapidFuzz"""

        choices = [n["name"] for n in self.all_nodes if "name" in n]
        print("choices :  ", choices)

        matches = process.extract(
            name,
            choices,
            scorer= fuzz.partial_ratio,  
            limit=limit,
            score_cutoff=score_cutoff,
            processor=lambda x: x # compare only the name part
        )

        # print("choices : ",choices)
        print("matches: ",matches)
        matched_nodes = [m[0] for m in matches] 
        all_matches = [n for n in self.all_nodes if n.get("name") in matched_nodes]

        return  all_matches # extract the node dicts



    def type_filter(self, candidates: list[dict], node_type: str) -> list[dict]:
        """Filter nodes by type"""
        return [c for c in candidates if c.get("node_type") == node_type]
    

    def _load_schema(self, schema_file_path):
        """Load Neo4j schema from JSON file"""
        try:
            with open(schema_file_path, 'r') as f:
                schema = json.load(f)
            print(f"Loaded schema with {len(schema)} entities")


            nodes = []
            for key, value in schema.items():
                # print("key : ", key)
                # print("value: ", value)
                # print(value.keys())
                # If value is a dict with "node_type", treat it as a node
                if isinstance(value, dict) and "node_type" in value:
                    nodes.append(value)
                # If it's a nested list (rare case), extend it
                elif isinstance(value, list):
                    nodes.extend(value)
                return nodes
        except FileNotFoundError:
            print(f"Schema file not found: {schema_file_path}")
            return {}
        except json.JSONDecodeError:
            print(f"Invalid JSON in schema file: {schema_file_path}")
            return {}
    


class AmbiguityResolver():
    def __init__(self):
        self.index = SchemaIndex()


    def resolve_ambiguity(self, analysis):# state: AgentState) -> AgentState:
        print("*"*50)
        entities = analysis.get("entities", [])
        specific_names = analysis.get("specific_names", {})

        print("specific_names :",specific_names)

        resolved_entities = []


        for ent_type in entities:
            names = specific_names.get(ent_type)
        
            if isinstance(names, str):
                names = [names]
            if names:
                for name in names:
                    fuzzy_match = False
                    candidates = []

                    # Try exact lookup first
                    candidates = self.index.exact_lookup(name)

                    print("Exact match candidates : ",candidates)

                    if not candidates:
                        # Fall back to fuzzy
                        candidates = self.index.fuzzy_lookup(name, score_cutoff=90)
                        print("fuzzy_lookup candidates : ",candidates)
                        fuzzy_match = True

                    # Filter by type if available
                    # candidates = index.type_filter(candidates, ent_type)
                    # print("type_filter candidates : ",candidates)

                    else:
                        # No specific name → find all nodes of this type
                        candidates = self.index.type_filter(self.index.all_nodes, ent_type)
                        print("else type_filter candidates : ",candidates)


                    # Decide resolution status
                    if len(candidates) == 1 and not fuzzy_match:
                        resolved = {"status": "resolved", "entity": candidates[0]}
                    elif len(candidates) > 1 or fuzzy_match:
                        # if fuzzy_match and len(candidates)==1: candidates = [candidates]
                        print("more candidates or  fuzzy_match: ",candidates)
                        resolved = {
                            "status": "ambiguous",
                            "candidates": [
                                {
                                    # "uuid": c["uuid"],
                                    "name": c["name"],
                                    "node_type": c["node_type"],
                                    # "repo_uuid": c.get("repo_uuid"),
                                }
                                for c in candidates
                            ]
                        }
                    else:
                        resolved = {"status": "not_found"}

                    print("name : ",name)
                    if candidates:
                        resolved_entities.append({
                            "type": ent_type,
                            "name": name,
                            "resolved": resolved
                        })

        # Store back into analysis
        # state['analysis']["resolved_entities"] = resolved_entities

        return resolved_entities
    

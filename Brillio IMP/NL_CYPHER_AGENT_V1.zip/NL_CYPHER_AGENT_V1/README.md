# Natural Language to Cypher Query Agent

A LangGraph-based agent that converts natural language queries to Cypher queries for Neo4j data lineage databases.

## Features

- 🤖 **LangGraph Agent**: Multi-step workflow for query analysis, generation, and validation
- 🧠 **Schema-Aware**: Uses your Neo4j schema as context for accurate query generation
- 🔄 **Indirect Relationships**: Handles complex path queries with variable-length relationships
- **Ambiguity Resolver**: Resolves ambiguity in the user questiona and also raises clarification questions if needed.
- ✅ **Query Validation**: Validates generated queries against schema

## Quick Start

### 1. Installation

```bash
# Install dependencies
pip install -r requirements.txt
```

### 2. Environment Setup

Create a `.env` file (copy from `.env.example`):

```bash
# Required

# Azure Openai
OPENAI_API_KEY= b1af33941ef9408088e7180ca36947ee
OPENAI_API_KEY_ENDPOINT= https://btaasopenai.openai.azure.com/
OPENAI_DEPLOYMENT= model_data_lineage
OPENAI_API_VERSION= 2024-12-01-preview

# Optional (for query execution)
NEO4J_URI=bolt://localhost:7687
NEO4J_USERNAME=neo4j
NEO4J_PASSWORD=your_password

# Configuration
SCHEMA_FILE_PATH=neo4j_data-lineage_schema.json
```

### 3. Basic Usage

```python
from nl_to_cypher_agent import NLToCypherAgent

# Initialize agent
agent = NLToCypherAgent()

# Convert natural language to Cypher
result = agent.convert_query("How is database OneInsights interacting with the application?")

if result["success"]:
    print(f"Generated Cypher: {result['cypher_query']}")
else:
    print(f"Error: {result['error']}")
```

### 4. Run Examples

```bash
# Test the agent
python test_agent.py

# Run interactive mode
python nl_to_cypher_agent.py
```

## Example Queries

The agent can handle various types of natural language queries:

| Natural Language | Generated Cypher |
|------------------|------------------|
| "How is database OneInsights interacting with the application?" | `MATCH p=(d:Database {name: "OneInsights (172.23.75.4:27017)"})-[*1..2]-(a:Application) RETURN p` |
| "Show me all applications that read from collections" | `MATCH (a:Application)-[CONTAINS]->(e:Api_Endpoint)-[READS_FROM]->(c:Collection) RETURN a, e, c` |
| "What fields are available in collections?" | `MATCH (c:Collection)-[HAS_FIELD]->(f:Field) RETURN c.name, f.name` |
| "Find API endpoints that write to collections" | `MATCH (e:Api_Endpoint)-[WRITES_TO]->(c:Collection) RETURN e, c` |

## Schema Structure

The agent works with the following Neo4j schema:

### Node Types
- **Database**: Data storage systems
- **Application**: Software applications
- **Collection**: Data collections/tables
- **Field**: Data fields/columns
- **Api_Endpoint**: API endpoints
- **Api_Call**: API calls

### Relationship Types
- **STORES_IN**: Collection → Database
- **CONTAINS**: Application → Api_Endpoint
- **READS_FROM**: Api_Endpoint → Collection
- **WRITES_TO**: Api_Endpoint → Collection
- **DEFINES**: Application → Collection
- **USES**: Application → Api_Call
- **TARGETS**: Api_Call → Api_Endpoint
- **HAS_FIELD**: Collection → Field

## Agent Workflow

The LangGraph agent follows this workflow:

1. **Query Analysis**: Analyzes natural language to identify entities, relationships, and intent
2. **Cypher Generation**: Generates optimized Cypher query based on analysis
3. **Query Validation**: Validates query syntax and schema compliance
4. **Query Refinement**: Fixes issues if validation fails
5. **Execution** (Advanced): Optionally executes query against Neo4j
6. **Response Formatting**: Formats results for user



### Customization

You can customize the agent behavior:

```python
# Custom schema file and model
agent = NLToCypherAgent(
    schema_file_path="custom_schema.json",
    model_name="gpt-4"
)

# Advanced agent with Neo4j connection
agent = AdvancedNLToCypherAgent(
    neo4j_uri="bolt://localhost:7687",
    neo4j_username="neo4j",
    neo4j_password="password"
)
```

## Files

- `nl_to_cypher_agent.py`: Basic LangGraph agent
- `test_agent.py`: Test script with examples
- `neo4j_data-lineage_schema.json`: Neo4j schema definition
- `requirements.txt`: Python dependencies
- `.env.example`: Environment variables template

## Requirements

- Python 3.8+
- OpenAI API key
- Neo4j database (optional, for query execution)

## Dependencies

- `langchain`: LangChain framework
- `langchain-openai`: OpenAI integration
- `langgraph`: Graph-based agent framework
- `neo4j`: Neo4j Python driver (optional)
- `python-dotenv`: Environment variable management

## Troubleshooting

### Common Issues

1. **"Schema file not found"**: Ensure `neo4j_data-lineage_schema.json` exists, Run `get_schema.py`.
2. **"OpenAI API key not set"**: Set `OPENAI_API_KEY` in `.env` file
3. **"Neo4j connection failed"**: Check Neo4j URI and credentials
4. **main_data_lineage.json** : Ensure you have `main_data_lineage.json` in the following format
```json
{
  "nodes": [
    {
      "uuid": "49422caf-b6fd-30fe-d202-79b7d98a1493",
      "node_type": "application",
      "name": "Configurations",
      "full_name": "Configurations",
      "repo_uuid": "2e36918f-0f89-1de2-6168-8e5dae45c88e",
      "created_at": "2025-08-26T16:16:09.021595",
      "source": "repository",
      "confidence": 1.0,
      "properties": {
        "url": "file://workspace\\Configurations",
        "branch": "main",
        "commit_hash": "local-copy",
        "file_count": 0,
        "total_lines": 0,
        "appears_in_repos": [
          "2e36918f-0f89-1de2-6168-8e5dae45c88e"
        ]
      }
    },
    {
      "uuid": "8af77268-0287-e421-97e5-f826f82ca3e4",
      "node_type": "collection",
      "name": "almconfiguration",
      "full_name": "almconfiguration",
      "repo_uuid": "2e36918f-0f89-1de2-6168-8e5dae45c88e",
      "file_path": "src\\main\\java\\com\\oneinsights\\configurations\\model\\ALMConfiguration.java",
      "created_at": "2025-08-26T16:16:09.122065",
      "source": "ast",
      "confidence": 0.9,
      "properties": {
        "document_class": "com.oneinsights.configurations.model.ALMConfiguration",
        "collection_name": "almconfiguration",
        "database_type": "mongodb",
        "found_in_repos": [
          "2e36918f-0f89-1de2-6168-8e5dae45c88e"
        ]
      }
    }]
}
```
5. **Change code in ambiguity_resolver.py**: If the nodes are not in the above format, please change code in the mentioned script accordingly.


#!/usr/bin/env python3
"""
Interactive Data Lineage Pipeline with Repository Management
"""

import os
import sys
import time
import shutil
import subprocess
from pathlib import Path

# Add the project root to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from agents.agent_01_collector import FileCollector
from agents.agent_02_parser import JavaASTParser
from agents.agent_03_framework import FrameworkDetector
from agents.agent_04_symbols import SymbolTableBuilder
from agents.agent_05_transformations import VariableTransformationAnalyzer
from agents.agent_06_normalization import DataNormalizer
from agents.agent_07_neo4j import Neo4jGraphBuilder

def get_user_input():
    """Get user input for repository selection"""
    print("=" * 60)
    print("🚀 DATA LINEAGE PIPELINE - 7 AGENT ARCHITECTURE")
    print("=" * 60)
    
    # Ask for local or git
    while True:
        print("\n📂 Repository Source:")
        print("1. Local repository")
        print("2. Git repository")
        source_type = input("Select (1/2): ").strip()
        if source_type in ['1', '2']:
            break
        print("❌ Please enter 1 or 2")
    
    repositories = []
    workspace_dir = "workspace"
    
    # Ensure workspace directory exists
    os.makedirs(workspace_dir, exist_ok=True)
    
    while True:
        if source_type == '1':
            # Local repository
            while True:
                repo_path = input("\n📁 Enter local repository path: ").strip().strip('"')
                if os.path.exists(repo_path):
                    # Copy to workspace
                    repo_name = os.path.basename(repo_path)
                    workspace_path = os.path.join(workspace_dir, repo_name)
                    
                    if os.path.exists(workspace_path):
                        shutil.rmtree(workspace_path)
                    
                    print(f"📋 Copying {repo_path} to workspace...")
                    shutil.copytree(repo_path, workspace_path)
                    repositories.append(workspace_path)
                    print(f"✅ Repository copied to: {workspace_path}")
                    break
                else:
                    print(f"❌ Path not found: {repo_path}")
        
        else:
            # Git repository
            while True:
                git_url = input("\n🌐 Enter Git repository URL: ").strip()
                if git_url:
                    # Extract repo name from URL
                    repo_name = git_url.split('/')[-1].replace('.git', '')
                    workspace_path = os.path.join(workspace_dir, repo_name)
                    
                    if os.path.exists(workspace_path):
                        shutil.rmtree(workspace_path)
                    
                    print(f"📥 Cloning {git_url}...")
                    try:
                        result = subprocess.run(['git', 'clone', git_url, workspace_path], 
                                              capture_output=True, text=True, check=True)
                        repositories.append(workspace_path)
                        print(f"✅ Repository cloned to: {workspace_path}")
                        break
                    except subprocess.CalledProcessError as e:
                        print(f"❌ Git clone failed: {e.stderr}")
                        continue
                else:
                    print("❌ Please enter a valid Git URL")
        
        # Ask for additional repositories
        while True:
            add_more = input("\n➕ Add another repository? (y/n): ").strip().lower()
            if add_more in ['n', 'no']:
                return repositories
            elif add_more in ['y', 'yes']:
                # Ask for source type again
                while True:
                    print("\n📂 Repository Source:")
                    print("1. Local repository")
                    print("2. Git repository")
                    source_type = input("Select (1/2): ").strip()
                    if source_type in ['1', '2']:
                        break
                    print("❌ Please enter 1 or 2")
                break
            else:
                print("❌ Please enter y or n")

def run_pipeline_for_repo(repo_path, output_path):
    """Run the complete pipeline for a single repository"""
    repo_name = os.path.basename(repo_path)
    print(f"\n🔄 Processing Repository: {repo_name}")
    print("=" * 60)
    
    start_time = time.time()
    
    try:
        # Agent 1: File Collection
        print("\n📁 Agent 1: File Collection")
        print("-" * 40)
        collector = FileCollector()
        collection_data = collector.collect_files(repo_path)
        collector.save_results(collection_data, output_path)
        print(f"✅ Collected {collection_data['total_files']} files")
        
        # Agent 2: AST Parsing and Method Chunking
        print("\n🌳 Agent 2: AST Parsing & Method Chunking")
        print("-" * 40)
        parser = JavaASTParser()
        parsing_data = parser.parse_repository(repo_path)
        parser.save_results(parsing_data, output_path)
        print(f"✅ Created {parsing_data['total_chunks']} method chunks")
        print(f"✅ Extracted {parsing_data['total_nodes']} nodes")
        
        # Agent 3: Framework Detection
        print("\n🔍 Agent 3: Framework Detection")
        print("-" * 40)
        framework_detector = FrameworkDetector()
        framework_data = framework_detector.detect_frameworks(output_path)
        framework_detector.save_results(framework_data, output_path)
        print(f"✅ Detected {len(framework_data.get('detected_frameworks', []))} frameworks")
        
        # Agent 4: Symbol Table Generation
        print("\n📊 Agent 4: Symbol Table Generation")
        print("-" * 40)
        symbol_builder = SymbolTableBuilder()
        symbol_data = symbol_builder.build_symbol_tables(output_path)
        symbol_builder.save_results(symbol_data, output_path)
        print(f"✅ Generated symbol tables with {symbol_data['total_symbols']} symbols")
        
        # Agent 5: Variable Transformation Analysis
        print("\n🤖 Agent 5: Variable Transformation Analysis")
        print("-" * 40)
        transformation_analyzer = VariableTransformationAnalyzer()
        transformation_data = transformation_analyzer.analyze_transformations(output_path)
        transformation_analyzer.save_results(transformation_data, output_path)
        print(f"✅ Analyzed {transformation_data['total_transformations']} transformations")
        
        # Agent 6: Data Normalization
        print("\n🔧 Agent 6: Data Normalization")
        print("-" * 40)
        normalizer = DataNormalizer()
        parsing_file = os.path.join(output_path, "parsing.json")
        transformations_file = os.path.join(output_path, "variable_transformations.json")
        normalized_data = normalizer.normalize_data(parsing_file, transformations_file)
        normalizer.save_final_lineage(normalized_data, output_path)
        print(f"✅ Normalized {normalized_data['metadata']['total_nodes']} nodes")
        
        # Agent 7: Neo4j Graph Building
        print("\n🗄️  Agent 7: Neo4j Graph Building")
        print("-" * 40)
        graph_builder = Neo4jGraphBuilder()
        graph_data = graph_builder.build_graph(output_path)
        graph_builder.save_results(graph_data, output_path)
        print(f"✅ Loaded {graph_data['load_results']['nodes_created']} nodes to Neo4j")
        
        # Repository completion
        end_time = time.time()
        duration = end_time - start_time
        
        print(f"\n✅ Repository {repo_name} completed in {duration:.2f} seconds")
        return True
        
    except Exception as e:
        print(f"\n❌ Repository {repo_name} failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run the complete data lineage pipeline"""
    
    # Get user input for repositories
    repositories = get_user_input()
    
    if not repositories:
        print("❌ No repositories selected")
        return 1
    
    print(f"\n📋 Selected {len(repositories)} repositories:")
    for repo in repositories:
        print(f"  - {os.path.basename(repo)}")
    
    # Process each repository
    output_path = "output"
    os.makedirs(output_path, exist_ok=True)
    
    total_start_time = time.time()
    successful_repos = 0
    
    for repo_path in repositories:
        if run_pipeline_for_repo(repo_path, output_path):
            successful_repos += 1
    
    # Final summary
    total_end_time = time.time()
    total_duration = total_end_time - total_start_time
    
    print("\n" + "=" * 60)
    print("🎉 PIPELINE COMPLETED!")
    print("=" * 60)
    print(f"📊 Processed: {successful_repos}/{len(repositories)} repositories")
    print(f"⏱️  Total execution time: {total_duration:.2f} seconds")
    print(f"📁 Output directory: {output_path}")
    print(f"🗄️  Neo4j database: data-lineage")
    print("=" * 60)
    
    return 0 if successful_repos == len(repositories) else 1

if __name__ == "__main__":
    exit(main())

"""
Agent 7: Graph Database Agent
Pushes final_lineage.json to Neo4j database
"""

import os
import json
from typing import Dict, List, Any
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Neo4j imports
try:
    from neo4j import GraphDatabase
    NEO4J_AVAILABLE = True
except ImportError:
    NEO4J_AVAILABLE = False
    print("Warning: Neo4j driver not available, using simulation mode")

class Neo4jGraphBuilder:
    """Loads data lineage into Neo4j graph database"""
    
    def __init__(self, test_database=None):
        self.driver = None
        self.neo4j_available = False

        # Initialize Neo4j connection
        if NEO4J_AVAILABLE:
            try:
                uri = os.getenv("NEO4J_DB_URI", "bolt://localhost:7687")
                username = os.getenv("NEO4J_DB_USERNAME", "neo4j")
                password = os.getenv("NEO4J_DB_PASSWORD", "Test@7889")
                database = test_database or os.getenv("NEO4J_DB_DATABASE", "data-lineage")

                self.driver = GraphDatabase.driver(uri, auth=(username, password))
                self.database = database
                self.neo4j_available = True

                # Test connection
                with self.driver.session(database=database) as session:
                    session.run("RETURN 1")

                print(f"  Neo4j connected: {uri} (database: {database})")

            except Exception as e:
                print(f"  Warning: Failed to connect to Neo4j: {e}")
                self.neo4j_available = False
        else:
            print("  Warning: Neo4j driver not available, using simulation mode")
    
    def load_lineage_to_neo4j(self, final_lineage_file: str) -> Dict[str, Any]:
        """
        Load final lineage data into Neo4j
        
        Args:
            final_lineage_file: Path to final_lineage.json from Agent 6
            
        Returns:
            Load results summary
        """
        print("Agent 7: Loading data lineage into Neo4j")
        
        # Load final lineage data
        with open(final_lineage_file, 'r', encoding='utf-8') as f:
            lineage_data = json.load(f)
        
        nodes = lineage_data['nodes']
        relationships = lineage_data['relationships']
        
        if self.neo4j_available:
            result = self._load_to_neo4j(nodes, relationships, lineage_data)
        else:
            result = self._simulate_neo4j_load(nodes, relationships, lineage_data)
        
        print(f"  Loaded {result['nodes_created']} nodes")
        print(f"  Created {result['relationships_created']} relationships")
        
        return result
    
    def _load_to_neo4j(self, nodes: List[Dict], relationships: List[Dict], lineage_data: Dict) -> Dict[str, Any]:
        """Actually load data to Neo4j"""
        nodes_created = 0
        relationships_created = 0
        relationships_skipped = 0

        try:
            with self.driver.session(database=self.database) as session:
                # Clear existing data (optional - be careful in production)
                print("    Clearing existing data...")
                session.run("MATCH (n) DETACH DELETE n")
                
                # Filter out nodes with generic IDs (from LLM that don't map properly)
                import re
                generic_pattern = re.compile(r'^(node_\d+|n\d+)$')
                valid_nodes = [node for node in nodes if not generic_pattern.match(node['node_id'])]
                nodes_filtered = len(nodes) - len(valid_nodes)

                print(f"    Filtered out {nodes_filtered} nodes with generic IDs")
                print(f"    Creating {len(valid_nodes)} valid nodes...")

                for node in valid_nodes:
                    # Normalize node type to proper case (capitalize first letter)
                    node_type = node['node_type'].capitalize()
                    properties = node['properties'].copy()
                    properties['node_id'] = node['node_id']
                    properties['name'] = node['name']

                    # Convert lists to strings for Neo4j
                    for key, value in properties.items():
                        if isinstance(value, list):
                            properties[key] = ', '.join(str(v) for v in value)

                    # Use MERGE to prevent duplicate nodes
                    query = f"MERGE (n:{node_type} {{node_id: $node_id}}) SET n += $props"
                    session.run(query, node_id=properties['node_id'], props=properties)
                    nodes_created += 1
                
                # Create relationships with proper duplicate prevention
                print("    Creating relationships...")
                relationship_cache = set()  # Track created relationships

                # Create node ID lookup for validation (only valid nodes)
                valid_node_ids = {node['node_id'] for node in valid_nodes}
                relationships_skipped_invalid = 0

                for rel in relationships:
                    # Normalize relationship type to uppercase for Neo4j convention
                    rel_type = rel['relationship_type'].upper()
                    source_id = rel['source_id']
                    target_id = rel['target_id']

                    # Skip relationships with invalid node IDs (generic IDs from LLM that don't map to real nodes)
                    if source_id not in valid_node_ids or target_id not in valid_node_ids:
                        relationships_skipped_invalid += 1
                        continue

                    # Create unique key for this relationship
                    rel_key = (source_id, target_id, rel_type)

                    # Skip if this exact relationship already exists
                    if rel_key in relationship_cache:
                        print(f"      Skipping duplicate relationship: {source_id} -[{rel_type}]-> {target_id}")
                        relationships_skipped += 1
                        continue

                    # Add to cache
                    relationship_cache.add(rel_key)

                    # Use MERGE with unique constraint on source, target, and type
                    query = f"""
                    MATCH (source {{node_id: $source_id}})
                    MATCH (target {{node_id: $target_id}})
                    MERGE (source)-[r:{rel_type}]->(target)
                    ON CREATE SET r += $props
                    ON MATCH SET r += $props
                    """

                    props = rel['properties'].copy()
                    props['relationship_id'] = rel['relationship_id']
                    props['relationship_type'] = rel['relationship_type']  # Keep original type as property

                    # Convert lists to strings
                    for key, value in props.items():
                        if isinstance(value, list):
                            props[key] = ', '.join(str(v) for v in value)

                    session.run(query,
                               source_id=source_id,
                               target_id=target_id,
                               props=props)
                    relationships_created += 1
                
                # Create indexes for performance
                print("    Creating indexes...")
                session.run("CREATE INDEX IF NOT EXISTS FOR (n:Method) ON (n.node_id)")
                session.run("CREATE INDEX IF NOT EXISTS FOR (n:Class) ON (n.node_id)")
                session.run("CREATE INDEX IF NOT EXISTS FOR (n:Field) ON (n.node_id)")
                
        except Exception as e:
            print(f"    Error loading to Neo4j: {e}")
            return self._simulate_neo4j_load(nodes, relationships, lineage_data)
        
        print(f"    Summary: {nodes_created} nodes, {relationships_created} relationships created")
        print(f"    Filtered: {nodes_filtered} generic nodes")
        print(f"    Skipped: {relationships_skipped} duplicates, {relationships_skipped_invalid} invalid node references")

        return {
            'status': 'success',
            'nodes_created': nodes_created,
            'nodes_filtered': nodes_filtered,
            'relationships_created': relationships_created,
            'relationships_skipped': relationships_skipped,
            'relationships_skipped_invalid': relationships_skipped_invalid,
            'database': self.database,
            'load_method': 'Neo4j'
        }
    
    def _simulate_neo4j_load(self, nodes: List[Dict], relationships: List[Dict], lineage_data: Dict) -> Dict[str, Any]:
        """Simulate Neo4j load for testing"""
        print("    Simulating Neo4j load...")
        
        # Count node types
        node_types = {}
        for node in nodes:
            node_type = node['node_type']
            node_types[node_type] = node_types.get(node_type, 0) + 1
        
        # Count relationship types
        rel_types = {}
        for rel in relationships:
            rel_type = rel['relationship_type']
            rel_types[rel_type] = rel_types.get(rel_type, 0) + 1
        
        print(f"    Node types: {node_types}")
        print(f"    Relationship types: {rel_types}")
        
        return {
            'status': 'simulated',
            'nodes_created': len(nodes),
            'relationships_created': len(relationships),
            'database': 'simulation',
            'load_method': 'Simulation',
            'node_types': node_types,
            'relationship_types': rel_types
        }
    
    def create_graph_summary(self, load_result: Dict[str, Any], output_path: str):
        """Create summary of graph database load"""
        os.makedirs(output_path, exist_ok=True)
        
        summary_file = os.path.join(output_path, "neo4j_load_summary.json")
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(load_result, f, indent=2, ensure_ascii=False)
        
        print(f"Agent 7 Complete: Data lineage loaded to Neo4j")
    
    def build_graph(self, output_path: str) -> Dict[str, Any]:
        """Build graph from final lineage data"""
        final_lineage_file = os.path.join(output_path, "final_lineage.json")
        return self.load_lineage_to_neo4j(final_lineage_file)

    def save_results(self, graph_data: Dict[str, Any], output_path: str):
        """Save graph building results"""
        self.create_graph_summary(graph_data, output_path)

    def validate_no_duplicates(self) -> Dict[str, Any]:
        """Validate that no duplicate relationships exist in the database"""
        if not self.neo4j_available:
            return {"status": "skipped", "reason": "Neo4j not available"}

        try:
            with self.driver.session(database=self.database) as session:
                # Query to find duplicate relationships
                query = """
                MATCH (a)-[r]->(b)
                WITH a.node_id as source_id, b.node_id as target_id, type(r) as rel_type, count(r) as rel_count
                WHERE rel_count > 1
                RETURN source_id, target_id, rel_type, rel_count
                ORDER BY rel_count DESC
                """

                result = session.run(query)
                duplicates = []

                for record in result:
                    duplicates.append({
                        'source_id': record['source_id'],
                        'target_id': record['target_id'],
                        'relationship_type': record['rel_type'],
                        'count': record['rel_count']
                    })

                # Get total counts
                total_query = """
                MATCH (n)
                OPTIONAL MATCH (n)-[r]->()
                RETURN count(DISTINCT n) as node_count, count(r) as relationship_count
                """

                total_result = session.run(total_query).single()

                return {
                    'status': 'success',
                    'duplicates_found': len(duplicates),
                    'duplicate_relationships': duplicates,
                    'total_nodes': total_result['node_count'],
                    'total_relationships': total_result['relationship_count'],
                    'database': self.database
                }

        except Exception as e:
            return {
                'status': 'error',
                'error': str(e),
                'database': self.database
            }

    def close(self):
        """Close Neo4j connection"""
        if self.driver:
            self.driver.close()

if __name__ == "__main__":
    loader = Neo4jGraphBuilder()
    
    try:
        # Test Neo4j loading
        final_lineage_file = "output/final_lineage.json"
        if os.path.exists(final_lineage_file):
            load_result = loader.load_lineage_to_neo4j(final_lineage_file)
            loader.create_graph_summary(load_result, "output")
        else:
            print("Run Agent 6 first to create final_lineage.json")
    finally:
        loader.close()

"""
Agent 3: Framework Detection Agent
Detects API calls and endpoints based on frameworks
Adds them to parsing.json
"""

import os
import json
import uuid
from typing import Dict, List, Any

class FrameworkDetector:
    """Detects framework patterns and API endpoints"""
    
    def __init__(self):
        pass
        
        # Framework patterns
        self.framework_patterns = {
            'spring_boot': {
                'annotations': ['@RestController', '@RequestMapping', '@GetMapping', '@PostMapping', '@PutMapping', '@DeleteMapping'],
                'imports': ['org.springframework.web.bind.annotation', 'org.springframework.boot']
            },
            'spring_data': {
                'annotations': ['@Repository', '@Entity', '@Table'],
                'imports': ['org.springframework.data', 'javax.persistence']
            },
            'hibernate': {
                'annotations': ['@Entity', '@Table', '@Column'],
                'imports': ['org.hibernate', 'javax.persistence']
            }
        }
    
    def detect_frameworks(self, output_path: str) -> Dict[str, Any]:
        """
        Detect frameworks and add API endpoints to parsing data

        Args:
            output_path: Path to output directory containing parsing.json

        Returns:
            Updated parsing data with API endpoints
        """
        print("Agent 3: Detecting frameworks and API endpoints")

        # Load parsing data
        parsing_file = os.path.join(output_path, "parsing.json")
        with open(parsing_file, 'r', encoding='utf-8') as f:
            parsing_data = json.load(f)

        nodes = parsing_data['nodes']
        relationships = parsing_data['relationships']
        
        # Detect frameworks
        detected_frameworks = self._detect_frameworks_from_nodes(nodes)
        print(f"  Detected frameworks: {detected_frameworks}")
        
        # Find API endpoints
        api_endpoints = []
        api_calls = []
        
        if 'spring_boot' in detected_frameworks:
            endpoints, calls = self._detect_spring_endpoints(nodes, relationships)
            api_endpoints.extend(endpoints)
            api_calls.extend(calls)
        
        if 'spring_data' in detected_frameworks:
            repo_calls = self._detect_repository_calls(nodes, relationships)
            api_calls.extend(repo_calls)
        
        # Add API nodes to parsing data
        for endpoint in api_endpoints:
            endpoint_node = {
                'node_id': str(uuid.uuid4()),
                'node_type': 'API_Endpoint',
                'name': endpoint['path'],
                'properties': {
                    'http_method': endpoint['method'],
                    'path': endpoint['path'],
                    'controller': endpoint['controller'],
                    'handler_method': endpoint['handler_method']
                }
            }
            nodes.append(endpoint_node)
            
            # Add relationship from controller method to endpoint
            endpoint_rel = {
                'relationship_id': str(uuid.uuid4()),
                'source_id': endpoint['method_id'],
                'target_id': endpoint_node['node_id'],
                'relationship_type': 'EXPOSES_ENDPOINT',
                'properties': {}
            }
            relationships.append(endpoint_rel)
        
        # Add API call nodes
        for call in api_calls:
            call_node = {
                'node_id': str(uuid.uuid4()),
                'node_type': 'API_Call',
                'name': call['target'],
                'properties': {
                    'call_type': call['type'],
                    'target': call['target'],
                    'source_method': call['source_method']
                }
            }
            nodes.append(call_node)
            
            # Add relationship from source method to API call
            call_rel = {
                'relationship_id': str(uuid.uuid4()),
                'source_id': call['source_id'],
                'target_id': call_node['node_id'],
                'relationship_type': 'MAKES_API_CALL',
                'properties': {}
            }
            relationships.append(call_rel)
        
        # Update parsing data
        parsing_data['total_nodes'] = len(nodes)
        parsing_data['total_relationships'] = len(relationships)
        parsing_data['nodes'] = nodes
        parsing_data['relationships'] = relationships

        # Add framework detection results
        parsing_data['frameworks'] = {
            'detected_frameworks': detected_frameworks,
            'api_endpoints': len(api_endpoints),
            'api_calls': len(api_calls)
        }
        
        print(f"  Added {len(api_endpoints)} API endpoints")
        print(f"  Added {len(api_calls)} API calls")
        print(f"  Total nodes: {len(nodes)}")
        print(f"  Total relationships: {len(relationships)}")
        
        return parsing_data
    
    def _detect_frameworks_from_nodes(self, nodes: List[Dict]) -> List[str]:
        """Detect frameworks based on annotations and imports"""
        detected = []
        
        # Collect all annotations and imports
        all_annotations = set()
        all_imports = set()
        
        for node in nodes:
            if node['node_type'] == 'Class':
                annotations = node['properties'].get('annotations', [])
                all_annotations.update(annotations)
            elif node['node_type'] == 'File':
                imports = node['properties'].get('imports', [])
                all_imports.update(imports)
        
        # Check framework patterns
        for framework, patterns in self.framework_patterns.items():
            # Check annotations
            if any(ann in all_annotations for ann in patterns['annotations']):
                detected.append(framework)
                continue
            
            # Check imports
            if any(any(imp.startswith(pattern) for pattern in patterns['imports']) for imp in all_imports):
                detected.append(framework)
        
        return detected
    
    def _detect_spring_endpoints(self, nodes: List[Dict], relationships: List[Dict]) -> tuple:
        """Detect Spring Boot REST endpoints"""
        endpoints = []
        calls = []
        
        # Find controller classes
        controller_classes = [
            node for node in nodes 
            if node['node_type'] == 'Class' and 
            any(ann in ['@RestController', '@Controller'] for ann in node['properties'].get('annotations', []))
        ]
        
        for controller in controller_classes:
            # Find methods in controller
            controller_methods = [
                node for node in nodes
                if node['node_type'] == 'Method' and 
                node['properties'].get('class_name') == controller['name']
            ]
            
            for method in controller_methods:
                annotations = method['properties'].get('annotations', [])
                
                # Check for mapping annotations
                for ann in annotations:
                    if ann.startswith('@') and 'Mapping' in ann:
                        endpoint = self._parse_endpoint_annotation(ann, method, controller)
                        if endpoint:
                            endpoints.append(endpoint)
        
        return endpoints, calls
    
    def _parse_endpoint_annotation(self, annotation: str, method: Dict, controller: Dict) -> Dict:
        """Parse endpoint annotation to extract HTTP method and path"""
        # Simple parsing - in real implementation, use proper annotation parsing
        http_method = 'GET'  # default
        path = f"/{method['name'].lower()}"  # default
        
        if '@GetMapping' in annotation:
            http_method = 'GET'
        elif '@PostMapping' in annotation:
            http_method = 'POST'
        elif '@PutMapping' in annotation:
            http_method = 'PUT'
        elif '@DeleteMapping' in annotation:
            http_method = 'DELETE'
        
        # Extract path from annotation (simplified)
        if '(' in annotation and ')' in annotation:
            content = annotation[annotation.find('(') + 1:annotation.find(')')]
            if '"' in content:
                path = content.strip('"').strip("'")
        
        return {
            'method': http_method,
            'path': path,
            'controller': controller['name'],
            'handler_method': method['name'],
            'method_id': method['node_id']
        }
    
    def _detect_repository_calls(self, nodes: List[Dict], relationships: List[Dict]) -> List[Dict]:
        """Detect Spring Data repository calls"""
        calls = []
        
        # Find repository interfaces
        repositories = [
            node for node in nodes
            if node['node_type'] == 'Interface' and
            any(ann in ['@Repository'] for ann in node['properties'].get('annotations', []))
        ]
        
        # Find calls to repository methods
        for rel in relationships:
            if rel['relationship_type'] == 'CALLS':
                target_node = next((n for n in nodes if n['node_id'] == rel['target_id']), None)
                source_node = next((n for n in nodes if n['node_id'] == rel['source_id']), None)
                
                if target_node and source_node:
                    # Check if target is a repository method
                    target_class = target_node['properties'].get('class_name', '')
                    if any(repo['name'] == target_class for repo in repositories):
                        calls.append({
                            'type': 'REPOSITORY_CALL',
                            'target': target_node['name'],
                            'source_method': source_node['name'],
                            'source_id': rel['source_id']
                        })
        
        return calls
    
    def save_results(self, parsing_data: Dict[str, Any], output_path: str):
        """Save updated parsing results"""
        os.makedirs(output_path, exist_ok=True)
        
        parsing_file = os.path.join(output_path, "parsing.json")
        with open(parsing_file, 'w', encoding='utf-8') as f:
            json.dump(parsing_data, f, indent=2, ensure_ascii=False)
        
        print(f"Agent 3 Complete: Updated parsing.json with framework detection")

if __name__ == "__main__":
    detector = FrameworkDetector()
    
    # Test framework detection
    output_path = "output"
    parsing_file = os.path.join(output_path, "parsing.json")
    if os.path.exists(parsing_file):
        parsing_data = detector.detect_frameworks(output_path)
        detector.save_results(parsing_data, output_path)
    else:
        print("Run Agent 2 first to create parsing.json")

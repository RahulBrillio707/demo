#!/usr/bin/env python3
"""
Agent 2: AST-based Parser and Method Chunking
Uses javalang for accurate Java AST parsing instead of regex
"""

import os
import json
import uuid
from typing import Dict, List, Any, Tuple
import javalang
import re

class JavaASTParser:
    """AST-based parser using javalang for accurate Java parsing"""
    
    def __init__(self):
        self.node_types = {
            'APPLICATION': 'Application',
            'PACKAGE': 'Package', 
            'FILE': 'File',
            'CLASS': 'Class',
            'INTERFACE': 'Interface',
            'METHOD': 'Method',
            'FIELD': 'Field',
            'PARAMETER': 'Parameter',
            'DATABASE': 'Database',
            'CONFIG': 'Config'
        }
        
        self.relationship_types = {
            'CONTAINS': 'contains',
            'HAS_PARAMETER': 'has_parameter',
            'HAS_FIELD': 'has_field',
            'EXTENDS': 'extends',
            'IMPLEMENTS': 'implements'
        }
    
    def parse_repository(self, repo_path: str) -> Dict[str, Any]:
        """Parse repository using AST-based approach"""
        print("Agent 2: Starting AST parsing and method chunking")
        
        # Collect all files
        files = self._collect_files(repo_path)
        
        # Initialize data structures
        all_chunks = []
        all_nodes = []
        all_relationships = []
        
        # Create application node
        app_name = os.path.basename(repo_path)
        app_node = self._create_node(
            self.node_types['APPLICATION'],
            app_name,
            {'repository_path': repo_path}
        )
        all_nodes.append(app_node)
        
        # Process each file
        for file_info in files:
            print(f"  Processing {file_info['relative_path']} ({file_info['type']})")
            
            if file_info['type'] == 'java':
                chunks, nodes, relationships = self._parse_java_file_ast(file_info, app_node['node_id'])
            elif file_info['type'] == 'sql':
                chunks, nodes, relationships = self._parse_sql_file(file_info, app_node['node_id'])
            elif file_info['type'] == 'config':
                chunks, nodes, relationships = self._parse_config_file(file_info, app_node['node_id'])
            else:
                continue
                
            all_chunks.extend(chunks)
            all_nodes.extend(nodes)
            all_relationships.extend(relationships)
        
        print(f"  Created {len(all_chunks)} method chunks")
        print(f"  Extracted {len(all_nodes)} nodes")
        print(f"  Found {len(all_relationships)} relationships")
        
        return {
            'repository_path': repo_path,
            'total_chunks': len(all_chunks),
            'method_chunks': all_chunks,
            'total_nodes': len(all_nodes),
            'nodes': all_nodes,
            'total_relationships': len(all_relationships),
            'relationships': all_relationships
        }
    
    def _parse_java_file_ast(self, file_info: Dict, app_id: str) -> Tuple[List[Dict], List[Dict], List[Dict]]:
        """Parse Java file using AST"""
        chunks = []
        nodes = []
        relationships = []
        
        try:
            with open(file_info['path'], 'r', encoding='utf-8') as f:
                content = f.read()

            # Pre-process content to handle triple-quoted strings that javalang can't parse
            processed_content = self._preprocess_java_content(content)

            # Parse with javalang
            tree = javalang.parse.parse(processed_content)
            
            # Create FILE node
            file_node = self._create_node(
                self.node_types['FILE'],
                file_info['name'],
                {
                    'file_path': file_info['relative_path'],
                    'file_type': 'java',
                    'size': len(content)
                }
            )
            nodes.append(file_node)
            
            # APPLICATION CONTAINS FILE
            relationships.append(self._create_relationship(
                app_id, file_node['node_id'], self.relationship_types['CONTAINS']
            ))
            
            # Extract package
            package_name = tree.package.name if tree.package else ''
            package_node_id = None
            
            if package_name:
                package_node = self._create_node(
                    self.node_types['PACKAGE'],
                    package_name,
                    {'full_name': package_name}
                )
                nodes.append(package_node)
                package_node_id = package_node['node_id']
                
                # PACKAGE CONTAINS FILE
                relationships.append(self._create_relationship(
                    package_node_id, file_node['node_id'], self.relationship_types['CONTAINS']
                ))
            
            # Process classes
            for path, class_node in tree.filter(javalang.tree.ClassDeclaration):
                class_chunks, class_nodes, class_rels = self._process_class_ast(
                    class_node, content, file_info, file_node['node_id'], package_name
                )
                chunks.extend(class_chunks)
                nodes.extend(class_nodes)
                relationships.extend(class_rels)
            
            # Process interfaces
            for path, interface_node in tree.filter(javalang.tree.InterfaceDeclaration):
                interface_chunks, interface_nodes, interface_rels = self._process_interface_ast(
                    interface_node, content, file_info, file_node['node_id'], package_name
                )
                chunks.extend(interface_chunks)
                nodes.extend(interface_nodes)
                relationships.extend(interface_rels)
                
        except Exception as e:
            print(f"    ⚠️  AST parsing failed for {file_info['name']}: {e}")
            # Fallback to regex-based parsing for problematic files
            chunks, nodes, relationships = self._parse_java_file_fallback(file_info, app_id, content)

        return chunks, nodes, relationships

    def _parse_java_file_fallback(self, file_info: Dict, app_id: str, content: str) -> Tuple[List[Dict], List[Dict], List[Dict]]:
        """Fallback regex-based parsing for files that AST can't handle"""
        chunks = []
        nodes = []
        relationships = []

        # Create FILE node
        file_node = self._create_node(
            self.node_types['FILE'],
            file_info['name'],
            {
                'file_path': file_info['relative_path'],
                'file_type': 'java',
                'parsing_method': 'fallback_regex',
                'size': len(content)
            }
        )
        nodes.append(file_node)

        # APPLICATION CONTAINS FILE
        relationships.append(self._create_relationship(
            app_id, file_node['node_id'], self.relationship_types['CONTAINS']
        ))

        # Extract package name
        package_match = re.search(r'package\s+([\w.]+);', content)
        package_name = package_match.group(1) if package_match else ''

        # Extract interfaces (for repository files)
        interface_pattern = r'(?:public\s+)?interface\s+(\w+)'
        interface_matches = re.findall(interface_pattern, content)

        for interface_name in interface_matches:
            # Create INTERFACE node
            interface_node = self._create_node(
                self.node_types['INTERFACE'],
                interface_name,
                {
                    'file_path': file_info['relative_path'],
                    'package_name': package_name,
                    'full_name': f"{package_name}.{interface_name}" if package_name else interface_name,
                    'parsing_method': 'fallback_regex'
                }
            )
            nodes.append(interface_node)

            # FILE CONTAINS INTERFACE
            relationships.append(self._create_relationship(
                file_node['node_id'], interface_node['node_id'], self.relationship_types['CONTAINS']
            ))

            # Extract interface methods (simplified)
            method_pattern = r'(\w+(?:<[^>]+>)?|\w+\[\])\s+(\w+)\s*\([^)]*\);'
            method_matches = re.findall(method_pattern, content)

            for return_type, method_name in method_matches:
                # Skip if it looks like a field or annotation
                if method_name in ['interface', 'class', 'extends', 'implements']:
                    continue

                # Create METHOD node
                method_node = self._create_node(
                    self.node_types['METHOD'],
                    method_name,
                    {
                        'class_name': interface_name,
                        'return_type': return_type,
                        'file_path': file_info['relative_path'],
                        'is_interface_method': True,
                        'parsing_method': 'fallback_regex'
                    }
                )
                nodes.append(method_node)

                # INTERFACE CONTAINS METHOD
                relationships.append(self._create_relationship(
                    interface_node['node_id'], method_node['node_id'], self.relationship_types['CONTAINS']
                ))

                # Create basic method chunk (no body for interface methods)
                chunk = {
                    'chunk_id': method_node['node_id'],
                    'file_path': file_info['relative_path'],
                    'method_name': method_name,
                    'class_name': interface_name,
                    'content': f"// Interface method: {return_type} {method_name}(...);",
                    'variables': [],
                    'operations': [],
                    'dependencies': []
                }
                chunks.append(chunk)
        
        return chunks, nodes, relationships
    
    def _process_class_ast(self, class_node, content: str, file_info: Dict, file_node_id: str, package_name: str) -> Tuple[List[Dict], List[Dict], List[Dict]]:
        """Process a class using AST"""
        chunks = []
        nodes = []
        relationships = []
        
        class_name = class_node.name
        
        # Create CLASS node
        class_ast_node = self._create_node(
            self.node_types['CLASS'],
            class_name,
            {
                'file_path': file_info['relative_path'],
                'package_name': package_name,
                'full_name': f"{package_name}.{class_name}" if package_name else class_name,
                'modifiers': list(class_node.modifiers) if class_node.modifiers else []
            }
        )
        nodes.append(class_ast_node)
        
        # FILE CONTAINS CLASS
        relationships.append(self._create_relationship(
            file_node_id, class_ast_node['node_id'], self.relationship_types['CONTAINS']
        ))
        
        # Process methods
        for method_path, method_node in class_node.filter(javalang.tree.MethodDeclaration):
            method_chunks, method_nodes, method_rels = self._process_method_ast(
                method_node, content, file_info, class_ast_node['node_id'], class_name
            )
            chunks.extend(method_chunks)
            nodes.extend(method_nodes)
            relationships.extend(method_rels)
        
        # Process fields
        for field_path, field_node in class_node.filter(javalang.tree.FieldDeclaration):
            field_nodes, field_rels = self._process_field_ast(
                field_node, class_ast_node['node_id']
            )
            nodes.extend(field_nodes)
            relationships.extend(field_rels)
        
        return chunks, nodes, relationships

    def _process_method_ast(self, method_node, content: str, file_info: Dict, class_id: str, class_name: str) -> Tuple[List[Dict], List[Dict], List[Dict]]:
        """Process a method using AST"""
        chunks = []
        nodes = []
        relationships = []

        method_name = method_node.name
        return_type = method_node.return_type.name if method_node.return_type else "void"
        modifiers = list(method_node.modifiers) if method_node.modifiers else []

        # Extract method body content
        method_content = self._extract_method_content_ast(method_node, content)

        # Create METHOD node
        method_ast_node = self._create_node(
            self.node_types['METHOD'],
            method_name,
            {
                'class_name': class_name,
                'return_type': return_type,
                'modifiers': modifiers,
                'file_path': file_info['relative_path'],
                'is_static': 'static' in modifiers,
                'visibility': self._get_visibility(modifiers)
            }
        )
        nodes.append(method_ast_node)

        # CLASS CONTAINS METHOD
        relationships.append(self._create_relationship(
            class_id, method_ast_node['node_id'], self.relationship_types['CONTAINS']
        ))

        # Create method chunk
        chunk = {
            'chunk_id': method_ast_node['node_id'],
            'file_path': file_info['relative_path'],
            'method_name': method_name,
            'class_name': class_name,
            'content': method_content,
            'variables': self._extract_variables_from_content(method_content),
            'operations': self._extract_operations_from_content(method_content),
            'dependencies': []
        }
        chunks.append(chunk)

        # Process parameters
        if method_node.parameters:
            for param in method_node.parameters:
                param_node = self._create_node(
                    self.node_types['PARAMETER'],
                    param.name,
                    {
                        'data_type': param.type.name if hasattr(param.type, 'name') else str(param.type),
                        'method_name': method_name
                    }
                )
                nodes.append(param_node)

                # METHOD HAS PARAMETER
                relationships.append(self._create_relationship(
                    method_ast_node['node_id'], param_node['node_id'], self.relationship_types['HAS_PARAMETER']
                ))

        return chunks, nodes, relationships

    def _process_field_ast(self, field_node, class_id: str) -> Tuple[List[Dict], List[Dict]]:
        """Process a field using AST"""
        nodes = []
        relationships = []

        field_type = field_node.type.name if hasattr(field_node.type, 'name') else str(field_node.type)
        modifiers = list(field_node.modifiers) if field_node.modifiers else []

        for declarator in field_node.declarators:
            field_name = declarator.name

            # Create FIELD node
            field_ast_node = self._create_node(
                self.node_types['FIELD'],
                field_name,
                {
                    'data_type': field_type,
                    'modifiers': modifiers,
                    'is_static': 'static' in modifiers,
                    'visibility': self._get_visibility(modifiers)
                }
            )
            nodes.append(field_ast_node)

            # CLASS HAS FIELD
            relationships.append(self._create_relationship(
                class_id, field_ast_node['node_id'], self.relationship_types['HAS_FIELD']
            ))

        return nodes, relationships

    def _process_interface_ast(self, interface_node, content: str, file_info: Dict, file_node_id: str, package_name: str) -> Tuple[List[Dict], List[Dict], List[Dict]]:
        """Process an interface using AST"""
        chunks = []
        nodes = []
        relationships = []

        interface_name = interface_node.name

        # Create INTERFACE node
        interface_ast_node = self._create_node(
            self.node_types['INTERFACE'],
            interface_name,
            {
                'file_path': file_info['relative_path'],
                'package_name': package_name,
                'full_name': f"{package_name}.{interface_name}" if package_name else interface_name
            }
        )
        nodes.append(interface_ast_node)

        # FILE CONTAINS INTERFACE
        relationships.append(self._create_relationship(
            file_node_id, interface_ast_node['node_id'], self.relationship_types['CONTAINS']
        ))

        # Process interface methods
        for method_path, method_node in interface_node.filter(javalang.tree.MethodDeclaration):
            method_chunks, method_nodes, method_rels = self._process_method_ast(
                method_node, content, file_info, interface_ast_node['node_id'], interface_name
            )
            chunks.extend(method_chunks)
            nodes.extend(method_nodes)
            relationships.extend(method_rels)

        return chunks, nodes, relationships

    def _preprocess_java_content(self, content: str) -> str:
        """Preprocess Java content to handle constructs that javalang can't parse"""
        # Replace triple-quoted strings with regular quoted strings
        # This handles SQL queries in @Query annotations
        processed = re.sub(r'"""(.*?)"""', lambda m: '"' + m.group(1).replace('\n', '\\n').replace('"', '\\"') + '"', content, flags=re.DOTALL)
        return processed

    def _extract_method_content_ast(self, method_node, content: str) -> str:
        """Extract method body content using AST position info"""
        try:
            # Get method position from AST
            if hasattr(method_node, 'position') and method_node.position:
                start_line = method_node.position.line - 1
                # Find method body by looking for opening brace
                lines = content.split('\n')
                method_start = start_line

                # Find the opening brace
                brace_count = 0
                method_lines = []
                in_method_body = False

                for i in range(method_start, len(lines)):
                    line = lines[i]
                    if '{' in line and not in_method_body:
                        in_method_body = True
                        # Start collecting from the line after opening brace
                        brace_count += line.count('{')
                        brace_count -= line.count('}')
                        continue

                    if in_method_body:
                        brace_count += line.count('{')
                        brace_count -= line.count('}')

                        if brace_count > 0:
                            method_lines.append(line.strip())
                        else:
                            break

                return '\n'.join(method_lines)
            else:
                # Fallback: extract by method name
                return self._extract_method_by_name_fallback(content, method_node.name)

        except Exception:
            return self._extract_method_by_name_fallback(content, method_node.name)

    def _extract_method_by_name_fallback(self, content: str, method_name: str) -> str:
        """Fallback method extraction by name"""
        lines = content.split('\n')
        for i, line in enumerate(lines):
            if method_name in line and '(' in line and '{' in line:
                # Simple extraction - get next few lines
                method_lines = []
                brace_count = 0
                for j in range(i, len(lines)):
                    current_line = lines[j]
                    brace_count += current_line.count('{')
                    brace_count -= current_line.count('}')

                    if j > i:  # Skip the method declaration line
                        method_lines.append(current_line.strip())

                    if brace_count == 0 and j > i:
                        break

                return '\n'.join(method_lines[:-1])  # Remove closing brace line

        return ""

    def _extract_variables_from_content(self, content: str) -> List[str]:
        """Extract variable names from method content (improved version)"""
        variables = []

        # Comprehensive variable extraction patterns
        patterns = [
            # Variable declarations
            r'(\w+)\s+(\w+)\s*=',  # Type var =
            r'(\w+)\s+(\w+);',     # Type var;
            r'for\s*\(\s*\w+\s+(\w+)',  # for loop variables

            # Field assignments and access
            r'this\.(\w+)\s*=',    # this.field =
            r'this\.(\w+)',        # this.field access

            # Simple assignments
            r'(\w+)\s*=\s*[^=]',   # variable = (not ==)
            r'=\s*(\w+)',          # = variable

            # Method calls and parameters
            r'(\w+)\.',            # object.method
            r'\.(\w+)\(',          # .method(
            r'\((\w+)\)',          # (parameter)
            r'\((\w+),',           # (param1,
            r',\s*(\w+)',          # , param

            # Return statements
            r'return\s+(\w+)',     # return variable

            # Common Java patterns
            r'new\s+\w+\((\w+)',   # new Type(param)
            r'(\w+)\[',            # array[index]
        ]

        for pattern in patterns:
            matches = re.findall(pattern, content)
            for match in matches:
                if isinstance(match, tuple):
                    # For tuple matches, add all non-empty groups
                    for group in match:
                        if group and group.isalpha() and len(group) > 1:
                            variables.append(group)
                else:
                    if match and match.isalpha() and len(match) > 1:
                        variables.append(match)

        # Filter out Java keywords and common non-variables
        java_keywords = {
            'public', 'private', 'protected', 'static', 'final', 'abstract',
            'class', 'interface', 'extends', 'implements', 'import', 'package',
            'if', 'else', 'for', 'while', 'do', 'switch', 'case', 'default',
            'try', 'catch', 'finally', 'throw', 'throws', 'return', 'new',
            'this', 'super', 'null', 'true', 'false', 'void', 'int', 'long',
            'double', 'float', 'boolean', 'char', 'byte', 'short', 'String',
            'List', 'Map', 'Set', 'Optional', 'ResponseEntity', 'HttpStatus'
        }

        variables = [var for var in variables if var not in java_keywords]
        return list(set(variables))

    def _extract_operations_from_content(self, content: str) -> List[str]:
        """Extract operations from method content"""
        operations = []

        if 'return' in content:
            operations.append('RETURN')
        if '=' in content and not '==' in content:
            operations.append('ASSIGNMENT')
        if '.save(' in content or '.persist(' in content:
            operations.append('SAVE')
        if '.find(' in content or '.get(' in content:
            operations.append('READ')
        if '.delete(' in content:
            operations.append('DELETE')
        if '@' in content:
            operations.append('ANNOTATION')

        return operations

    def _get_visibility(self, modifiers: List[str]) -> str:
        """Get visibility from modifiers"""
        if 'public' in modifiers:
            return 'public'
        elif 'private' in modifiers:
            return 'private'
        elif 'protected' in modifiers:
            return 'protected'
        else:
            return 'package'

    def _collect_files(self, repo_path: str) -> List[Dict]:
        """Collect all relevant files from repository"""
        files = []

        for root, dirs, filenames in os.walk(repo_path):
            # Skip common non-source directories
            dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ['target', 'build', 'node_modules']]

            for filename in filenames:
                file_path = os.path.join(root, filename)
                relative_path = os.path.relpath(file_path, repo_path)

                file_type = self._get_file_type(filename)
                if file_type:
                    files.append({
                        'name': filename,
                        'path': file_path,
                        'relative_path': relative_path.replace('\\', '/'),
                        'type': file_type
                    })

        return files

    def _get_file_type(self, filename: str) -> str:
        """Determine file type"""
        if filename.endswith('.java'):
            return 'java'
        elif filename.endswith('.sql'):
            return 'sql'
        elif filename in ['pom.xml', 'build.gradle', 'application.yml', 'application.properties', 'application-dev.properties']:
            return 'config'
        else:
            return None

    def _parse_sql_file(self, file_info: Dict, app_id: str) -> Tuple[List[Dict], List[Dict], List[Dict]]:
        """Parse SQL file (simplified)"""
        chunks = []
        nodes = []
        relationships = []

        try:
            with open(file_info['path'], 'r', encoding='utf-8') as f:
                content = f.read()

            # Create DATABASE node
            db_node = self._create_node(
                self.node_types['DATABASE'],
                file_info['name'],
                {
                    'file_path': file_info['relative_path'],
                    'file_type': 'sql'
                }
            )
            nodes.append(db_node)

            # APPLICATION CONTAINS DATABASE
            relationships.append(self._create_relationship(
                app_id, db_node['node_id'], self.relationship_types['CONTAINS']
            ))

            # Create SQL chunk
            chunk = {
                'chunk_id': db_node['node_id'],
                'file_path': file_info['relative_path'],
                'method_name': 'SQL_SCRIPT',
                'class_name': 'DATABASE',
                'content': content,
                'variables': [],
                'operations': self._extract_sql_operations(content),
                'dependencies': []
            }
            chunks.append(chunk)

        except Exception as e:
            print(f"    ⚠️  SQL parsing failed for {file_info['name']}: {e}")

        return chunks, nodes, relationships

    def _parse_config_file(self, file_info: Dict, app_id: str) -> Tuple[List[Dict], List[Dict], List[Dict]]:
        """Parse configuration file"""
        chunks = []
        nodes = []
        relationships = []

        try:
            with open(file_info['path'], 'r', encoding='utf-8') as f:
                content = f.read()

            # Create CONFIG node
            config_node = self._create_node(
                self.node_types['CONFIG'],
                file_info['name'],
                {
                    'file_path': file_info['relative_path'],
                    'file_type': 'config'
                }
            )
            nodes.append(config_node)

            # APPLICATION CONTAINS CONFIG
            relationships.append(self._create_relationship(
                app_id, config_node['node_id'], self.relationship_types['CONTAINS']
            ))

        except Exception as e:
            print(f"    ⚠️  Config parsing failed for {file_info['name']}: {e}")

        return chunks, nodes, relationships

    def _extract_sql_operations(self, content: str) -> List[str]:
        """Extract SQL operations"""
        operations = []
        content_upper = content.upper()

        if 'CREATE' in content_upper:
            operations.append('CREATE')
        if 'SELECT' in content_upper:
            operations.append('SELECT')
        if 'INSERT' in content_upper:
            operations.append('INSERT')
        if 'UPDATE' in content_upper:
            operations.append('UPDATE')
        if 'DELETE' in content_upper:
            operations.append('DELETE')

        return operations

    def _create_node(self, node_type: str, name: str, properties: Dict = None) -> Dict:
        """Create a node"""
        return {
            'node_id': str(uuid.uuid4()),
            'node_type': node_type,
            'name': name,
            'properties': properties or {}
        }

    def _create_relationship(self, source_id: str, target_id: str, relationship_type: str) -> Dict:
        """Create a relationship"""
        return {
            'relationship_id': str(uuid.uuid4()),
            'source_id': source_id,
            'target_id': target_id,
            'relationship_type': relationship_type,
            'properties': {}
        }

    def save_results(self, data: Dict[str, Any], output_path: str):
        """Save parsing results"""
        os.makedirs(output_path, exist_ok=True)

        # Save chunks
        chunks_data = {
            'repository_path': data['repository_path'],
            'total_chunks': data['total_chunks'],
            'method_chunks': data['method_chunks']
        }

        chunks_file = os.path.join(output_path, "chunks.json")
        with open(chunks_file, 'w', encoding='utf-8') as f:
            json.dump(chunks_data, f, indent=2, ensure_ascii=False)

        # Save parsing data
        parsing_data = {
            'repository_path': data['repository_path'],
            'total_nodes': data['total_nodes'],
            'nodes': data['nodes'],
            'total_relationships': data['total_relationships'],
            'relationships': data['relationships']
        }

        parsing_file = os.path.join(output_path, "parsing.json")
        with open(parsing_file, 'w', encoding='utf-8') as f:
            json.dump(parsing_data, f, indent=2, ensure_ascii=False)

        print(f"Agent 2 Complete: Saved chunks.json and parsing.json")


if __name__ == "__main__":
    parser = JavaASTParser()

    # Test AST-based parsing
    repo_path = "test_projects/swiggy_backend"
    if os.path.exists(repo_path):
        data = parser.parse_repository(repo_path)
        parser.save_results(data, "output")
    else:
        print("Repository path not found. Update the path in the script.")

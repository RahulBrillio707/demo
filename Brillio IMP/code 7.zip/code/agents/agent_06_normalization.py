"""
Agent 6: Data Normalization Agent
Combines parsing.json with variable_transformations.json to create final_lineage.json
"""

import os
import json
from typing import Dict, List, Any

class DataNormalizer:
    """Normalizes and combines parsing data with variable transformations"""
    
    def __init__(self):
        pass
    
    def normalize_data(self, parsing_file: str, transformations_file: str) -> Dict[str, Any]:
        """
        Combine parsing data with variable transformations

        Args:
            parsing_file: Path to parsing.json from Agent 3
            transformations_file: Path to variable_transformations.json from Agent 5

        Returns:
            Combined lineage data
        """
        print("Agent 6: Normalizing data and creating final lineage")

        # Load transformation data
        with open(transformations_file, 'r', encoding='utf-8') as f:
            transformation_data = json.load(f)

        # Check if we have merged lineage from Agent 5
        if 'merged_lineage' in transformation_data and transformation_data['merged_lineage']:
            print("  Using merged lineage from Agent 5")
            merged_data = transformation_data['merged_lineage']
            nodes = merged_data['nodes']
            relationships = merged_data['relationships']
            transformations = transformation_data['transformations']
        else:
            print("  Using separate parsing and transformation files")
            # Load parsing data
            with open(parsing_file, 'r', encoding='utf-8') as f:
                parsing_data = json.load(f)

            # Get base data
            nodes = parsing_data['nodes']
            relationships = parsing_data['relationships']
            transformations = transformation_data['transformations']
        
        # Create method-to-transformation mapping
        method_transformations = {}
        for trans in transformations:
            method_id = trans['method_id']
            if method_id not in method_transformations:
                method_transformations[method_id] = []
            method_transformations[method_id].append(trans)

        # If we already have merged data, use it directly, otherwise enhance
        if 'merged_lineage' in transformation_data and transformation_data['merged_lineage']:
            print("  Using pre-merged nodes and relationships")
            enhanced_nodes = nodes  # Already merged
            all_relationships = relationships  # Already merged
            transformation_relationships = []  # No additional relationships needed
        else:
            print("  Enhancing nodes and creating transformation relationships")
            # Enhance nodes with transformation data
            enhanced_nodes = self._enhance_nodes_with_transformations(nodes, method_transformations)

            # Create transformation relationships
            transformation_relationships = self._create_transformation_relationships(transformations, nodes)

            # Combine all relationships
            all_relationships = relationships + transformation_relationships
        
        # Create final lineage structure
        final_lineage = {
            'repository_path': transformation_data.get('repository_path', ''),
            'metadata': {
                'total_nodes': len(enhanced_nodes),
                'total_relationships': len(all_relationships),
                'total_transformations': len(transformations),
                'total_variable_nodes': transformation_data.get('total_variable_nodes', 0),
                'total_variable_relationships': transformation_data.get('total_variable_relationships', 0),
                'analysis_method': transformation_data.get('analysis_method', 'Unknown'),
                'merge_stats': transformation_data.get('merged_lineage', {}).get('merge_stats', {})
            },
            'nodes': enhanced_nodes,
            'relationships': all_relationships,
            'method_flows': self._create_method_flows(method_transformations, enhanced_nodes),
            'data_lineage_summary': self._create_lineage_summary(transformations, enhanced_nodes)
        }
        
        print(f"  Enhanced {len(enhanced_nodes)} nodes")
        print(f"  Created {len(transformation_relationships)} transformation relationships")
        print(f"  Total relationships: {len(all_relationships)}")
        print(f"  Method flows: {len(final_lineage['method_flows'])}")
        
        return final_lineage
    
    def _enhance_nodes_with_transformations(self, nodes: List[Dict], method_transformations: Dict) -> List[Dict]:
        """Enhance method nodes with transformation data"""
        enhanced_nodes = []
        
        for node in nodes:
            enhanced_node = node.copy()
            
            # Add transformation data to method nodes
            if node['node_type'] == 'Method' and node['node_id'] in method_transformations:
                transformations = method_transformations[node['node_id']]
                enhanced_node['properties']['transformations'] = len(transformations)
                # Handle new transformation structure
                analysis_types = list(set(t.get('analysis_type', 'unknown') for t in transformations))
                enhanced_node['properties']['analysis_types'] = analysis_types
                confidences = [t.get('confidence', 0.5) for t in transformations if 'confidence' in t]
                enhanced_node['properties']['avg_confidence'] = sum(confidences) / len(confidences) if confidences else 0.5
            
            enhanced_nodes.append(enhanced_node)
        
        return enhanced_nodes
    
    def _create_transformation_relationships(self, transformations: List[Dict], nodes: List[Dict]) -> List[Dict]:
        """Create relationships for variable transformations"""
        relationships = []
        
        # Create node lookup
        node_lookup = {node['node_id']: node for node in nodes}
        
        for trans in transformations:
            # Create transformation relationship for new structure
            rel = {
                'relationship_id': f"trans_rel_{trans['transformation_id']}",
                'source_id': trans['method_id'],
                'target_id': trans['method_id'],  # Self-reference for internal transformation
                'relationship_type': 'HAS_TRANSFORMATION',
                'properties': {
                    'transformation_id': trans['transformation_id'],
                    'analysis_type': trans.get('analysis_type', 'unknown'),
                    'method_name': trans.get('method_name', ''),
                    'class_name': trans.get('class_name', ''),
                    'confidence': trans.get('confidence', 0.5),
                    'variable_nodes': len(trans.get('nodes', [])),
                    'variable_relationships': len(trans.get('relationships', []))
                }
            }
            relationships.append(rel)
        
        return relationships
    
    def _find_method_by_name(self, method_name: str, nodes: List[Dict]) -> Dict:
        """Find method node by name"""
        if not method_name:
            return None

        for node in nodes:
            if node['node_type'] == 'Method' and node.get('name') and method_name in node['name']:
                return node
        return None
    
    def _create_method_flows(self, method_transformations: Dict, nodes: List[Dict]) -> Dict:
        """Create method flow summaries"""
        method_flows = {}
        
        for method_id, transformations in method_transformations.items():
            method_node = next((n for n in nodes if n['node_id'] == method_id), None)
            if not method_node:
                continue
            
            # Group transformations by analysis type
            trans_by_type = {}
            for trans in transformations:
                analysis_type = trans.get('analysis_type', 'unknown')
                if analysis_type not in trans_by_type:
                    trans_by_type[analysis_type] = []
                trans_by_type[analysis_type].append(trans)

            # Calculate confidence
            confidences = [t.get('confidence', 0.5) for t in transformations if 'confidence' in t]
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0.5

            method_flows[method_id] = {
                'method_name': method_node['name'],
                'class_name': method_node['properties'].get('class_name', ''),
                'total_transformations': len(transformations),
                'analysis_types': trans_by_type,
                'avg_confidence': avg_confidence,
                'variable_nodes': sum(len(t.get('nodes', [])) for t in transformations),
                'variable_relationships': sum(len(t.get('relationships', [])) for t in transformations)
            }
        
        return method_flows
    
    def _create_lineage_summary(self, transformations: List[Dict], nodes: List[Dict]) -> Dict:
        """Create data lineage summary"""
        # Count analysis types
        analysis_types = {}
        for trans in transformations:
            analysis_type = trans.get('analysis_type', 'unknown')
            analysis_types[analysis_type] = analysis_types.get(analysis_type, 0) + 1

        # Calculate confidence
        confidences = [t.get('confidence', 0.5) for t in transformations if 'confidence' in t]
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0.5

        # Count variable nodes and relationships
        total_var_nodes = sum(len(t.get('nodes', [])) for t in transformations)
        total_var_relationships = sum(len(t.get('relationships', [])) for t in transformations)

        return {
            'total_transformations': len(transformations),
            'analysis_types': analysis_types,
            'avg_confidence': avg_confidence,
            'total_variable_nodes': total_var_nodes,
            'total_variable_relationships': total_var_relationships,
            'methods_with_transformations': len(set(t['method_id'] for t in transformations))
        }
    
    def _find_flow_chains(self, transformations: List[Dict], nodes: List[Dict]) -> List[Dict]:
        """Find chains of data flow between methods"""
        chains = []
        
        # Group transformations by method
        method_trans = {}
        for trans in transformations:
            method_id = trans['method_id']
            if method_id not in method_trans:
                method_trans[method_id] = []
            method_trans[method_id].append(trans)
        
        # Simple chain detection (can be enhanced)
        for method_id, trans_list in method_trans.items():
            if len(trans_list) > 1:
                chains.append({
                    'method_id': method_id,
                    'chain_length': len(trans_list),
                    'transformations': [t['transformation_id'] for t in trans_list]
                })
        
        return chains
    
    def save_final_lineage(self, lineage_data: Dict[str, Any], output_path: str):
        """Save final lineage data"""
        os.makedirs(output_path, exist_ok=True)
        
        output_file = os.path.join(output_path, "final_lineage.json")
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(lineage_data, f, indent=2, ensure_ascii=False)
        
        print(f"Agent 6 Complete: Saved final_lineage.json")

if __name__ == "__main__":
    normalizer = DataNormalizer()
    
    # Test normalization
    parsing_file = "output/parsing.json"
    transformations_file = "output/variable_transformations.json"
    
    if os.path.exists(parsing_file) and os.path.exists(transformations_file):
        lineage_data = normalizer.normalize_data(parsing_file, transformations_file)
        normalizer.save_final_lineage(lineage_data, "output")
    else:
        print("Run previous agents first to create required input files")

"""
Agent 1: File Collection Agent
Collects all files (Java, SQL, Config, YAML, etc.) from repository
"""

import os
import json
import hashlib
from pathlib import Path
from typing import List, Dict, Any
from datetime import datetime

class FileCollector:
    """Collects all files from repository and categorizes them"""
    
    def __init__(self):
        self.supported_extensions = {
            'java': ['.java'],
            'sql': ['.sql'],
            'config': ['.yml', '.yaml', '.properties', '.xml', '.json'],
            'other': []
        }
    
    def collect_files(self, repo_path: str) -> Dict[str, Any]:
        """
        Collect all files from repository
        
        Args:
            repo_path: Path to repository
            
        Returns:
            Dictionary with categorized files
        """
        print(f"Agent 1: Collecting files from {repo_path}")
        
        all_files = []
        file_stats = {
            'java': 0,
            'sql': 0, 
            'config': 0,
            'other': 0
        }
        
        # Walk through all files
        for root, dirs, files in os.walk(repo_path):
            # Skip hidden directories and common build directories
            dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ['target', 'build', 'node_modules']]
            
            for file in files:
                if file.startswith('.'):
                    continue
                    
                file_path = os.path.join(root, file)
                relative_path = os.path.relpath(file_path, repo_path)
                
                # Determine file type
                file_ext = Path(file).suffix.lower()
                file_type = self._get_file_type(file_ext)
                
                # Get file metadata
                file_info = {
                    'path': relative_path,
                    'name': file,
                    'type': file_type,
                    'extension': file_ext,
                    'size': os.path.getsize(file_path),
                    'checksum': self._get_file_checksum(file_path),
                    'last_modified': datetime.fromtimestamp(os.path.getmtime(file_path)).isoformat()
                }
                
                all_files.append(file_info)
                file_stats[file_type] += 1
        
        result = {
            'repository_path': repo_path,
            'total_files': len(all_files),
            'file_statistics': file_stats,
            'files': all_files,
            'collection_timestamp': datetime.now().isoformat()
        }
        
        print(f"  Found {len(all_files)} files:")
        print(f"    Java: {file_stats['java']}")
        print(f"    SQL: {file_stats['sql']}")
        print(f"    Config: {file_stats['config']}")
        print(f"    Other: {file_stats['other']}")
        
        return result
    
    def _get_file_type(self, extension: str) -> str:
        """Determine file type based on extension"""
        for file_type, extensions in self.supported_extensions.items():
            if extension in extensions:
                return file_type
        return 'other'
    
    def _get_file_checksum(self, file_path: str) -> str:
        """Calculate MD5 checksum of file"""
        try:
            with open(file_path, 'rb') as f:
                return hashlib.md5(f.read()).hexdigest()
        except:
            return ""
    
    def save_results(self, collection_data: Dict[str, Any], output_path: str):
        """Save collection results"""
        self.save_collection(collection_data, output_path)

    def save_collection(self, collection_data: Dict[str, Any], output_path: str):
        """Save collection data to JSON file"""
        os.makedirs(output_path, exist_ok=True)

        output_file = os.path.join(output_path, "collection.json")
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(collection_data, f, indent=2, ensure_ascii=False)

        print(f"Agent 1 Complete: Saved to {output_file}")

if __name__ == "__main__":
    collector = FileCollector()
    
    # Test with swiggy backend
    repo_path = "test_projects/swiggy_backend"
    collection_data = collector.collect_files(repo_path)
    collector.save_collection(collection_data, "output")

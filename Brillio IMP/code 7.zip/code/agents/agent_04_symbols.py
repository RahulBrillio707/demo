"""
Agent 4: Symbol Tables Generation Agent
Generates CSV files for symbols, operations, variables, and lineage
"""

import os
import json
import csv
from typing import Dict, List, Any

class SymbolTableBuilder:
    """Generates symbol tables from parsing data"""

    def __init__(self):
        pass

    def build_symbol_tables(self, output_path: str) -> Dict[str, Any]:
        """Build symbol tables from parsing data"""
        parsing_file = os.path.join(output_path, "parsing.json")
        return self.generate_symbol_tables(parsing_file)

    def save_results(self, symbol_data: Dict[str, Any], output_path: str):
        """Save symbol table results"""
        self.save_symbol_tables(symbol_data, output_path)
    
    def generate_symbol_tables(self, parsing_file: str) -> Dict[str, Any]:
        """
        Generate symbol tables from parsing data
        
        Args:
            parsing_file: Path to parsing.json from Agent 3
            
        Returns:
            Dictionary with symbol table data
        """
        print("Agent 4: Generating symbol tables")
        
        # Load parsing data
        with open(parsing_file, 'r', encoding='utf-8') as f:
            parsing_data = json.load(f)

        nodes = parsing_data['nodes']
        relationships = parsing_data['relationships']
        
        # Generate tables
        symbols_table = self._generate_symbols_table(nodes)
        operations_table = self._generate_operations_table(nodes, relationships)
        variables_table = self._generate_variables_table(nodes)
        lineage_table = self._generate_lineage_table(relationships, nodes)
        
        result = {
            'total_symbols': len(symbols_table),
            'symbols': symbols_table,
            'operations': operations_table,
            'variables': variables_table,
            'lineage': lineage_table
        }
        
        print(f"  Generated {len(symbols_table)} symbols")
        print(f"  Generated {len(operations_table)} operations")
        print(f"  Generated {len(variables_table)} variables")
        print(f"  Generated {len(lineage_table)} lineage relationships")
        
        return result
    
    def _generate_symbols_table(self, nodes: List[Dict]) -> List[Dict]:
        """Generate symbols table (Methods, classes, fields, parameters)"""
        symbols = []
        
        for node in nodes:
            if node['node_type'] in ['Method', 'Class', 'Field', 'Parameter', 'Interface']:
                symbol = {
                    'symbol_id': node['node_id'],
                    'symbol_name': node['name'],
                    'symbol_type': node['node_type'],
                    'class_name': node['properties'].get('class_name', ''),
                    'package_name': node['properties'].get('package_name', ''),
                    'file_path': node['properties'].get('file_path', ''),
                    'visibility': node['properties'].get('visibility', ''),
                    'is_static': node['properties'].get('is_static', False),
                    'return_type': node['properties'].get('return_type', ''),
                    'parameters': ','.join(node['properties'].get('parameters', [])),
                    'annotations': ','.join(node['properties'].get('annotations', []))
                }
                symbols.append(symbol)
        
        return symbols
    
    def _generate_operations_table(self, nodes: List[Dict], relationships: List[Dict]) -> List[Dict]:
        """Generate operations table (Method and database operations)"""
        operations = []
        
        # Method call operations
        for rel in relationships:
            if rel['relationship_type'] in ['CALLS', 'MAKES_API_CALL']:
                source_node = next((n for n in nodes if n['node_id'] == rel['source_id']), None)
                target_node = next((n for n in nodes if n['node_id'] == rel['target_id']), None)
                
                if source_node and target_node:
                    operation = {
                        'operation_id': rel['relationship_id'],
                        'operation_type': 'METHOD_CALL',
                        'source_method': source_node['name'],
                        'source_class': source_node['properties'].get('class_name', ''),
                        'target_method': target_node['name'],
                        'target_class': target_node['properties'].get('class_name', ''),
                        'operation_details': f"{source_node['name']} -> {target_node['name']}",
                        'line_number': rel['properties'].get('line_number', 0)
                    }
                    operations.append(operation)
        
        # Database operations
        for node in nodes:
            if node['node_type'] in ['Database', 'Database_Table', 'API_Call']:
                operation = {
                    'operation_id': node['node_id'],
                    'operation_type': 'DATABASE_OPERATION',
                    'source_method': '',
                    'source_class': '',
                    'target_method': node['name'],
                    'target_class': 'DATABASE',
                    'operation_details': f"Database operation: {node['name']}",
                    'line_number': 0
                }
                operations.append(operation)
        
        return operations
    
    def _generate_variables_table(self, nodes: List[Dict]) -> List[Dict]:
        """Generate variables table (Variable details with types and scopes)"""
        variables = []
        
        for node in nodes:
            if node['node_type'] in ['Field', 'Parameter', 'Variable']:
                variable = {
                    'variable_id': node['node_id'],
                    'variable_name': node['name'],
                    'variable_type': node['properties'].get('type', ''),
                    'scope': node['properties'].get('scope', ''),
                    'class_name': node['properties'].get('class_name', ''),
                    'method_name': node['properties'].get('method_name', ''),
                    'is_final': node['properties'].get('is_final', False),
                    'is_static': node['properties'].get('is_static', False),
                    'initial_value': node['properties'].get('initial_value', ''),
                    'annotations': ','.join(node['properties'].get('annotations', []))
                }
                variables.append(variable)
        
        return variables
    
    def _generate_lineage_table(self, relationships: List[Dict], nodes: List[Dict]) -> List[Dict]:
        """Generate lineage table (Relationships and data flow)"""
        lineage = []
        
        for rel in relationships:
            source_node = next((n for n in nodes if n['node_id'] == rel['source_id']), None)
            target_node = next((n for n in nodes if n['node_id'] == rel['target_id']), None)
            
            if source_node and target_node:
                lineage_entry = {
                    'relationship_id': rel['relationship_id'],
                    'source_id': rel['source_id'],
                    'source_name': source_node['name'],
                    'source_type': source_node['node_type'],
                    'target_id': rel['target_id'],
                    'target_name': target_node['name'],
                    'target_type': target_node['node_type'],
                    'relationship_type': rel['relationship_type'],
                    'relationship_details': rel['properties'].get('details', ''),
                    'confidence': rel['properties'].get('confidence', 1.0)
                }
                lineage.append(lineage_entry)
        
        return lineage
    
    def save_symbol_tables(self, symbol_data: Dict[str, Any], output_path: str):
        """Save symbol tables (CSV generation disabled as not used by subsequent agents)"""
        os.makedirs(output_path, exist_ok=True)

        # CSV files are not consumed by subsequent agents, so generation is disabled
        # to reduce output clutter and improve performance

        # # Save symbols.csv
        # symbols_file = os.path.join(output_path, "symbols.csv")
        # if symbol_data['symbols']:
        #     with open(symbols_file, 'w', newline='', encoding='utf-8') as f:
        #         writer = csv.DictWriter(f, fieldnames=symbol_data['symbols'][0].keys())
        #         writer.writeheader()
        #         writer.writerows(symbol_data['symbols'])

        # # Save operations.csv
        # operations_file = os.path.join(output_path, "operations.csv")
        # if symbol_data['operations']:
        #     with open(operations_file, 'w', newline='', encoding='utf-8') as f:
        #         writer = csv.DictWriter(f, fieldnames=symbol_data['operations'][0].keys())
        #         writer.writeheader()
        #         writer.writerows(symbol_data['operations'])

        # # Save variables.csv
        # variables_file = os.path.join(output_path, "variables.csv")
        # if symbol_data['variables']:
        #     with open(variables_file, 'w', newline='', encoding='utf-8') as f:
        #         writer = csv.DictWriter(f, fieldnames=symbol_data['variables'][0].keys())
        #         writer.writeheader()
        #         writer.writerows(symbol_data['variables'])

        # # Save lineage.csv
        # lineage_file = os.path.join(output_path, "lineage.csv")
        # if symbol_data['lineage']:
        #     with open(lineage_file, 'w', newline='', encoding='utf-8') as f:
        #         writer = csv.DictWriter(f, fieldnames=symbol_data['lineage'][0].keys())
        #         writer.writeheader()
        #         writer.writerows(symbol_data['lineage'])

        print(f"Agent 4 Complete: Symbol table generation completed (CSV output disabled)")

if __name__ == "__main__":
    generator = SymbolTableBuilder()
    
    # Test symbol table generation
    parsing_file = "output/parsing.json"
    if os.path.exists(parsing_file):
        symbol_data = generator.generate_symbol_tables(parsing_file)
        generator.save_symbol_tables(symbol_data, "output")
    else:
        print("Run Agent 3 first to create parsing.json")

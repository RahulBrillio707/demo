"""
Agent 5: Variable Transformations Agent
Uses LLM to analyze variable transformations in method chunks
"""

import os
import json
import warnings
from typing import Dict, List, Any
from dotenv import load_dotenv

# Suppress SSL warnings
warnings.filterwarnings("ignore", message=".*SSL.*")
warnings.filterwarnings("ignore", message=".*certificate.*")
os.environ['GRPC_VERBOSITY'] = 'ERROR'
os.environ['GLOG_minloglevel'] = '2'


# Load environment variables
load_dotenv()

# LLM imports
try:
    from langchain_openai import AzureChatOpenAI
    from langchain_core.messages import HumanMessage, SystemMessage
    LLM_AVAILABLE = True
except ImportError:
    LLM_AVAILABLE = False
    print("Warning: LangChain not available, using simulation mode")

class VariableTransformationAnalyzer:
    """Analyzes variable transformations using LLM"""
    
    def __init__(self):
        self.llm = None
        self.llm_available = False
        
        # Initialize Azure OpenAI LLM
        if LLM_AVAILABLE:
            try:
                # Use the working Azure OpenAI configuration
                self.llm = AzureChatOpenAI(
                    api_key="b1af33941ef9408088e7180ca36947ee",
                    azure_endpoint="https://btaasopenai.openai.azure.com/",
                    azure_deployment="model_data_lineage",
                    api_version="2024-12-01-preview",
                    temperature=0.1,
                    max_tokens=2000
                )
                self.llm_available = True
                print("  LLM (Azure OpenAI) initialized successfully")
            except Exception as e:
                print(f"  Warning: Failed to initialize Azure OpenAI LLM: {e}")
                self.llm_available = False
        else:
            print("  Warning: LangChain not available, using enhanced pattern mode")
            self.llm_available = False
    
    def analyze_transformations(self, output_path: str) -> Dict[str, Any]:
        """
        Analyze variable transformations in method chunks and merge with parser output

        Args:
            output_path: Path to output directory containing chunks.json and parsing.json

        Returns:
            Dictionary with transformation analysis and merged lineage
        """
        print("Agent 5: Analyzing variable transformations")

        # Load chunks data
        chunks_file = os.path.join(output_path, "chunks.json")
        with open(chunks_file, 'r', encoding='utf-8') as f:
            chunks_data = json.load(f)

        method_chunks = chunks_data['method_chunks']
        transformations = []
        all_nodes = []
        all_relationships = []

        # Analyze each method chunk with LLM
        total_chunks = len(method_chunks)
        for i, chunk in enumerate(method_chunks):
            if self.llm_available:
                chunk_transformations = self._analyze_chunk_with_llm(chunk)
            else:
                chunk_transformations = self._analyze_chunk_with_patterns(chunk)

            transformations.extend(chunk_transformations)

            # Collect nodes and relationships from transformations
            for trans in chunk_transformations:
                if 'nodes' in trans:
                    all_nodes.extend(trans['nodes'])
                if 'relationships' in trans:
                    all_relationships.extend(trans['relationships'])

            # Show progress every 10 chunks or for important milestones
            if i % 10 == 0 or i == total_chunks - 1:
                print(f"  Processing chunk ({i+1}/{total_chunks}) - Nodes: {len(all_nodes)}, Relationships: {len(all_relationships)}, Methods: {len(transformations)}")

        # Merge with parser output if provided
        merged_data = None
        parser_file = os.path.join(output_path, "parsing.json")
        if os.path.exists(parser_file):
            merged_data = self._merge_with_parser_output(parser_file, all_nodes, all_relationships)

        result = {
            'repository_path': chunks_data.get('repository_path', ''),
            'total_transformations': len(transformations),
            'total_variable_nodes': len(all_nodes),
            'total_variable_relationships': len(all_relationships),
            'transformations': transformations,
            'variable_nodes': all_nodes,
            'variable_relationships': all_relationships,
            'merged_lineage': merged_data,
            'analysis_method': 'LLM' if self.llm_available else 'Pattern-based'
        }

        print(f"  Found {len(transformations)} method transformations")
        print(f"  Created {len(all_nodes)} variable nodes")
        print(f"  Created {len(all_relationships)} variable relationships")

        return result
    
    def _analyze_chunk_with_llm(self, chunk: Dict) -> List[Dict]:
        """Analyze chunk using enhanced LLM variable flow analysis"""
        transformations = []

        try:
            # Create comprehensive prompt for variable flow analysis
            prompt = self._create_transformation_prompt(chunk)

            # Create messages with system context
            messages = [
                SystemMessage(content="""You are an expert Java code analyzer specializing in variable transformation flows.
                Your task is to trace complete data lineage from method inputs through all transformations to outputs.
                Focus on identifying:
                - Variable assignments and modifications
                - Method calls that transform data
                - Database operations (queries, inserts, updates)
                - Collection operations (add, remove, update)
                - Cross-method variable dependencies
                Return only valid JSON with the requested structure."""),
                HumanMessage(content=prompt)
            ]

            # Call LLM with enhanced context
            response = self.llm.invoke(messages)

            # Parse enhanced LLM response
            transformations = self._parse_llm_response(response.content, chunk)

        except Exception as e:
            print(f"    LLM analysis failed for {chunk['method_name']}: {e}")
            # Fallback to pattern-based analysis
            transformations = self._analyze_chunk_with_patterns(chunk)

        return transformations
    
    def _analyze_chunk_with_patterns(self, chunk: Dict) -> List[Dict]:
        """Enhanced pattern-based analysis for variable transformations"""
        import uuid
        import re

        content = chunk['content']
        method_name = chunk['method_name']
        method_id = chunk['chunk_id']
        variables = chunk['variables']
        operations = chunk.get('operations', [])

        # Create nodes and relationships for this method
        nodes = []
        relationships = []
        variable_flows = []

        # Enhanced variable analysis
        variable_nodes = {}
        parameter_vars = []
        local_vars = []
        return_vars = []

        # Analyze content line by line for better pattern recognition
        lines = content.split('\n')

        # Identify parameters (first line analysis)
        first_meaningful_line = next((line.strip() for line in lines if line.strip() and not line.strip().startswith('//')), '')
        if '(' in first_meaningful_line and ')' in first_meaningful_line:
            param_section = first_meaningful_line[first_meaningful_line.find('(')+1:first_meaningful_line.find(')')]
            param_matches = re.findall(r'(\w+)\s+(\w+)', param_section)
            for param_type, param_name in param_matches:
                if param_name in variables:
                    parameter_vars.append(param_name)

        # Create enhanced variable nodes with better type inference
        for i, var in enumerate(variables):
            var_node_id = f"{method_id}_var_{i}"

            # Determine variable scope and type
            scope = 'parameter' if var in parameter_vars else 'local'
            data_type = self._infer_variable_type_simple(var, content)
            usage_pattern = self._analyze_variable_usage_simple(var, content)

            var_node = {
                'node_id': var_node_id,
                'node_type': 'Variable',
                'name': var,
                'properties': {
                    'data_type': data_type,
                    'scope': scope,
                    'method_id': method_id,
                    'method_name': method_name,
                    'usage_pattern': usage_pattern,
                    'line_references': self._find_variable_lines_simple(var, lines)
                }
            }
            nodes.append(var_node)
            variable_nodes[var] = var_node_id

            # Create method declares variable relationship
            rel = {
                'relationship_id': f"{method_id}_declares_{i}",
                'source_id': method_id,
                'target_id': var_node_id,
                'relationship_type': 'declares',
                'properties': {
                    'declaration_type': scope,
                    'confidence': 0.9
                }
            }
            relationships.append(rel)

        # Create operation nodes
        for i, op in enumerate(operations):
            op_node_id = f"{method_id}_op_{i}"
            op_node = {
                'node_id': op_node_id,
                'node_type': 'Operation',
                'name': op,
                'properties': {
                    'operation_type': op.lower(),
                    'method_id': method_id,
                    'method_name': method_name
                }
            }
            nodes.append(op_node)

            # Create variable flows to operation relationships
            for j, var in enumerate(variables[:3]):  # Limit to first 3 variables
                if var in variable_nodes:
                    rel = {
                        'relationship_id': f"{method_id}_flows_{i}_{j}",
                        'source_id': variable_nodes[var],
                        'target_id': op_node_id,
                        'relationship_type': 'flows_to',
                        'properties': {
                            'flow_type': 'data_flow'
                        }
                    }
                    relationships.append(rel)

        # Analyze assignment patterns for variable transformations
        lines = content.split('\n')
        for i, line in enumerate(lines):
            line = line.strip()

            # Assignment patterns: var = expression
            if '=' in line and not line.startswith('//') and not '==' in line:
                parts = line.split('=', 1)
                if len(parts) == 2:
                    target_var = parts[0].strip().split()[-1]  # Get variable name
                    source_expr = parts[1].strip().rstrip(';')

                    # Create transformation operation
                    trans_op_id = f"{method_id}_assign_{i}"
                    trans_op = {
                        'node_id': trans_op_id,
                        'node_type': 'Operation',
                        'name': 'ASSIGNMENT',
                        'properties': {
                            'operation_type': 'assignment',
                            'line_number': i + 1,
                            'expression': source_expr,
                            'method_id': method_id
                        }
                    }
                    nodes.append(trans_op)

                    # Create relationships if variables exist
                    if target_var in variable_nodes:
                        # Operation transforms to target variable
                        rel = {
                            'relationship_id': f"{method_id}_transforms_{i}",
                            'source_id': trans_op_id,
                            'target_id': variable_nodes[target_var],
                            'relationship_type': 'transforms_to',
                            'properties': {
                                'transformation_type': 'assignment',
                                'line_number': i + 1
                            }
                        }
                        relationships.append(rel)

        # Create single transformation record with nodes and relationships
        transformation = {
            'transformation_id': f"{method_id}_pattern_analysis",
            'method_id': method_id,
            'method_name': method_name,
            'class_name': chunk.get('class_name', 'Unknown'),
            'nodes': nodes,
            'relationships': relationships,
            'analysis_type': 'pattern_based',
            'confidence': 0.7,
            'variable_count': len(variables),
            'operation_count': len(operations),
            'transformation_count': len([line for line in lines if '=' in line and not '==' in line])
        }

        return [transformation]
    
    def _create_transformation_prompt(self, chunk: Dict) -> str:
        """Create comprehensive prompt for LLM variable flow analysis"""
        method_name = chunk['method_name']
        class_name = chunk['class_name']
        content = chunk['content']
        variables = chunk.get('variables', [])

        return f"""You are an expert Java code analyzer. Analyze this method for complete variable transformation flows.

**METHOD DETAILS:**
- Method: {method_name}
- Class: {class_name}
- Detected Variables: {variables}

**CODE TO ANALYZE:**
```java
{content}
```

**ANALYSIS REQUIREMENTS:**
Trace the complete variable flow from input to output:

1. **Input Parameters**: Identify method parameters and their usage
2. **Variable Assignments**: Track all variable assignments and modifications
3. **Method Calls**: Identify method calls that transform variables (setters, builders, transformers)
4. **Database Operations**: Find database queries, inserts, updates, deletes
5. **Collection Operations**: Track list/map operations (add, remove, put, get)
6. **Return Values**: Identify what variables are returned and their transformations
7. **Cross-Method Dependencies**: Variables passed to other methods

**OUTPUT FORMAT:**
Return ONLY a JSON object with this exact structure:

{{
  "variable_flows": [
    {{
      "flow_id": "unique_flow_id",
      "flow_type": "parameter_to_return|assignment|method_call|database_operation|collection_operation",
      "source_variable": "variable_name",
      "target_variable": "variable_name",
      "transformation_method": "method_name_if_applicable",
      "line_number": 1,
      "description": "detailed description of transformation"
    }}
  ],
  "nodes": [
    {{
      "node_id": "unique_node_id",
      "node_type": "Variable|Operation|Parameter|DatabaseQuery|CollectionOperation",
      "name": "node_name",
      "properties": {{
        "data_type": "inferred_type",
        "scope": "parameter|local|field|return",
        "line_number": 1,
        "usage_pattern": "input|intermediate|output|database|collection"
      }}
    }}
  ],
  "relationships": [
    {{
      "relationship_id": "unique_rel_id",
      "source_id": "source_node_id",
      "target_id": "target_node_id",
      "relationship_type": "declares|flows_to|transforms_to|calls|queries|updates",
      "properties": {{
        "line_number": 1,
        "transformation_type": "assignment|method_call|database_op|collection_op",
        "confidence": 0.9
      }}
    }}
  ]
}}

**IMPORTANT:**
- Return ONLY the JSON object, no explanations
- Include ALL variable transformations, even simple assignments
- Identify database table/column references if present
- Track collection modifications (add, remove, update operations)
- Include confidence scores for complex transformations"""
    
    def _parse_llm_response(self, response_content: str, chunk: Dict) -> List[Dict]:
        """Parse enhanced LLM response with variable flows"""
        transformations = []

        try:
            # Clean the response content
            response_content = response_content.strip()
            import re
            import uuid

            # Look for JSON object
            json_match = re.search(r'\{[\s\S]*\}', response_content)
            if json_match:
                json_str = json_match.group(0)
                # Clean up common JSON issues
                json_str = re.sub(r',\s*}', '}', json_str)
                json_str = re.sub(r',\s*]', ']', json_str)

                try:
                    parsed_data = json.loads(json_str)

                    # Extract variable flows, nodes, and relationships
                    variable_flows = parsed_data.get('variable_flows', [])
                    nodes = parsed_data.get('nodes', [])
                    relationships = parsed_data.get('relationships', [])

                    # Ensure all nodes have proper IDs
                    for node in nodes:
                        if 'node_id' not in node or not node['node_id']:
                            node['node_id'] = f"{chunk['chunk_id']}_{node['node_type'].lower()}_{uuid.uuid4().hex[:8]}"

                        # Add method context to properties
                        if 'properties' not in node:
                            node['properties'] = {}
                        node['properties']['method_id'] = chunk['chunk_id']
                        node['properties']['method_name'] = chunk['method_name']

                    # Ensure all relationships have proper IDs
                    for rel in relationships:
                        if 'relationship_id' not in rel or not rel['relationship_id']:
                            rel['relationship_id'] = f"{chunk['chunk_id']}_rel_{uuid.uuid4().hex[:8]}"

                    # Create comprehensive transformation entry
                    transformation = {
                        'transformation_id': f"{chunk['chunk_id']}_llm_enhanced",
                        'method_id': chunk['chunk_id'],
                        'method_name': chunk['method_name'],
                        'class_name': chunk['class_name'],
                        'variable_flows': variable_flows,
                        'nodes': nodes,
                        'relationships': relationships,
                        'analysis_type': 'llm_enhanced',
                        'confidence': 0.95,
                        'flow_count': len(variable_flows),
                        'node_count': len(nodes),
                        'relationship_count': len(relationships)
                    }
                    transformations.append(transformation)

                    print(f"    LLM analysis successful: {len(variable_flows)} flows, {len(nodes)} nodes, {len(relationships)} relationships")
                    return transformations

                except json.JSONDecodeError as e:
                    print(f"    JSON parsing failed: {e}")
                    print(f"    Response content: {response_content[:200]}...")

            # If LLM parsing fails, fall back to pattern analysis
            print(f"    LLM response parsing failed, using pattern fallback")
            return self._analyze_chunk_with_patterns(chunk)

        except Exception as e:
            print(f"    LLM response parsing error: {e}")
            return self._analyze_chunk_with_patterns(chunk)

            # Create operation nodes
            for i, op in enumerate(operations):
                op_node = {
                    'node_id': f"{method_id}_op_{i}",
                    'node_type': 'operation',
                    'name': op,
                    'properties': {
                        'operation_type': op.lower(),
                        'method_id': method_id
                    }
                }
                nodes.append(op_node)

                # Create variable flows to operation relationships
                if variables:
                    for j, var in enumerate(variables):
                        rel = {
                            'relationship_id': f"{method_id}_flows_{i}_{j}",
                            'source_id': f"{method_id}_var_{j}",
                            'target_id': f"{method_id}_op_{i}",
                            'relationship_type': 'flows_to',
                            'properties': {
                                'flow_type': 'data_flow'
                            }
                        }
                        relationships.append(rel)

            transformation = {
                'transformation_id': f"{chunk['chunk_id']}_fallback_analysis",
                'method_id': method_id,
                'method_name': chunk['method_name'],
                'class_name': chunk['class_name'],
                'nodes': nodes,
                'relationships': relationships,
                'analysis_type': 'fallback_pattern',
                'confidence': 0.6
            }
            transformations.append(transformation)

        except Exception as e:
            print(f"    Failed to parse LLM response: {e}")
            # Create minimal transformation
            transformation = {
                'transformation_id': f"{chunk['chunk_id']}_minimal",
                'method_id': chunk['chunk_id'],
                'method_name': chunk['method_name'],
                'class_name': chunk['class_name'],
                'nodes': [],
                'relationships': [],
                'analysis_type': 'error_fallback',
                'confidence': 0.3
            }
            transformations.append(transformation)

        return transformations

    def _merge_with_parser_output(self, parser_file: str, variable_nodes: List[Dict], variable_relationships: List[Dict]) -> Dict[str, Any]:
        """Merge variable transformations with parser output"""
        print("  Merging with parser output...")

        # Load parser data
        with open(parser_file, 'r', encoding='utf-8') as f:
            parser_data = json.load(f)

        # Get existing nodes and relationships
        existing_nodes = parser_data.get('nodes', [])
        existing_relationships = parser_data.get('relationships', [])

        # Merge nodes (avoid duplicates by node_id)
        existing_node_ids = {node['node_id'] for node in existing_nodes}
        merged_nodes = existing_nodes.copy()

        for var_node in variable_nodes:
            if var_node['node_id'] not in existing_node_ids:
                merged_nodes.append(var_node)

        # Merge relationships (avoid duplicates by relationship_id)
        existing_rel_ids = {rel['relationship_id'] for rel in existing_relationships}
        merged_relationships = existing_relationships.copy()

        for var_rel in variable_relationships:
            if var_rel['relationship_id'] not in existing_rel_ids:
                merged_relationships.append(var_rel)

        merged_data = {
            'total_nodes': len(merged_nodes),
            'total_relationships': len(merged_relationships),
            'nodes': merged_nodes,
            'relationships': merged_relationships,
            'merge_stats': {
                'original_nodes': len(existing_nodes),
                'original_relationships': len(existing_relationships),
                'added_variable_nodes': len(variable_nodes),
                'added_variable_relationships': len(variable_relationships),
                'final_nodes': len(merged_nodes),
                'final_relationships': len(merged_relationships)
            }
        }

        print(f"    Merged: {len(existing_nodes)} + {len(variable_nodes)} = {len(merged_nodes)} nodes")
        print(f"    Merged: {len(existing_relationships)} + {len(variable_relationships)} = {len(merged_relationships)} relationships")

        return merged_data

    def save_results(self, transformation_data: Dict[str, Any], output_path: str):
        """Save transformation results"""
        self.save_transformations(transformation_data, output_path)

    def save_transformations(self, transformation_data: Dict[str, Any], output_path: str):
        """Save transformation analysis results"""
        os.makedirs(output_path, exist_ok=True)

        # Save variable transformations
        output_file = os.path.join(output_path, "variable_transformations.json")
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(transformation_data, f, indent=2, ensure_ascii=False)

        # Save merged lineage if available
        if transformation_data.get('merged_lineage'):
            merged_file = os.path.join(output_path, "merged_lineage.json")
            with open(merged_file, 'w', encoding='utf-8') as f:
                json.dump(transformation_data['merged_lineage'], f, indent=2, ensure_ascii=False)
            print(f"  Saved merged_lineage.json with complete application-to-variable lineage")

        print(f"Agent 5 Complete: Saved variable_transformations.json")

    def _infer_variable_type_simple(self, var_name: str, content: str) -> str:
        """Simple variable type inference"""
        content_lower = content.lower()
        var_lower = var_name.lower()

        # Common type patterns
        if 'string' in var_lower or 'name' in var_lower or 'email' in var_lower:
            return 'String'
        elif 'int' in var_lower or 'id' in var_lower or 'count' in var_lower:
            return 'Integer'
        elif 'bool' in var_lower or var_lower.startswith('is') or var_lower.startswith('has'):
            return 'Boolean'
        elif 'list' in var_lower or 'array' in var_lower:
            return 'List'
        elif 'map' in var_lower or 'dict' in var_lower:
            return 'Map'
        elif 'date' in var_lower or 'time' in var_lower:
            return 'DateTime'
        elif var_name[0].isupper():  # Likely a class name
            return var_name
        else:
            return 'Object'

    def _analyze_variable_usage_simple(self, var_name: str, content: str) -> str:
        """Simple variable usage pattern analysis"""
        if f'{var_name} =' in content:
            return 'assignment'
        elif f'return {var_name}' in content:
            return 'return'
        elif f'.{var_name}(' in content or f'{var_name}.' in content:
            return 'method_call'
        elif 'repository' in var_name.lower() or 'service' in var_name.lower():
            return 'dependency'
        else:
            return 'local'

    def _find_variable_lines_simple(self, var_name: str, lines: List[str]) -> List[int]:
        """Find line numbers where variable is referenced"""
        line_numbers = []
        for i, line in enumerate(lines):
            if var_name in line:
                line_numbers.append(i + 1)
        return line_numbers[:5]  # Limit to first 5 occurrences

if __name__ == "__main__":
    analyzer = VariableTransformationAnalyzer()

    # Test transformation analysis
    output_path = "output"
    chunks_file = os.path.join(output_path, "chunks.json")

    if os.path.exists(chunks_file):
        transformation_data = analyzer.analyze_transformations(output_path)
        analyzer.save_results(transformation_data, output_path)
    else:
        print("Run Agent 2 first to create chunks.json")

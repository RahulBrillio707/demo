"""Database configuration and connection management."""

from typing import Optional, Dict, Any
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class DatabaseConfig:
    """Database configuration class."""
    uri: str
    username: str
    password: str
    database: str
    batch_size: int = 1000
    
    def __post_init__(self):
        """Validate configuration after initialization."""
        if not self.uri:
            raise ValueError("Database URI is required")
        if not self.username:
            raise ValueError("Database username is required")
        if not self.password:
            raise ValueError("Database password is required")
        if not self.database:
            raise ValueError("Database name is required")
    
    def get_connection_params(self) -> Dict[str, Any]:
        """Get connection parameters for Neo4j driver."""
        return {
            "uri": self.uri,
            "auth": (self.username, self.password),
            "database": self.database
        }
    
    def __repr__(self) -> str:
        """String representation (without password)."""
        return f"DatabaseConfig(uri='{self.uri}', username='{self.username}', database='{self.database}')"


class DatabaseManager:
    """Database connection manager."""
    
    def __init__(self):
        """Initialize database manager."""
        self._connections: Dict[str, Any] = {}
    
    def get_connection(self, config: DatabaseConfig, connection_name: str = "default"):
        """Get or create a database connection."""
        try:
            from neo4j import GraphDatabase
            
            if connection_name not in self._connections:
                logger.info(f"Creating new database connection: {connection_name}")
                driver = GraphDatabase.driver(
                    config.uri,
                    auth=(config.username, config.password)
                )
                self._connections[connection_name] = driver
                logger.info(f"Successfully connected to database: {config.database}")
            
            return self._connections[connection_name]
            
        except ImportError:
            logger.error("Neo4j driver not installed. Please install with: pip install neo4j")
            raise
        except Exception as e:
            logger.error(f"Failed to connect to database {config.database}: {e}")
            raise
    
    def close_connection(self, connection_name: str = "default"):
        """Close a database connection."""
        if connection_name in self._connections:
            try:
                self._connections[connection_name].close()
                del self._connections[connection_name]
                logger.info(f"Closed database connection: {connection_name}")
            except Exception as e:
                logger.error(f"Error closing connection {connection_name}: {e}")
    
    def close_all_connections(self):
        """Close all database connections."""
        for connection_name in list(self._connections.keys()):
            self.close_connection(connection_name)
    
    def test_connection(self, config: DatabaseConfig) -> bool:
        """Test database connection."""
        try:
            from neo4j import GraphDatabase
            
            driver = GraphDatabase.driver(
                config.uri,
                auth=(config.username, config.password)
            )
            
            with driver.session(database=config.database) as session:
                result = session.run("RETURN 1 as test")
                test_value = result.single()["test"]
                
            driver.close()
            
            if test_value == 1:
                logger.info(f"Database connection test successful: {config.database}")
                return True
            else:
                logger.error(f"Database connection test failed: {config.database}")
                return False
                
        except Exception as e:
            logger.error(f"Database connection test failed for {config.database}: {e}")
            return False


# Global database manager instance
db_manager = DatabaseManager()

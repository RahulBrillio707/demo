"""Main configuration settings for the lineage analysis system."""

import os
from pathlib import Path
from typing import Optional, Dict, Any
from dataclasses import dataclass
from dotenv import load_dotenv
from .database import DatabaseConfig

# Load environment variables from .env file
load_dotenv()


# Add from_env class method to DatabaseConfig
def _from_env(cls, prefix: str) -> 'DatabaseConfig':
    """Create database config from environment variables."""
    return cls(
        uri=os.getenv(f"{prefix}_URI", "bolt://localhost:7687"),
        username=os.getenv(f"{prefix}_USERNAME", "neo4j"),
        password=os.getenv(f"{prefix}_PASSWORD", "password"),
        database=os.getenv(f"{prefix}_DATABASE", "neo4j"),
        batch_size=int(os.getenv(f"{prefix}_BATCH_SIZE", "1000"))
    )

# Add the from_env method to the imported DatabaseConfig class
DatabaseConfig.from_env = classmethod(_from_env)


@dataclass
class GitHubConfig:
    """GitHub configuration."""
    username: str
    token: str
    organization: str
    
    @classmethod
    def from_env(cls) -> 'GitHubConfig':
        """Create GitHub config from environment variables."""
        return cls(
            username=os.getenv("GITHUB_USERNAME", ""),
            token=os.getenv("GITHUB_PAT", ""),
            organization=os.getenv("GITHUB_ORG", "brillio-Oneai")
        )


@dataclass
class PipelineConfig:
    """Pipeline configuration."""
    max_workers: int
    batch_size: int
    timeout_seconds: int
    
    @classmethod
    def from_env(cls) -> 'PipelineConfig':
        """Create pipeline config from environment variables."""
        return cls(
            max_workers=int(os.getenv("MAX_WORKERS", "4")),
            batch_size=int(os.getenv("BATCH_SIZE", "100")),
            timeout_seconds=int(os.getenv("TIMEOUT_SECONDS", "300"))
        )


class Settings:
    """Main application settings."""
    
    def __init__(self):
        """Initialize settings from environment variables."""
        self.project_root = Path(__file__).parent.parent
        
        # Database configurations
        self.db1 = DatabaseConfig.from_env("NEO4J_DB1")  # Code lineage
        self.db2 = DatabaseConfig.from_env("NEO4J_DB2")  # Data lineage
        
        # Legacy database config (for backward compatibility)
        self.neo4j_uri = os.getenv("NEO4J_URI", self.db1.uri)
        self.neo4j_user = os.getenv("NEO4J_USER", self.db1.username)
        self.neo4j_password = os.getenv("NEO4J_PASSWORD", self.db1.password)
        self.neo4j_db = os.getenv("NEO4J_DB", self.db1.database)
        
        # GitHub configuration
        self.github = GitHubConfig.from_env()
        
        # Pipeline configuration
        self.pipeline = PipelineConfig.from_env()
        
        # Application settings
        self.log_level = os.getenv("LOG_LEVEL", "INFO")
        self.output_dir = Path(os.getenv("OUTPUT_DIR", "output"))
        self.workspace_dir = Path(os.getenv("WORKSPACE_DIR", "workspace"))
        self.output_json = os.getenv("OUTPUT_JSON", "output/json/graph_output.json")
        
        # Repository settings
        self.default_branch = os.getenv("DEFAULT_BRANCH", "main")
        self.clone_depth = int(os.getenv("CLONE_DEPTH", "1"))
        self.local_repo_path = Path(os.getenv("LOCAL_REPO_PATH", "Local"))
        
        # Ensure directories exist
        self.output_dir.mkdir(parents=True, exist_ok=True)
        (self.output_dir / "json").mkdir(parents=True, exist_ok=True)
        (self.output_dir / "logs").mkdir(parents=True, exist_ok=True)
        (self.output_dir / "reports").mkdir(parents=True, exist_ok=True)
        self.workspace_dir.mkdir(parents=True, exist_ok=True)
    
    def get_database_config(self, pipeline_type: str) -> DatabaseConfig:
        """Get database configuration for a specific pipeline type."""
        if pipeline_type.lower() == "code_lineage":
            return self.db1
        elif pipeline_type.lower() == "data_lineage":
            return self.db2
        else:
            return self.db1  # Default to code lineage
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert settings to dictionary."""
        return {
            "project_root": str(self.project_root),
            "databases": {
                "code_lineage": {
                    "uri": self.db1.uri,
                    "username": self.db1.username,
                    "database": self.db1.database
                },
                "data_lineage": {
                    "uri": self.db2.uri,
                    "username": self.db2.username,
                    "database": self.db2.database
                }
            },
            "github": {
                "username": self.github.username,
                "organization": self.github.organization
            },
            "pipeline": {
                "max_workers": self.pipeline.max_workers,
                "batch_size": self.pipeline.batch_size,
                "timeout_seconds": self.pipeline.timeout_seconds
            },
            "paths": {
                "output_dir": str(self.output_dir),
                "workspace_dir": str(self.workspace_dir),
                "output_json": self.output_json
            },
            "repository": {
                "default_branch": self.default_branch,
                "clone_depth": self.clone_depth
            }
        }


# Global settings instance
settings = Settings()

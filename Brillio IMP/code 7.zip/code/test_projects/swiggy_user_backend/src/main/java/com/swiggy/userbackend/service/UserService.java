package com.swiggy.userbackend.service;

import com.swiggy.userbackend.entity.User;
import com.swiggy.userbackend.entity.UserAddress;
import com.swiggy.userbackend.repository.UserRepository;
import com.swiggy.userbackend.repository.UserAddressRepository;
import com.swiggy.userbackend.dto.UserRegistrationRequest;
import com.swiggy.userbackend.dto.UserResponse;
import com.swiggy.userbackend.events.UserCreatedEvent;
import com.swiggy.userbackend.events.UserUpdatedEvent;
import com.swiggy.userbackend.exception.UserNotFoundException;
import com.swiggy.userbackend.exception.EmailAlreadyExistsException;
import com.swiggy.userbackend.client.DeliveryServiceClient;
import com.swiggy.userbackend.client.NotificationServiceClient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * User Service - Core business logic for user management in User Backend
 * 
 * Cross-service interactions:
 * 1. Database: Shared database with Delivery Backend (cross-schema access)
 * 2. Kafka: Publishes user events and consumes order events
 * 3. REST API: Calls Notification Service and receives calls from Delivery Service
 * 4. Cache: Redis for user profile caching
 */
@Service
@Transactional
public class UserService {

    private final UserRepository userRepository;
    private final UserAddressRepository userAddressRepository;
    private final PasswordEncoder passwordEncoder;
    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final NotificationServiceClient notificationServiceClient;
    private final DeliveryServiceClient deliveryServiceClient;
    private final RestTemplate restTemplate;
    private final JwtTokenService jwtTokenService;

    @Autowired
    public UserService(UserRepository userRepository,
                      UserAddressRepository userAddressRepository,
                      PasswordEncoder passwordEncoder,
                      KafkaTemplate<String, Object> kafkaTemplate,
                      NotificationServiceClient notificationServiceClient,
                      DeliveryServiceClient deliveryServiceClient,
                      RestTemplate restTemplate,
                      JwtTokenService jwtTokenService) {
        this.userRepository = userRepository;
        this.userAddressRepository = userAddressRepository;
        this.passwordEncoder = passwordEncoder;
        this.kafkaTemplate = kafkaTemplate;
        this.notificationServiceClient = notificationServiceClient;
        this.deliveryServiceClient = deliveryServiceClient;
        this.restTemplate = restTemplate;
        this.jwtTokenService = jwtTokenService;
    }

    /**
     * Register new user - Demonstrates cross-service communication
     * 
     * Data Flow:
     * 1. Save user to shared database (accessible by Delivery Backend)
     * 2. Publish UserCreatedEvent to Kafka (consumed by Notification Service)
     * 3. Call Notification Service REST API for welcome email
     * 4. Cache user profile in Redis
     */
    @Transactional
    public UserResponse registerUser(UserRegistrationRequest request) {
        // Check if email already exists in shared database
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new EmailAlreadyExistsException("Email already registered: " + request.getEmail());
        }

        // Create new user entity
        User user = new User();
        user.setFullName(request.getFullName());
        user.setEmail(request.getEmail());
        user.setPhoneNumber(request.getPhoneNumber());
        user.setPasswordHash(passwordEncoder.encode(request.getPassword()));
        user.setPreferredLanguage(request.getPreferredLanguage());
        user.setNotificationPreferences(request.getNotificationPreferences());

        // Save to shared database (accessible by Delivery Backend for orders)
        User savedUser = userRepository.save(user);

        // Create default address if provided
        if (request.getAddress() != null) {
            UserAddress address = new UserAddress();
            address.setUser(savedUser);
            address.setAddressLine1(request.getAddress().getAddressLine1());
            address.setAddressLine2(request.getAddress().getAddressLine2());
            address.setCity(request.getAddress().getCity());
            address.setState(request.getAddress().getState());
            address.setPostalCode(request.getAddress().getPostalCode());
            address.setAddressType(request.getAddress().getAddressType());
            address.setIsDefault(true);
            address.setLatitude(request.getAddress().getLatitude());
            address.setLongitude(request.getAddress().getLongitude());
            
            userAddressRepository.save(address);
        }

        // Publish user created event to Kafka - Notification Service will consume this
        UserCreatedEvent event = new UserCreatedEvent(
            savedUser.getUserId(),
            savedUser.getEmail(),
            savedUser.getFullName(),
            savedUser.getPhoneNumber(),
            savedUser.getCreatedAt()
        );
        kafkaTemplate.send("user-events", "user.created", event);

        // Call Notification Service via REST API for immediate welcome email
        try {
            notificationServiceClient.sendWelcomeEmail(
                savedUser.getEmail(), 
                savedUser.getFullName()
            );
        } catch (Exception e) {
            // Log error but don't fail registration
            System.err.println("Failed to send welcome email: " + e.getMessage());
        }

        return convertToUserResponse(savedUser);
    }

    /**
     * Authenticate user - Demonstrates JWT token generation
     */
    @Transactional
    public String authenticateUser(String email, String password) {
        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new UserNotFoundException("User not found: " + email));

        // Check if account is locked
        if (user.isAccountLocked()) {
            throw new RuntimeException("Account is locked until: " + user.getAccountLockedUntil());
        }

        // Verify password
        if (!passwordEncoder.matches(password, user.getPasswordHash())) {
            user.incrementFailedLoginAttempts();
            
            // Lock account after 5 failed attempts
            if (user.getFailedLoginAttempts() >= 5) {
                user.lockAccount(1800); // 30 minutes
            }
            
            userRepository.save(user);
            throw new RuntimeException("Invalid credentials");
        }

        // Successful login
        user.updateLastLogin();
        userRepository.save(user);

        // Publish login event
        kafkaTemplate.send("user-events", "user.login", Map.of(
            "userId", user.getUserId(),
            "email", user.getEmail(),
            "loginTime", LocalDateTime.now()
        ));

        // Generate JWT token
        return jwtTokenService.generateToken(user);
    }

    /**
     * Get user profile with caching
     */
    @Cacheable(value = "user-profiles", key = "#userId")
    @Transactional(readOnly = true)
    public UserResponse getUserProfile(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException("User not found: " + userId));
        
        return convertToUserResponse(user);
    }

    /**
     * Update user profile - Demonstrates cache eviction and event publishing
     */
    @CacheEvict(value = "user-profiles", key = "#userId")
    @Transactional
    public UserResponse updateUserProfile(Long userId, UserRegistrationRequest updateRequest) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException("User not found: " + userId));

        // Update user fields
        if (updateRequest.getFullName() != null) {
            user.setFullName(updateRequest.getFullName());
        }
        
        if (updateRequest.getPhoneNumber() != null) {
            user.setPhoneNumber(updateRequest.getPhoneNumber());
        }

        if (updateRequest.getPreferredLanguage() != null) {
            user.setPreferredLanguage(updateRequest.getPreferredLanguage());
        }

        if (updateRequest.getNotificationPreferences() != null) {
            user.setNotificationPreferences(updateRequest.getNotificationPreferences());
        }

        User updatedUser = userRepository.save(user);

        // Publish update event to Kafka
        UserUpdatedEvent event = new UserUpdatedEvent(
            updatedUser.getUserId(),
            updatedUser.getEmail(),
            updatedUser.getFullName(),
            updatedUser.getUpdatedAt()
        );
        kafkaTemplate.send("user-events", "user.updated", event);

        return convertToUserResponse(updatedUser);
    }

    /**
     * Get user addresses
     */
    @Transactional(readOnly = true)
    public List<UserAddress> getUserAddresses(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException("User not found: " + userId));
        
        return userAddressRepository.findByUserOrderByIsDefaultDescCreatedAtDesc(user);
    }

    /**
     * Add new address for user
     */
    @Transactional
    public UserAddress addUserAddress(Long userId, UserAddress addressRequest) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException("User not found: " + userId));

        UserAddress address = new UserAddress();
        address.setUser(user);
        address.setAddressLine1(addressRequest.getAddressLine1());
        address.setAddressLine2(addressRequest.getAddressLine2());
        address.setCity(addressRequest.getCity());
        address.setState(addressRequest.getState());
        address.setPostalCode(addressRequest.getPostalCode());
        address.setLandmark(addressRequest.getLandmark());
        address.setAddressType(addressRequest.getAddressType());
        address.setLatitude(addressRequest.getLatitude());
        address.setLongitude(addressRequest.getLongitude());

        // If this is the first address, make it default
        List<UserAddress> existingAddresses = userAddressRepository.findByUser(user);
        if (existingAddresses.isEmpty()) {
            address.setIsDefault(true);
        } else if (addressRequest.getIsDefault() != null && addressRequest.getIsDefault()) {
            // If setting as default, unset other default addresses
            existingAddresses.forEach(addr -> addr.setIsDefault(false));
            userAddressRepository.saveAll(existingAddresses);
            address.setIsDefault(true);
        }

        return userAddressRepository.save(address);
    }

    /**
     * Get user statistics with cross-service data
     */
    @Transactional(readOnly = true)
    public UserStats getUserStats(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException("User not found: " + userId));

        // Get order statistics from Delivery Backend via REST API
        long totalOrders = 0;
        long completedOrders = 0;
        try {
            String deliveryServiceUrl = "http://swiggy-delivery-backend/api/v1/orders/user/" + userId + "/stats";
            Map<String, Object> orderStats = restTemplate.getForObject(deliveryServiceUrl, Map.class);
            if (orderStats != null) {
                totalOrders = ((Number) orderStats.get("totalOrders")).longValue();
                completedOrders = ((Number) orderStats.get("completedOrders")).longValue();
            }
        } catch (Exception e) {
            System.err.println("Failed to get order statistics: " + e.getMessage());
        }
        
        return new UserStats(
            userId,
            totalOrders,
            completedOrders,
            user.getAddresses() != null ? user.getAddresses().size() : 0,
            user.getCreatedAt(),
            user.getLastLoginAt()
        );
    }

    /**
     * Kafka listener for order events from Delivery Backend
     * 
     * Data Flow:
     * Delivery Backend → Kafka → User Backend (for user activity tracking)
     */
    @KafkaListener(topics = "order-events", groupId = "swiggy-user-service-group")
    public void handleOrderEvents(Map<String, Object> eventData) {
        String eventType = (String) eventData.get("eventType");
        
        switch (eventType) {
            case "order.created":
                handleOrderCreatedEvent(eventData);
                break;
            case "order.delivered":
                handleOrderDeliveredEvent(eventData);
                break;
            case "order.cancelled":
                handleOrderCancelledEvent(eventData);
                break;
            default:
                System.out.println("Unknown order event type: " + eventType);
        }
    }

    /**
     * Handle order created event - Update user activity
     */
    private void handleOrderCreatedEvent(Map<String, Object> eventData) {
        Long userId = ((Number) eventData.get("userId")).longValue();
        
        try {
            User user = userRepository.findById(userId).orElse(null);
            if (user != null) {
                // Update user's last activity
                user.setUpdatedAt(LocalDateTime.now());
                userRepository.save(user);
                
                // Clear user cache to reflect updated activity
                // cacheManager.evict("user-profiles", userId);
            }
        } catch (Exception e) {
            System.err.println("Failed to handle order created event: " + e.getMessage());
        }
    }

    /**
     * Handle order delivered event - Update user loyalty points (if implemented)
     */
    private void handleOrderDeliveredEvent(Map<String, Object> eventData) {
        Long userId = ((Number) eventData.get("userId")).longValue();
        // Implementation for loyalty points, user tier updates, etc.
    }

    /**
     * Handle order cancelled event
     */
    private void handleOrderCancelledEvent(Map<String, Object> eventData) {
        Long userId = ((Number) eventData.get("userId")).longValue();
        // Implementation for handling cancellation impacts
    }

    /**
     * Get user by email - Used by Delivery Backend for cross-service queries
     */
    @Transactional(readOnly = true)
    public Optional<UserResponse> getUserByEmail(String email) {
        return userRepository.findByEmail(email)
            .map(this::convertToUserResponse);
    }

    /**
     * Check if user exists - Used by Delivery Backend before creating orders
     */
    @Transactional(readOnly = true)
    public boolean userExists(Long userId) {
        return userRepository.existsById(userId);
    }

    /**
     * Convert User entity to UserResponse DTO
     */
    private UserResponse convertToUserResponse(User user) {
        UserResponse response = new UserResponse();
        response.setUserId(user.getUserId());
        response.setFullName(user.getFullName());
        response.setEmail(user.getEmail());
        response.setPhoneNumber(user.getPhoneNumber());
        response.setStatus(user.getStatus().toString());
        response.setEmailVerified(user.getEmailVerified());
        response.setPhoneVerified(user.getPhoneVerified());
        response.setProfileImageUrl(user.getProfileImageUrl());
        response.setPreferredLanguage(user.getPreferredLanguage());
        response.setNotificationPreferences(user.getNotificationPreferences());
        response.setLastLoginAt(user.getLastLoginAt());
        response.setCreatedAt(user.getCreatedAt());
        response.setUpdatedAt(user.getUpdatedAt());
        
        return response;
    }

    /**
     * User statistics DTO
     */
    public static class UserStats {
        private Long userId;
        private Long totalOrders;
        private Long completedOrders;
        private Long totalAddresses;
        private LocalDateTime memberSince;
        private LocalDateTime lastLogin;

        public UserStats(Long userId, Long totalOrders, Long completedOrders, Long totalAddresses,
                        LocalDateTime memberSince, LocalDateTime lastLogin) {
            this.userId = userId;
            this.totalOrders = totalOrders;
            this.completedOrders = completedOrders;
            this.totalAddresses = totalAddresses;
            this.memberSince = memberSince;
            this.lastLogin = lastLogin;
        }

        // Getters and setters
        public Long getUserId() { return userId; }
        public void setUserId(Long userId) { this.userId = userId; }
        
        public Long getTotalOrders() { return totalOrders; }
        public void setTotalOrders(Long totalOrders) { this.totalOrders = totalOrders; }
        
        public Long getCompletedOrders() { return completedOrders; }
        public void setCompletedOrders(Long completedOrders) { this.completedOrders = completedOrders; }
        
        public Long getTotalAddresses() { return totalAddresses; }
        public void setTotalAddresses(Long totalAddresses) { this.totalAddresses = totalAddresses; }
        
        public LocalDateTime getMemberSince() { return memberSince; }
        public void setMemberSince(LocalDateTime memberSince) { this.memberSince = memberSince; }
        
        public LocalDateTime getLastLogin() { return lastLogin; }
        public void setLastLogin(LocalDateTime lastLogin) { this.lastLogin = lastLogin; }
    }
}

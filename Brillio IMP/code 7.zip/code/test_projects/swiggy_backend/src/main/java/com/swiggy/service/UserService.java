package com.swiggy.service;

import com.swiggy.entity.User;
import com.swiggy.entity.Address;
import com.swiggy.repository.UserRepository;
import com.swiggy.repository.AddressRepository;
import com.swiggy.dto.UserRegistrationRequest;
import com.swiggy.dto.UserResponse;
import com.swiggy.events.UserCreatedEvent;
import com.swiggy.exception.UserNotFoundException;
import com.swiggy.exception.EmailAlreadyExistsException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * User service handling user management operations
 * 
 * Demonstrates:
 * - Spring Service annotation
 * - Dependency injection with @Autowired
 * - Transaction management
 * - Caching with Redis
 * - Kafka event publishing
 * - Data transformation between entities and DTOs
 */
@Service
@Transactional
public class UserService {

    private final UserRepository userRepository;
    private final AddressRepository addressRepository;
    private final PasswordEncoder passwordEncoder;
    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final CacheService cacheService;

    @Autowired
    public UserService(UserRepository userRepository,
                      AddressRepository addressRepository,
                      PasswordEncoder passwordEncoder,
                      KafkaTemplate<String, Object> kafkaTemplate,
                      CacheService cacheService) {
        this.userRepository = userRepository;
        this.addressRepository = addressRepository;
        this.passwordEncoder = passwordEncoder;
        this.kafkaTemplate = kafkaTemplate;
        this.cacheService = cacheService;
    }

    /**
     * Register a new user
     * Demonstrates: Transaction management, validation, event publishing
     */
    @Transactional
    public UserResponse registerUser(UserRegistrationRequest request) {
        // Check if email already exists
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new EmailAlreadyExistsException("Email already registered: " + request.getEmail());
        }

        // Create new user entity
        User user = new User();
        user.setFullName(request.getFullName());
        user.setEmail(request.getEmail());
        user.setPhoneNumber(request.getPhoneNumber());
        user.setPasswordHash(passwordEncoder.encode(request.getPassword()));

        // Save user to database
        User savedUser = userRepository.save(user);

        // Create default address if provided
        if (request.getAddress() != null) {
            Address address = new Address();
            address.setUser(savedUser);
            address.setAddressLine1(request.getAddress().getAddressLine1());
            address.setAddressLine2(request.getAddress().getAddressLine2());
            address.setCity(request.getAddress().getCity());
            address.setState(request.getAddress().getState());
            address.setPostalCode(request.getAddress().getPostalCode());
            address.setIsDefault(true);
            
            addressRepository.save(address);
        }

        // Publish user created event to Kafka
        UserCreatedEvent event = new UserCreatedEvent(
            savedUser.getUserId(),
            savedUser.getEmail(),
            savedUser.getFullName(),
            savedUser.getCreatedAt()
        );
        kafkaTemplate.send("user-events", event);

        // Cache user data
        cacheService.cacheUser(savedUser);

        return convertToUserResponse(savedUser);
    }

    /**
     * Get user by ID with caching
     * Demonstrates: Caching, exception handling
     */
    @Cacheable(value = "users", key = "#userId")
    @Transactional(readOnly = true)
    public UserResponse getUserById(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userId));
        
        return convertToUserResponse(user);
    }

    /**
     * Get user by email
     * Demonstrates: Custom repository method, optional handling
     */
    @Transactional(readOnly = true)
    public Optional<UserResponse> getUserByEmail(String email) {
        return userRepository.findByEmail(email)
            .map(this::convertToUserResponse);
    }

    /**
     * Update user profile
     * Demonstrates: Cache eviction, partial updates
     */
    @CacheEvict(value = "users", key = "#userId")
    @Transactional
    public UserResponse updateUserProfile(Long userId, UserRegistrationRequest updateRequest) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userId));

        // Update user fields
        if (updateRequest.getFullName() != null) {
            user.setFullName(updateRequest.getFullName());
        }
        
        if (updateRequest.getPhoneNumber() != null) {
            user.setPhoneNumber(updateRequest.getPhoneNumber());
        }

        User updatedUser = userRepository.save(user);
        
        // Update cache
        cacheService.cacheUser(updatedUser);

        return convertToUserResponse(updatedUser);
    }

    /**
     * Get all user addresses
     * Demonstrates: Lazy loading, collection handling
     */
    @Transactional(readOnly = true)
    public List<Address> getUserAddresses(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userId));
        
        return addressRepository.findByUserOrderByIsDefaultDescCreatedAtDesc(user);
    }

    /**
     * Add new address for user
     * Demonstrates: Entity relationships, business logic
     */
    @Transactional
    public Address addUserAddress(Long userId, Address addressRequest) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userId));

        Address address = new Address();
        address.setUser(user);
        address.setAddressLine1(addressRequest.getAddressLine1());
        address.setAddressLine2(addressRequest.getAddressLine2());
        address.setCity(addressRequest.getCity());
        address.setState(addressRequest.getState());
        address.setPostalCode(addressRequest.getPostalCode());
        address.setLandmark(addressRequest.getLandmark());
        address.setAddressType(addressRequest.getAddressType());
        address.setLatitude(addressRequest.getLatitude());
        address.setLongitude(addressRequest.getLongitude());

        // If this is the first address, make it default
        List<Address> existingAddresses = addressRepository.findByUser(user);
        if (existingAddresses.isEmpty()) {
            address.setIsDefault(true);
        } else if (addressRequest.getIsDefault() != null && addressRequest.getIsDefault()) {
            // If setting as default, unset other default addresses
            existingAddresses.forEach(addr -> addr.setIsDefault(false));
            addressRepository.saveAll(existingAddresses);
            address.setIsDefault(true);
        }

        return addressRepository.save(address);
    }

    /**
     * Deactivate user account
     * Demonstrates: Soft delete, cache eviction
     */
    @CacheEvict(value = "users", key = "#userId")
    @Transactional
    public void deactivateUser(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userId));

        user.deactivate();
        userRepository.save(user);

        // Remove from cache
        cacheService.evictUser(userId);
    }

    /**
     * Search users by name or email
     * Demonstrates: Custom queries, pagination
     */
    @Transactional(readOnly = true)
    public List<UserResponse> searchUsers(String searchTerm) {
        List<User> users = userRepository.findByFullNameContainingIgnoreCaseOrEmailContainingIgnoreCase(
            searchTerm, searchTerm);
        
        return users.stream()
            .map(this::convertToUserResponse)
            .collect(Collectors.toList());
    }

    /**
     * Get user statistics
     * Demonstrates: Aggregation queries, business metrics
     */
    @Transactional(readOnly = true)
    public UserStats getUserStats(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userId));

        long totalOrders = userRepository.countOrdersByUserId(userId);
        long totalAddresses = addressRepository.countByUser(user);
        
        return new UserStats(userId, totalOrders, totalAddresses, user.getCreatedAt());
    }

    /**
     * Convert User entity to UserResponse DTO
     * Demonstrates: Data transformation, DTO pattern
     */
    private UserResponse convertToUserResponse(User user) {
        UserResponse response = new UserResponse();
        response.setUserId(user.getUserId());
        response.setFullName(user.getFullName());
        response.setEmail(user.getEmail());
        response.setPhoneNumber(user.getPhoneNumber());
        response.setStatus(user.getStatus().toString());
        response.setProfileImageUrl(user.getProfileImageUrl());
        response.setCreatedAt(user.getCreatedAt());
        response.setUpdatedAt(user.getUpdatedAt());
        
        return response;
    }

    /**
     * Inner class for user statistics
     */
    public static class UserStats {
        private Long userId;
        private Long totalOrders;
        private Long totalAddresses;
        private java.time.LocalDateTime memberSince;

        public UserStats(Long userId, Long totalOrders, Long totalAddresses, java.time.LocalDateTime memberSince) {
            this.userId = userId;
            this.totalOrders = totalOrders;
            this.totalAddresses = totalAddresses;
            this.memberSince = memberSince;
        }

        // Getters and setters
        public Long getUserId() { return userId; }
        public void setUserId(Long userId) { this.userId = userId; }
        
        public Long getTotalOrders() { return totalOrders; }
        public void setTotalOrders(Long totalOrders) { this.totalOrders = totalOrders; }
        
        public Long getTotalAddresses() { return totalAddresses; }
        public void setTotalAddresses(Long totalAddresses) { this.totalAddresses = totalAddresses; }
        
        public java.time.LocalDateTime getMemberSince() { return memberSince; }
        public void setMemberSince(java.time.LocalDateTime memberSince) { this.memberSince = memberSince; }
    }
}

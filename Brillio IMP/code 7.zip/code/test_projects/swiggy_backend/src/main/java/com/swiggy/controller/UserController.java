package com.swiggy.controller;

import com.swiggy.dto.UserRegistrationRequest;
import com.swiggy.dto.UserResponse;
import com.swiggy.entity.Address;
import com.swiggy.service.UserService;
import com.swiggy.exception.UserNotFoundException;
import com.swiggy.exception.EmailAlreadyExistsException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller for user management operations
 * 
 * Demonstrates:
 * - Spring REST Controller annotations
 * - OpenAPI/Swagger documentation
 * - Request/Response handling
 * - Validation
 * - Exception handling
 * - Security annotations
 */
@RestController
@RequestMapping("/api/v1/users")
@Tag(name = "User Management", description = "APIs for user registration, profile management, and address handling")
@CrossOrigin(origins = {"http://localhost:3000", "https://swiggy-frontend.com"})
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    /**
     * Register a new user
     * Demonstrates: POST endpoint, validation, exception handling
     */
    @PostMapping("/register")
    @Operation(summary = "Register new user", description = "Create a new user account with profile and address information")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "User registered successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid input data"),
        @ApiResponse(responseCode = "409", description = "Email already exists")
    })
    public ResponseEntity<UserResponse> registerUser(
            @Valid @RequestBody UserRegistrationRequest request) {
        
        try {
            UserResponse userResponse = userService.registerUser(request);
            return new ResponseEntity<>(userResponse, HttpStatus.CREATED);
        } catch (EmailAlreadyExistsException e) {
            return new ResponseEntity<>(null, HttpStatus.CONFLICT);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * Get user by ID
     * Demonstrates: GET endpoint with path variable, caching
     */
    @GetMapping("/{userId}")
    @Operation(summary = "Get user by ID", description = "Retrieve user profile information by user ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "User found"),
        @ApiResponse(responseCode = "404", description = "User not found")
    })
    public ResponseEntity<UserResponse> getUserById(
            @Parameter(description = "User ID", required = true)
            @PathVariable Long userId) {
        
        try {
            UserResponse userResponse = userService.getUserById(userId);
            return ResponseEntity.ok(userResponse);
        } catch (UserNotFoundException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    /**
     * Update user profile
     * Demonstrates: PUT endpoint, partial updates, security
     */
    @PutMapping("/{userId}")
    @PreAuthorize("hasRole('USER') and #userId == authentication.principal.userId")
    @Operation(summary = "Update user profile", description = "Update user profile information")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Profile updated successfully"),
        @ApiResponse(responseCode = "404", description = "User not found"),
        @ApiResponse(responseCode = "403", description = "Access denied")
    })
    public ResponseEntity<UserResponse> updateUserProfile(
            @PathVariable Long userId,
            @Valid @RequestBody UserRegistrationRequest updateRequest) {
        
        try {
            UserResponse updatedUser = userService.updateUserProfile(userId, updateRequest);
            return ResponseEntity.ok(updatedUser);
        } catch (UserNotFoundException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    /**
     * Get user addresses
     * Demonstrates: Nested resource endpoint, lazy loading
     */
    @GetMapping("/{userId}/addresses")
    @PreAuthorize("hasRole('USER') and #userId == authentication.principal.userId")
    @Operation(summary = "Get user addresses", description = "Retrieve all addresses for a user")
    public ResponseEntity<List<Address>> getUserAddresses(@PathVariable Long userId) {
        try {
            List<Address> addresses = userService.getUserAddresses(userId);
            return ResponseEntity.ok(addresses);
        } catch (UserNotFoundException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    /**
     * Add new address for user
     * Demonstrates: POST to nested resource, business logic
     */
    @PostMapping("/{userId}/addresses")
    @PreAuthorize("hasRole('USER') and #userId == authentication.principal.userId")
    @Operation(summary = "Add user address", description = "Add a new delivery address for the user")
    public ResponseEntity<Address> addUserAddress(
            @PathVariable Long userId,
            @Valid @RequestBody Address addressRequest) {
        
        try {
            Address savedAddress = userService.addUserAddress(userId, addressRequest);
            return new ResponseEntity<>(savedAddress, HttpStatus.CREATED);
        } catch (UserNotFoundException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    /**
     * Search users
     * Demonstrates: Query parameters, search functionality
     */
    @GetMapping("/search")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Search users", description = "Search users by name or email (Admin only)")
    public ResponseEntity<List<UserResponse>> searchUsers(
            @Parameter(description = "Search term for name or email")
            @RequestParam String q) {
        
        List<UserResponse> users = userService.searchUsers(q);
        return ResponseEntity.ok(users);
    }

    /**
     * Get user statistics
     * Demonstrates: Complex data aggregation, business metrics
     */
    @GetMapping("/{userId}/stats")
    @PreAuthorize("hasRole('USER') and #userId == authentication.principal.userId")
    @Operation(summary = "Get user statistics", description = "Get user's order and activity statistics")
    public ResponseEntity<UserService.UserStats> getUserStats(@PathVariable Long userId) {
        try {
            UserService.UserStats stats = userService.getUserStats(userId);
            return ResponseEntity.ok(stats);
        } catch (UserNotFoundException e) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
    }

    /**
     * Deactivate user account
     * Demonstrates: DELETE operation, soft delete
     */
    @DeleteMapping("/{userId}")
    @PreAuthorize("hasRole('USER') and #userId == authentication.principal.userId")
    @Operation(summary = "Deactivate user account", description = "Deactivate user account (soft delete)")
    public ResponseEntity<Void> deactivateUser(@PathVariable Long userId) {
        try {
            userService.deactivateUser(userId);
            return ResponseEntity.noContent().build();
        } catch (UserNotFoundException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    /**
     * Health check endpoint
     * Demonstrates: Simple GET endpoint for monitoring
     */
    @GetMapping("/health")
    @Operation(summary = "Health check", description = "Check if user service is healthy")
    public ResponseEntity<String> healthCheck() {
        return ResponseEntity.ok("User service is healthy");
    }

    /**
     * Exception handler for this controller
     * Demonstrates: Local exception handling
     */
    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleUserNotFound(UserNotFoundException e) {
        ErrorResponse error = new ErrorResponse("USER_NOT_FOUND", e.getMessage());
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(EmailAlreadyExistsException.class)
    public ResponseEntity<ErrorResponse> handleEmailAlreadyExists(EmailAlreadyExistsException e) {
        ErrorResponse error = new ErrorResponse("EMAIL_ALREADY_EXISTS", e.getMessage());
        return new ResponseEntity<>(error, HttpStatus.CONFLICT);
    }

    /**
     * Error response DTO
     */
    public static class ErrorResponse {
        private String errorCode;
        private String message;
        private long timestamp;

        public ErrorResponse(String errorCode, String message) {
            this.errorCode = errorCode;
            this.message = message;
            this.timestamp = System.currentTimeMillis();
        }

        // Getters and setters
        public String getErrorCode() { return errorCode; }
        public void setErrorCode(String errorCode) { this.errorCode = errorCode; }
        
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        
        public long getTimestamp() { return timestamp; }
        public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    }
}

package com.swiggy.repository;

import com.swiggy.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * User repository interface for database operations
 * 
 * Demonstrates:
 * - Spring Data JPA repository
 * - Custom query methods
 * - JPQL queries
 * - Native SQL queries
 * - Method naming conventions
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    /**
     * Find user by email address
     * Demonstrates: Method naming convention
     */
    Optional<User> findByEmail(String email);

    /**
     * Check if user exists by email
     * Demonstrates: Existence check methods
     */
    boolean existsByEmail(String email);

    /**
     * Find user by phone number
     * Demonstrates: Unique field lookup
     */
    Optional<User> findByPhoneNumber(String phoneNumber);

    /**
     * Find users by status
     * Demonstrates: Enum parameter handling
     */
    List<User> findByStatus(User.UserStatus status);

    /**
     * Find users created after a specific date
     * Demonstrates: Date/time queries
     */
    List<User> findByCreatedAtAfter(LocalDateTime date);

    /**
     * Search users by name or email (case insensitive)
     * Demonstrates: Multiple field search with ignore case
     */
    List<User> findByFullNameContainingIgnoreCaseOrEmailContainingIgnoreCase(
        String name, String email);

    /**
     * Find active users with orders
     * Demonstrates: JPQL with joins
     */
    @Query("SELECT DISTINCT u FROM User u " +
           "JOIN u.orders o " +
           "WHERE u.status = 'ACTIVE' " +
           "ORDER BY u.createdAt DESC")
    List<User> findActiveUsersWithOrders();

    /**
     * Count total orders for a user
     * Demonstrates: Aggregation with JPQL
     */
    @Query("SELECT COUNT(o) FROM Order o WHERE o.user.userId = :userId")
    long countOrdersByUserId(@Param("userId") Long userId);

    /**
     * Find users by city (from their addresses)
     * Demonstrates: Complex joins across relationships
     */
    @Query("SELECT DISTINCT u FROM User u " +
           "JOIN u.addresses a " +
           "WHERE a.city = :city " +
           "AND u.status = 'ACTIVE'")
    List<User> findUsersByCity(@Param("city") String city);

    /**
     * Get user statistics with native SQL
     * Demonstrates: Native SQL query with complex aggregations
     */
    @Query(value = """
        SELECT 
            u.user_id,
            u.full_name,
            u.email,
            COUNT(DISTINCT o.order_id) as total_orders,
            COUNT(DISTINCT a.address_id) as total_addresses,
            COALESCE(SUM(o.total_amount), 0) as total_spent,
            u.created_at
        FROM users u
        LEFT JOIN orders o ON u.user_id = o.user_id
        LEFT JOIN addresses a ON u.user_id = a.user_id
        WHERE u.user_id = :userId
        GROUP BY u.user_id, u.full_name, u.email, u.created_at
        """, nativeQuery = true)
    UserStatsProjection getUserStatistics(@Param("userId") Long userId);

    /**
     * Find top customers by order count
     * Demonstrates: Ordering and limiting results
     */
    @Query("SELECT u FROM User u " +
           "JOIN u.orders o " +
           "WHERE u.status = 'ACTIVE' " +
           "GROUP BY u " +
           "ORDER BY COUNT(o) DESC")
    List<User> findTopCustomersByOrderCount();

    /**
     * Find users who haven't placed orders recently
     * Demonstrates: NOT EXISTS subquery
     */
    @Query("SELECT u FROM User u " +
           "WHERE u.status = 'ACTIVE' " +
           "AND NOT EXISTS (" +
           "    SELECT 1 FROM Order o " +
           "    WHERE o.user.userId = u.userId " +
           "    AND o.createdAt > :sinceDate" +
           ")")
    List<User> findInactiveUsers(@Param("sinceDate") LocalDateTime sinceDate);

    /**
     * Update user last login time
     * Demonstrates: Update queries
     */
    @Query("UPDATE User u SET u.updatedAt = :loginTime WHERE u.userId = :userId")
    void updateLastLoginTime(@Param("userId") Long userId, @Param("loginTime") LocalDateTime loginTime);

    /**
     * Find users with multiple addresses
     * Demonstrates: HAVING clause with aggregation
     */
    @Query("SELECT u FROM User u " +
           "JOIN u.addresses a " +
           "GROUP BY u " +
           "HAVING COUNT(a) > 1")
    List<User> findUsersWithMultipleAddresses();

    /**
     * Search users with pagination support
     * Demonstrates: Custom method for pagination
     */
    @Query("SELECT u FROM User u " +
           "WHERE (:searchTerm IS NULL OR " +
           "       LOWER(u.fullName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "       LOWER(u.email) LIKE LOWER(CONCAT('%', :searchTerm, '%'))) " +
           "AND (:status IS NULL OR u.status = :status) " +
           "ORDER BY u.createdAt DESC")
    List<User> searchUsersWithFilters(@Param("searchTerm") String searchTerm, 
                                     @Param("status") User.UserStatus status);

    /**
     * Projection interface for user statistics
     * Demonstrates: Spring Data projections
     */
    interface UserStatsProjection {
        Long getUserId();
        String getFullName();
        String getEmail();
        Long getTotalOrders();
        Long getTotalAddresses();
        java.math.BigDecimal getTotalSpent();
        LocalDateTime getCreatedAt();
    }
}

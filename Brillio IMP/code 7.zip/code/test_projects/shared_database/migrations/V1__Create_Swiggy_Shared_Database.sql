-- Swiggy Shared Database Migration Script
-- Database: swiggy_shared_db
-- 
-- This database is shared between User Backend and Delivery Backend
-- Demonstrates cross-service data relationships and microservices data patterns

-- Create schemas for different backend services
CREATE SCHEMA IF NOT EXISTS user_schema;
CREATE SCHEMA IF NOT EXISTS delivery_schema;

-- =====================================================
-- USER SCHEMA - Managed by Swiggy User Backend
-- =====================================================

-- Users table - Primary table managed by User Backend
CREATE TABLE user_schema.users (
    user_id BIGSERIAL PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone_number VARCHAR(15) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    email_verified BOOLEAN DEFAULT FALSE,
    phone_verified BOOLEAN DEFAULT FALSE,
    profile_image_url VARCHAR(500),
    preferred_language VARCHAR(10) DEFAULT 'en',
    notification_preferences VARCHAR(100) DEFAULT 'email,sms,push',
    last_login_at TIMESTAMP,
    failed_login_attempts INTEGER DEFAULT 0,
    account_locked_until TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_user_status CHECK (status IN ('ACTIVE', 'INACTIVE', 'SUSPENDED', 'DELETED')),
    CONSTRAINT chk_email_format CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'),
    CONSTRAINT chk_phone_format CHECK (phone_number ~* '^\+?[1-9]\d{1,14}$'),
    CONSTRAINT chk_preferred_language CHECK (preferred_language IN ('en', 'hi', 'ta', 'te', 'bn', 'mr', 'gu'))
);

-- User addresses table - Managed by User Backend
CREATE TABLE user_schema.user_addresses (
    address_id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES user_schema.users(user_id) ON DELETE CASCADE,
    address_line1 VARCHAR(200) NOT NULL,
    address_line2 VARCHAR(200),
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    postal_code VARCHAR(10) NOT NULL,
    landmark VARCHAR(200),
    address_type VARCHAR(20) NOT NULL DEFAULT 'HOME',
    is_default BOOLEAN DEFAULT FALSE,
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_address_type CHECK (address_type IN ('HOME', 'WORK', 'OTHER')),
    CONSTRAINT chk_postal_code CHECK (postal_code ~ '^[0-9]{5,6}$')
);

-- User preferences table - Managed by User Backend
CREATE TABLE user_schema.user_preferences (
    preference_id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES user_schema.users(user_id) ON DELETE CASCADE,
    preference_key VARCHAR(50) NOT NULL,
    preference_value VARCHAR(200) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(user_id, preference_key)
);

-- =====================================================
-- DELIVERY SCHEMA - Managed by Swiggy Delivery Backend
-- =====================================================

-- Orders table - Managed by Delivery Backend, references User Backend data
CREATE TABLE delivery_schema.orders (
    order_id BIGSERIAL PRIMARY KEY,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    
    -- Cross-service foreign key reference
    -- References user_schema.users.user_id (managed by User Backend)
    user_id BIGINT NOT NULL,
    
    restaurant_id BIGINT NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'PLACED',
    subtotal DECIMAL(10,2) NOT NULL,
    delivery_fee DECIMAL(8,2),
    tax_amount DECIMAL(8,2),
    discount_amount DECIMAL(8,2) DEFAULT 0.00,
    total_amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50),
    payment_status VARCHAR(20) DEFAULT 'PENDING',
    delivery_address TEXT,
    delivery_latitude DECIMAL(10,8),
    delivery_longitude DECIMAL(11,8),
    estimated_delivery_time TIMESTAMP,
    actual_delivery_time TIMESTAMP,
    special_instructions TEXT,
    driver_id BIGINT,
    restaurant_preparation_time INTEGER,
    delivery_distance_km DECIMAL(8,2),
    delivery_partner_fee DECIMAL(8,2),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_order_status CHECK (status IN ('PLACED', 'CONFIRMED', 'PREPARING', 'READY_FOR_PICKUP', 'OUT_FOR_DELIVERY', 'DELIVERED', 'CANCELLED')),
    CONSTRAINT chk_payment_status CHECK (payment_status IN ('PENDING', 'PROCESSING', 'PAID', 'FAILED', 'REFUNDED')),
    CONSTRAINT chk_positive_amounts CHECK (subtotal > 0 AND total_amount > 0),
    
    -- Foreign key constraint across schemas (cross-service reference)
    CONSTRAINT fk_order_user FOREIGN KEY (user_id) REFERENCES user_schema.users(user_id)
);

-- Order items table - Managed by Delivery Backend
CREATE TABLE delivery_schema.order_items (
    order_item_id BIGSERIAL PRIMARY KEY,
    order_id BIGINT NOT NULL REFERENCES delivery_schema.orders(order_id) ON DELETE CASCADE,
    menu_item_id BIGINT NOT NULL,
    item_name VARCHAR(200) NOT NULL,
    quantity INTEGER NOT NULL,
    unit_price DECIMAL(8,2) NOT NULL,
    total_price DECIMAL(8,2) NOT NULL,
    special_requests TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_positive_quantity CHECK (quantity > 0),
    CONSTRAINT chk_positive_unit_price CHECK (unit_price > 0),
    CONSTRAINT chk_correct_total CHECK (total_price = unit_price * quantity)
);

-- Payments table - Managed by Delivery Backend
CREATE TABLE delivery_schema.payments (
    payment_id BIGSERIAL PRIMARY KEY,
    order_id BIGINT NOT NULL REFERENCES delivery_schema.orders(order_id) ON DELETE CASCADE,
    payment_method VARCHAR(50) NOT NULL,
    payment_provider VARCHAR(50) NOT NULL,
    transaction_id VARCHAR(100) UNIQUE,
    amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'INR',
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    gateway_response JSONB,
    processed_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_payment_status CHECK (status IN ('PENDING', 'PROCESSING', 'COMPLETED', 'FAILED', 'REFUNDED')),
    CONSTRAINT chk_positive_amount CHECK (amount > 0)
);

-- Deliveries table - Managed by Delivery Backend
CREATE TABLE delivery_schema.deliveries (
    delivery_id BIGSERIAL PRIMARY KEY,
    order_id BIGINT NOT NULL REFERENCES delivery_schema.orders(order_id) ON DELETE CASCADE,
    driver_id BIGINT NOT NULL,
    pickup_time TIMESTAMP,
    delivery_time TIMESTAMP,
    delivery_status VARCHAR(30) NOT NULL DEFAULT 'ASSIGNED',
    pickup_latitude DECIMAL(10,8),
    pickup_longitude DECIMAL(11,8),
    delivery_latitude DECIMAL(10,8),
    delivery_longitude DECIMAL(11,8),
    distance_km DECIMAL(8,2),
    delivery_fee DECIMAL(8,2),
    driver_rating INTEGER,
    delivery_notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_delivery_status CHECK (delivery_status IN ('ASSIGNED', 'PICKED_UP', 'IN_TRANSIT', 'DELIVERED', 'FAILED')),
    CONSTRAINT chk_driver_rating CHECK (driver_rating IS NULL OR (driver_rating >= 1 AND driver_rating <= 5))
);

-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================

-- User schema indexes
CREATE INDEX idx_users_email ON user_schema.users(email);
CREATE INDEX idx_users_phone ON user_schema.users(phone_number);
CREATE INDEX idx_users_status ON user_schema.users(status);
CREATE INDEX idx_users_created_at ON user_schema.users(created_at);
CREATE INDEX idx_users_last_login ON user_schema.users(last_login_at);

CREATE INDEX idx_user_addresses_user ON user_schema.user_addresses(user_id);
CREATE INDEX idx_user_addresses_default ON user_schema.user_addresses(user_id, is_default) WHERE is_default = TRUE;
CREATE INDEX idx_user_addresses_location ON user_schema.user_addresses(latitude, longitude);

CREATE INDEX idx_user_preferences_user ON user_schema.user_preferences(user_id);
CREATE INDEX idx_user_preferences_key ON user_schema.user_preferences(preference_key);

-- Delivery schema indexes
CREATE INDEX idx_orders_user_id ON delivery_schema.orders(user_id);
CREATE INDEX idx_orders_restaurant_id ON delivery_schema.orders(restaurant_id);
CREATE INDEX idx_orders_status ON delivery_schema.orders(status);
CREATE INDEX idx_orders_created_at ON delivery_schema.orders(created_at DESC);
CREATE INDEX idx_orders_number ON delivery_schema.orders(order_number);
CREATE INDEX idx_orders_driver ON delivery_schema.orders(driver_id);

CREATE INDEX idx_order_items_order ON delivery_schema.order_items(order_id);
CREATE INDEX idx_order_items_menu ON delivery_schema.order_items(menu_item_id);

CREATE INDEX idx_payments_order ON delivery_schema.payments(order_id);
CREATE INDEX idx_payments_transaction ON delivery_schema.payments(transaction_id);
CREATE INDEX idx_payments_status ON delivery_schema.payments(status);

CREATE INDEX idx_deliveries_order ON delivery_schema.deliveries(order_id);
CREATE INDEX idx_deliveries_driver ON delivery_schema.deliveries(driver_id);
CREATE INDEX idx_deliveries_status ON delivery_schema.deliveries(delivery_status);

-- =====================================================
-- CROSS-SERVICE VIEWS
-- =====================================================

-- View for Delivery Backend to get user details with orders
CREATE VIEW delivery_schema.user_order_summary AS
SELECT 
    u.user_id,
    u.full_name,
    u.email,
    u.phone_number,
    u.status as user_status,
    u.preferred_language,
    u.notification_preferences,
    COUNT(o.order_id) as total_orders,
    COALESCE(SUM(o.total_amount), 0) as total_spent,
    MAX(o.created_at) as last_order_date,
    AVG(o.total_amount) as average_order_value
FROM user_schema.users u
LEFT JOIN delivery_schema.orders o ON u.user_id = o.user_id
GROUP BY u.user_id, u.full_name, u.email, u.phone_number, u.status, u.preferred_language, u.notification_preferences;

-- View for User Backend to get user order statistics
CREATE VIEW user_schema.user_order_stats AS
SELECT 
    u.user_id,
    COUNT(o.order_id) as total_orders,
    COUNT(CASE WHEN o.status = 'DELIVERED' THEN 1 END) as completed_orders,
    COUNT(CASE WHEN o.status = 'CANCELLED' THEN 1 END) as cancelled_orders,
    COALESCE(AVG(o.total_amount), 0) as average_order_value,
    COALESCE(SUM(o.total_amount), 0) as total_spent,
    MAX(o.created_at) as last_order_date,
    COUNT(CASE WHEN o.created_at > CURRENT_DATE - INTERVAL '30 days' THEN 1 END) as orders_last_30_days
FROM user_schema.users u
LEFT JOIN delivery_schema.orders o ON u.user_id = o.user_id
GROUP BY u.user_id;

-- View for analytics - Cross-service user activity
CREATE VIEW delivery_schema.user_activity_analytics AS
SELECT 
    u.user_id,
    u.full_name,
    u.email,
    u.created_at as registration_date,
    u.last_login_at,
    COUNT(o.order_id) as lifetime_orders,
    COALESCE(SUM(o.total_amount), 0) as lifetime_value,
    COUNT(CASE WHEN o.created_at > CURRENT_DATE - INTERVAL '7 days' THEN 1 END) as orders_last_7_days,
    COUNT(CASE WHEN o.created_at > CURRENT_DATE - INTERVAL '30 days' THEN 1 END) as orders_last_30_days,
    COUNT(ua.address_id) as total_addresses,
    CASE 
        WHEN COUNT(o.order_id) = 0 THEN 'NEW_USER'
        WHEN COUNT(o.order_id) BETWEEN 1 AND 5 THEN 'OCCASIONAL_USER'
        WHEN COUNT(o.order_id) BETWEEN 6 AND 20 THEN 'REGULAR_USER'
        ELSE 'POWER_USER'
    END as user_segment
FROM user_schema.users u
LEFT JOIN delivery_schema.orders o ON u.user_id = o.user_id
LEFT JOIN user_schema.user_addresses ua ON u.user_id = ua.user_id
GROUP BY u.user_id, u.full_name, u.email, u.created_at, u.last_login_at;

-- =====================================================
-- TRIGGERS FOR AUDIT TRAILS
-- =====================================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers for updated_at
CREATE TRIGGER update_users_updated_at 
    BEFORE UPDATE ON user_schema.users 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_addresses_updated_at 
    BEFORE UPDATE ON user_schema.user_addresses 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_preferences_updated_at 
    BEFORE UPDATE ON user_schema.user_preferences 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_orders_updated_at 
    BEFORE UPDATE ON delivery_schema.orders 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_payments_updated_at 
    BEFORE UPDATE ON delivery_schema.payments 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_deliveries_updated_at 
    BEFORE UPDATE ON delivery_schema.deliveries 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- PERMISSIONS FOR CROSS-SERVICE ACCESS
-- =====================================================

-- Grant User Backend permissions
GRANT ALL PRIVILEGES ON SCHEMA user_schema TO swiggy_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA user_schema TO swiggy_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA user_schema TO swiggy_user;

-- Grant Delivery Backend permissions
GRANT ALL PRIVILEGES ON SCHEMA delivery_schema TO swiggy_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA delivery_schema TO swiggy_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA delivery_schema TO swiggy_user;

-- Grant Delivery Backend read access to User schema (for cross-service queries)
GRANT SELECT ON user_schema.users TO swiggy_user;
GRANT SELECT ON user_schema.user_addresses TO swiggy_user;
GRANT SELECT ON user_schema.user_order_stats TO swiggy_user;

-- Grant User Backend read access to Delivery schema (for user statistics)
GRANT SELECT ON delivery_schema.orders TO swiggy_user;
GRANT SELECT ON delivery_schema.user_order_summary TO swiggy_user;

-- Comments for documentation
COMMENT ON SCHEMA user_schema IS 'Schema managed by Swiggy User Backend - contains user profiles, addresses, and preferences';
COMMENT ON SCHEMA delivery_schema IS 'Schema managed by Swiggy Delivery Backend - contains orders, payments, and deliveries';

COMMENT ON TABLE user_schema.users IS 'Users table - shared read access with Delivery Backend for order processing';
COMMENT ON TABLE delivery_schema.orders IS 'Orders table - references users across service boundary via foreign key';

COMMENT ON VIEW delivery_schema.user_order_summary IS 'Cross-service view for Delivery Backend to access user data with order statistics';
COMMENT ON VIEW user_schema.user_order_stats IS 'Cross-service view for User Backend to access order statistics';
COMMENT ON VIEW delivery_schema.user_activity_analytics IS 'Cross-service analytics view for user segmentation and activity analysis';

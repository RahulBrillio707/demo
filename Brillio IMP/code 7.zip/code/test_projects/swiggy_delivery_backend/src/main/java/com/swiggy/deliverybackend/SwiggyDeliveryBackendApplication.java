package com.swiggy.deliverybackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Swiggy Delivery Backend Application
 * 
 * Responsibilities:
 * - Order management and processing
 * - Delivery tracking and assignment
 * - Payment processing integration
 * - Restaurant coordination
 * - Real-time order status updates
 * - Cross-service communication with User Backend
 */
@SpringBootApplication
@EnableEurekaClient
@EnableJpaAuditing
@EnableCaching
@EnableKafka
@EnableAsync
@EnableTransactionManagement
public class SwiggyDeliveryBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(SwiggyDeliveryBackendApplication.class, args);
    }
}

package com.swiggy.deliverybackend.service;

import com.swiggy.deliverybackend.entity.Order;
import com.swiggy.deliverybackend.entity.OrderItem;
import com.swiggy.deliverybackend.repository.OrderRepository;
import com.swiggy.deliverybackend.dto.OrderRequest;
import com.swiggy.deliverybackend.dto.OrderResponse;
import com.swiggy.deliverybackend.events.OrderCreatedEvent;
import com.swiggy.deliverybackend.events.OrderStatusUpdatedEvent;
import com.swiggy.deliverybackend.exception.OrderNotFoundException;
import com.swiggy.deliverybackend.exception.UserNotFoundException;
import com.swiggy.deliverybackend.client.UserServiceClient;
import com.swiggy.deliverybackend.client.NotificationServiceClient;
import com.swiggy.deliverybackend.client.PaymentGatewayClient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * Order Service - Core business logic for order management in Delivery Backend
 * 
 * Cross-service interactions:
 * 1. Database: Shared database with User Backend (cross-schema references)
 * 2. REST API: Calls User Backend for user validation and details
 * 3. Kafka: Publishes order events for Notification Service
 * 4. External APIs: Payment gateway integration
 * 5. Cache: Redis for order caching and performance
 */
@Service
@Transactional
public class OrderService {

    private final OrderRepository orderRepository;
    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final UserServiceClient userServiceClient;
    private final NotificationServiceClient notificationServiceClient;
    private final PaymentGatewayClient paymentGatewayClient;
    private final RestTemplate restTemplate;

    @Autowired
    public OrderService(OrderRepository orderRepository,
                       KafkaTemplate<String, Object> kafkaTemplate,
                       UserServiceClient userServiceClient,
                       NotificationServiceClient notificationServiceClient,
                       PaymentGatewayClient paymentGatewayClient,
                       RestTemplate restTemplate) {
        this.orderRepository = orderRepository;
        this.kafkaTemplate = kafkaTemplate;
        this.userServiceClient = userServiceClient;
        this.notificationServiceClient = notificationServiceClient;
        this.paymentGatewayClient = paymentGatewayClient;
        this.restTemplate = restTemplate;
    }

    /**
     * Create new order - Demonstrates cross-service communication
     * 
     * Data Flow:
     * 1. Validate user exists via REST call to User Backend
     * 2. Save order to shared database (cross-schema reference)
     * 3. Publish OrderCreatedEvent to Kafka (consumed by Notification Service)
     * 4. Call Notification Service REST API for order confirmation
     * 5. Cache order details in Redis
     */
    @Transactional
    public OrderResponse createOrder(OrderRequest orderRequest) {
        // Step 1: Validate user exists via cross-service REST call
        String userServiceUrl = "http://swiggy-user-backend/api/v1/users/" + orderRequest.getUserId();
        try {
            Map<String, Object> userResponse = restTemplate.getForObject(userServiceUrl, Map.class);
            if (userResponse == null) {
                throw new UserNotFoundException("User not found: " + orderRequest.getUserId());
            }
        } catch (Exception e) {
            throw new UserNotFoundException("Failed to validate user: " + orderRequest.getUserId());
        }

        // Step 2: Create order entity with cross-schema reference
        Order order = new Order();
        order.setUserId(orderRequest.getUserId()); // Foreign key to user_schema.users
        order.setRestaurantId(orderRequest.getRestaurantId());
        order.setDeliveryAddress(orderRequest.getDeliveryAddress());
        order.setDeliveryLatitude(orderRequest.getDeliveryLatitude());
        order.setDeliveryLongitude(orderRequest.getDeliveryLongitude());
        order.setSpecialInstructions(orderRequest.getSpecialInstructions());

        // Calculate order totals
        BigDecimal subtotal = calculateSubtotal(orderRequest.getOrderItems());
        BigDecimal deliveryFee = calculateDeliveryFee(orderRequest.getDeliveryLatitude(), orderRequest.getDeliveryLongitude());
        BigDecimal taxAmount = calculateTax(subtotal);
        
        order.setSubtotal(subtotal);
        order.setDeliveryFee(deliveryFee);
        order.setTaxAmount(taxAmount);
        order.calculateTotalAmount();

        // Step 3: Save to shared database
        Order savedOrder = orderRepository.save(order);

        // Add order items
        for (OrderRequest.OrderItemRequest itemRequest : orderRequest.getOrderItems()) {
            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(savedOrder);
            orderItem.setMenuItemId(itemRequest.getMenuItemId());
            orderItem.setItemName(itemRequest.getItemName());
            orderItem.setQuantity(itemRequest.getQuantity());
            orderItem.setUnitPrice(itemRequest.getUnitPrice());
            orderItem.setTotalPrice(itemRequest.getUnitPrice().multiply(BigDecimal.valueOf(itemRequest.getQuantity())));
            orderItem.setSpecialRequests(itemRequest.getSpecialRequests());
        }

        // Step 4: Publish order created event to Kafka
        OrderCreatedEvent event = new OrderCreatedEvent(
            savedOrder.getOrderId(),
            savedOrder.getOrderNumber(),
            savedOrder.getUserId(),
            savedOrder.getRestaurantId(),
            savedOrder.getTotalAmount(),
            savedOrder.getCreatedAt()
        );
        kafkaTemplate.send("order-events", "order.created", event);

        // Step 5: Call Notification Service via REST API
        try {
            notificationServiceClient.sendOrderConfirmation(
                savedOrder.getUserId(),
                savedOrder.getOrderNumber(),
                "Order placed successfully for " + savedOrder.getTotalAmount()
            );
        } catch (Exception e) {
            // Log error but don't fail order creation
            System.err.println("Failed to send order confirmation: " + e.getMessage());
        }

        return convertToOrderResponse(savedOrder);
    }

    /**
     * Update order status - Demonstrates event publishing and notifications
     */
    @CacheEvict(value = "orders", key = "#orderId")
    @Transactional
    public OrderResponse updateOrderStatus(Long orderId, String newStatus) {
        Order order = orderRepository.findById(orderId)
            .orElseThrow(() -> new OrderNotFoundException("Order not found: " + orderId));

        String previousStatus = order.getStatus().toString();
        
        // Update status based on business logic
        switch (newStatus.toUpperCase()) {
            case "CONFIRMED":
                order.confirm();
                break;
            case "PREPARING":
                order.startPreparation();
                break;
            case "READY_FOR_PICKUP":
                order.markReadyForPickup();
                break;
            case "OUT_FOR_DELIVERY":
                order.markOutForDelivery(null); // Driver assignment would happen separately
                break;
            case "DELIVERED":
                order.markDelivered();
                break;
            case "CANCELLED":
                order.cancel("User requested cancellation");
                break;
        }

        Order updatedOrder = orderRepository.save(order);

        // Publish status update event to Kafka
        OrderStatusUpdatedEvent event = new OrderStatusUpdatedEvent(
            updatedOrder.getOrderId(),
            updatedOrder.getOrderNumber(),
            updatedOrder.getUserId(),
            previousStatus,
            updatedOrder.getStatus().toString(),
            updatedOrder.getUpdatedAt()
        );
        kafkaTemplate.send("order-events", "order.status.updated", event);

        return convertToOrderResponse(updatedOrder);
    }

    /**
     * Get order details with caching
     */
    @Cacheable(value = "orders", key = "#orderId")
    @Transactional(readOnly = true)
    public OrderResponse getOrderById(Long orderId) {
        Order order = orderRepository.findById(orderId)
            .orElseThrow(() -> new OrderNotFoundException("Order not found: " + orderId));
        
        return convertToOrderResponse(order);
    }

    /**
     * Get user orders - Demonstrates cross-service data access
     */
    @Transactional(readOnly = true)
    public List<OrderResponse> getUserOrders(Long userId) {
        // First validate user exists via User Backend
        try {
            String userServiceUrl = "http://swiggy-user-backend/api/v1/users/" + userId;
            Map<String, Object> userResponse = restTemplate.getForObject(userServiceUrl, Map.class);
            if (userResponse == null) {
                throw new UserNotFoundException("User not found: " + userId);
            }
        } catch (Exception e) {
            throw new UserNotFoundException("Failed to validate user: " + userId);
        }

        // Query orders from shared database using cross-schema reference
        List<Order> orders = orderRepository.findByUserIdOrderByCreatedAtDesc(userId);
        
        return orders.stream()
            .map(this::convertToOrderResponse)
            .toList();
    }

    /**
     * Process payment - Demonstrates external API integration
     */
    @Transactional
    public OrderResponse processPayment(Long orderId, String paymentMethod) {
        Order order = orderRepository.findById(orderId)
            .orElseThrow(() -> new OrderNotFoundException("Order not found: " + orderId));

        try {
            // Call external payment gateway
            Map<String, Object> paymentRequest = Map.of(
                "amount", order.getTotalAmount(),
                "currency", "INR",
                "order_id", order.getOrderNumber(),
                "payment_method", paymentMethod
            );

            Map<String, Object> paymentResponse = paymentGatewayClient.processPayment(paymentRequest);
            
            if ("success".equals(paymentResponse.get("status"))) {
                order.setPaymentMethod(paymentMethod);
                order.setPaymentStatus(Order.PaymentStatus.PAID);
                
                // Confirm order after successful payment
                order.confirm();
                
                Order updatedOrder = orderRepository.save(order);

                // Publish payment success event
                kafkaTemplate.send("payment-events", "payment.success", Map.of(
                    "orderId", order.getOrderId(),
                    "orderNumber", order.getOrderNumber(),
                    "userId", order.getUserId(),
                    "amount", order.getTotalAmount(),
                    "paymentMethod", paymentMethod
                ));

                return convertToOrderResponse(updatedOrder);
            } else {
                order.setPaymentStatus(Order.PaymentStatus.FAILED);
                orderRepository.save(order);
                throw new RuntimeException("Payment failed: " + paymentResponse.get("error"));
            }

        } catch (Exception e) {
            order.setPaymentStatus(Order.PaymentStatus.FAILED);
            orderRepository.save(order);
            throw new RuntimeException("Payment processing failed", e);
        }
    }

    /**
     * Get order statistics for analytics
     */
    @Transactional(readOnly = true)
    public OrderStats getOrderStats(Long userId) {
        long totalOrders = orderRepository.countByUserId(userId);
        long completedOrders = orderRepository.countByUserIdAndStatus(userId, Order.OrderStatus.DELIVERED);
        long cancelledOrders = orderRepository.countByUserIdAndStatus(userId, Order.OrderStatus.CANCELLED);
        BigDecimal totalSpent = orderRepository.sumTotalAmountByUserId(userId);
        
        return new OrderStats(userId, totalOrders, completedOrders, cancelledOrders, totalSpent);
    }

    // Helper methods
    private BigDecimal calculateSubtotal(List<OrderRequest.OrderItemRequest> items) {
        return items.stream()
            .map(item -> item.getUnitPrice().multiply(BigDecimal.valueOf(item.getQuantity())))
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private BigDecimal calculateDeliveryFee(BigDecimal latitude, BigDecimal longitude) {
        // Simple distance-based calculation (would use actual maps API)
        return new BigDecimal("50.00"); // Base delivery fee
    }

    private BigDecimal calculateTax(BigDecimal subtotal) {
        return subtotal.multiply(new BigDecimal("0.18")); // 18% GST
    }

    private OrderResponse convertToOrderResponse(Order order) {
        OrderResponse response = new OrderResponse();
        response.setOrderId(order.getOrderId());
        response.setOrderNumber(order.getOrderNumber());
        response.setUserId(order.getUserId());
        response.setRestaurantId(order.getRestaurantId());
        response.setStatus(order.getStatus().toString());
        response.setSubtotal(order.getSubtotal());
        response.setDeliveryFee(order.getDeliveryFee());
        response.setTaxAmount(order.getTaxAmount());
        response.setDiscountAmount(order.getDiscountAmount());
        response.setTotalAmount(order.getTotalAmount());
        response.setPaymentMethod(order.getPaymentMethod());
        response.setPaymentStatus(order.getPaymentStatus().toString());
        response.setDeliveryAddress(order.getDeliveryAddress());
        response.setEstimatedDeliveryTime(order.getEstimatedDeliveryTime());
        response.setActualDeliveryTime(order.getActualDeliveryTime());
        response.setCreatedAt(order.getCreatedAt());
        response.setUpdatedAt(order.getUpdatedAt());
        
        return response;
    }

    /**
     * Order statistics DTO
     */
    public static class OrderStats {
        private Long userId;
        private Long totalOrders;
        private Long completedOrders;
        private Long cancelledOrders;
        private BigDecimal totalSpent;

        public OrderStats(Long userId, Long totalOrders, Long completedOrders, 
                         Long cancelledOrders, BigDecimal totalSpent) {
            this.userId = userId;
            this.totalOrders = totalOrders;
            this.completedOrders = completedOrders;
            this.cancelledOrders = cancelledOrders;
            this.totalSpent = totalSpent;
        }

        // Getters and setters
        public Long getUserId() { return userId; }
        public void setUserId(Long userId) { this.userId = userId; }
        
        public Long getTotalOrders() { return totalOrders; }
        public void setTotalOrders(Long totalOrders) { this.totalOrders = totalOrders; }
        
        public Long getCompletedOrders() { return completedOrders; }
        public void setCompletedOrders(Long completedOrders) { this.completedOrders = completedOrders; }
        
        public Long getCancelledOrders() { return cancelledOrders; }
        public void setCancelledOrders(Long cancelledOrders) { this.cancelledOrders = cancelledOrders; }
        
        public BigDecimal getTotalSpent() { return totalSpent; }
        public void setTotalSpent(BigDecimal totalSpent) { this.totalSpent = totalSpent; }
    }
}

package com.fooddelivery.notificationservice.service;

import com.fooddelivery.notificationservice.entity.NotificationLog;
import com.fooddelivery.notificationservice.repository.NotificationLogRepository;
import com.fooddelivery.notificationservice.dto.EmailRequest;
import com.fooddelivery.notificationservice.dto.SmsRequest;
import com.fooddelivery.notificationservice.dto.PushNotificationRequest;
import com.fooddelivery.notificationservice.client.EmailProviderClient;
import com.fooddelivery.notificationservice.client.SmsProviderClient;
import com.fooddelivery.notificationservice.client.UserServiceClient;
import com.fooddelivery.notificationservice.events.NotificationSentEvent;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * Notification Service - Handles all notification types
 * 
 * Cross-service interactions:
 * 1. REST API: Receives calls from User Service and Order Service
 * 2. Kafka Consumer: Listens to events from all services
 * 3. External APIs: Calls third-party notification providers
 * 4. Database: Stores notification logs in separate database
 */
@Service
@Transactional
public class NotificationService {

    private final NotificationLogRepository notificationLogRepository;
    private final EmailProviderClient emailProviderClient;
    private final SmsProviderClient smsProviderClient;
    private final UserServiceClient userServiceClient;
    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final RestTemplate restTemplate;

    @Autowired
    public NotificationService(NotificationLogRepository notificationLogRepository,
                             EmailProviderClient emailProviderClient,
                             SmsProviderClient smsProviderClient,
                             UserServiceClient userServiceClient,
                             KafkaTemplate<String, Object> kafkaTemplate,
                             RestTemplate restTemplate) {
        this.notificationLogRepository = notificationLogRepository;
        this.emailProviderClient = emailProviderClient;
        this.smsProviderClient = smsProviderClient;
        this.userServiceClient = userServiceClient;
        this.kafkaTemplate = kafkaTemplate;
        this.restTemplate = restTemplate;
    }

    /**
     * Send welcome email - Called via REST API from User Service
     * 
     * Data Flow:
     * User Service → REST API → Notification Service → Email Provider → User
     */
    @Transactional
    public void sendWelcomeEmail(String email, String fullName) {
        try {
            // Create email request
            EmailRequest emailRequest = new EmailRequest();
            emailRequest.setTo(email);
            emailRequest.setSubject("Welcome to Food Delivery Platform!");
            emailRequest.setTemplate("welcome");
            emailRequest.setTemplateData(Map.of(
                "fullName", fullName,
                "platformName", "Food Delivery Platform",
                "supportEmail", "support@fooddelivery.com"
            ));

            // Send via external email provider
            boolean sent = emailProviderClient.sendEmail(emailRequest);

            // Log notification
            NotificationLog log = new NotificationLog();
            log.setRecipient(email);
            log.setType("EMAIL");
            log.setSubject("Welcome Email");
            log.setStatus(sent ? "SENT" : "FAILED");
            log.setProvider("sendgrid");
            log.setSentAt(LocalDateTime.now());
            
            notificationLogRepository.save(log);

            // Publish notification event
            if (sent) {
                NotificationSentEvent event = new NotificationSentEvent(
                    log.getId(), "EMAIL", email, "SENT", LocalDateTime.now()
                );
                kafkaTemplate.send("notification-events", "notification.sent", event);
            }

        } catch (Exception e) {
            // Log failed notification
            NotificationLog log = new NotificationLog();
            log.setRecipient(email);
            log.setType("EMAIL");
            log.setSubject("Welcome Email");
            log.setStatus("FAILED");
            log.setErrorMessage(e.getMessage());
            log.setSentAt(LocalDateTime.now());
            
            notificationLogRepository.save(log);
            
            throw new RuntimeException("Failed to send welcome email", e);
        }
    }

    /**
     * Send order confirmation - Called via REST API from Order Service
     */
    @Transactional
    public void sendOrderConfirmation(Long userId, String orderNumber, String orderDetails) {
        try {
            // Get user details from User Service via REST API
            String userServiceUrl = "http://user-service/api/v1/users/" + userId;
            Map<String, Object> userResponse = restTemplate.getForObject(userServiceUrl, Map.class);
            
            if (userResponse == null) {
                throw new RuntimeException("User not found: " + userId);
            }

            String email = (String) userResponse.get("email");
            String fullName = (String) userResponse.get("fullName");

            // Send email
            EmailRequest emailRequest = new EmailRequest();
            emailRequest.setTo(email);
            emailRequest.setSubject("Order Confirmation - " + orderNumber);
            emailRequest.setTemplate("order-confirmation");
            emailRequest.setTemplateData(Map.of(
                "fullName", fullName,
                "orderNumber", orderNumber,
                "orderDetails", orderDetails,
                "trackingUrl", "https://fooddelivery.com/track/" + orderNumber
            ));

            boolean sent = emailProviderClient.sendEmail(emailRequest);

            // Log notification
            NotificationLog log = new NotificationLog();
            log.setUserId(userId);
            log.setRecipient(email);
            log.setType("EMAIL");
            log.setSubject("Order Confirmation");
            log.setStatus(sent ? "SENT" : "FAILED");
            log.setProvider("sendgrid");
            log.setRelatedEntityId(orderNumber);
            log.setSentAt(LocalDateTime.now());
            
            notificationLogRepository.save(log);

        } catch (Exception e) {
            NotificationLog log = new NotificationLog();
            log.setUserId(userId);
            log.setType("EMAIL");
            log.setSubject("Order Confirmation");
            log.setStatus("FAILED");
            log.setErrorMessage(e.getMessage());
            log.setSentAt(LocalDateTime.now());
            
            notificationLogRepository.save(log);
        }
    }

    /**
     * Kafka listener for user events from User Service
     * 
     * Data Flow:
     * User Service → Kafka → Notification Service → Email/SMS Provider
     */
    @KafkaListener(topics = "user-events", groupId = "notification-service-group")
    public void handleUserEvents(Map<String, Object> eventData) {
        String eventType = (String) eventData.get("eventType");
        
        switch (eventType) {
            case "user.created":
                handleUserCreatedEvent(eventData);
                break;
            case "user.updated":
                handleUserUpdatedEvent(eventData);
                break;
            case "user.email.verified":
                handleEmailVerifiedEvent(eventData);
                break;
            default:
                System.out.println("Unknown user event type: " + eventType);
        }
    }

    /**
     * Kafka listener for order events from Order Service
     */
    @KafkaListener(topics = "order-events", groupId = "notification-service-group")
    public void handleOrderEvents(Map<String, Object> eventData) {
        String eventType = (String) eventData.get("eventType");
        
        switch (eventType) {
            case "order.placed":
                handleOrderPlacedEvent(eventData);
                break;
            case "order.confirmed":
                handleOrderConfirmedEvent(eventData);
                break;
            case "order.preparing":
                handleOrderPreparingEvent(eventData);
                break;
            case "order.out_for_delivery":
                handleOrderOutForDeliveryEvent(eventData);
                break;
            case "order.delivered":
                handleOrderDeliveredEvent(eventData);
                break;
            default:
                System.out.println("Unknown order event type: " + eventType);
        }
    }

    /**
     * Handle user created event from Kafka
     */
    private void handleUserCreatedEvent(Map<String, Object> eventData) {
        Long userId = ((Number) eventData.get("userId")).longValue();
        String email = (String) eventData.get("email");
        String fullName = (String) eventData.get("fullName");

        // Send welcome email (duplicate handling - could be called via REST or Kafka)
        try {
            // Check if welcome email already sent
            boolean alreadySent = notificationLogRepository.existsByUserIdAndTypeAndSubject(
                userId, "EMAIL", "Welcome Email"
            );
            
            if (!alreadySent) {
                sendWelcomeEmail(email, fullName);
            }
        } catch (Exception e) {
            System.err.println("Failed to send welcome email via Kafka: " + e.getMessage());
        }
    }

    /**
     * Handle order placed event from Kafka
     */
    private void handleOrderPlacedEvent(Map<String, Object> eventData) {
        Long userId = ((Number) eventData.get("userId")).longValue();
        String orderNumber = (String) eventData.get("orderNumber");
        
        try {
            // Send push notification
            PushNotificationRequest pushRequest = new PushNotificationRequest();
            pushRequest.setUserId(userId);
            pushRequest.setTitle("Order Placed Successfully!");
            pushRequest.setBody("Your order " + orderNumber + " has been placed. We'll notify you when it's ready.");
            pushRequest.setData(Map.of(
                "orderNumber", orderNumber,
                "type", "order_placed"
            ));

            // This would call Firebase Cloud Messaging
            // pushNotificationClient.sendPushNotification(pushRequest);

            // Log notification
            NotificationLog log = new NotificationLog();
            log.setUserId(userId);
            log.setType("PUSH");
            log.setSubject("Order Placed");
            log.setStatus("SENT");
            log.setProvider("firebase");
            log.setRelatedEntityId(orderNumber);
            log.setSentAt(LocalDateTime.now());
            
            notificationLogRepository.save(log);

        } catch (Exception e) {
            System.err.println("Failed to send order placed notification: " + e.getMessage());
        }
    }

    /**
     * Handle order delivered event from Kafka
     */
    private void handleOrderDeliveredEvent(Map<String, Object> eventData) {
        Long userId = ((Number) eventData.get("userId")).longValue();
        String orderNumber = (String) eventData.get("orderNumber");
        
        try {
            // Get user phone number from User Service
            String userServiceUrl = "http://user-service/api/v1/users/" + userId;
            Map<String, Object> userResponse = restTemplate.getForObject(userServiceUrl, Map.class);
            
            if (userResponse != null) {
                String phoneNumber = (String) userResponse.get("phoneNumber");
                
                // Send SMS notification
                SmsRequest smsRequest = new SmsRequest();
                smsRequest.setTo(phoneNumber);
                smsRequest.setMessage("Your order " + orderNumber + " has been delivered! Enjoy your meal! Rate your experience: https://fooddelivery.com/rate/" + orderNumber);

                boolean sent = smsProviderClient.sendSms(smsRequest);

                // Log notification
                NotificationLog log = new NotificationLog();
                log.setUserId(userId);
                log.setRecipient(phoneNumber);
                log.setType("SMS");
                log.setSubject("Order Delivered");
                log.setStatus(sent ? "SENT" : "FAILED");
                log.setProvider("twilio");
                log.setRelatedEntityId(orderNumber);
                log.setSentAt(LocalDateTime.now());
                
                notificationLogRepository.save(log);
            }

        } catch (Exception e) {
            System.err.println("Failed to send order delivered SMS: " + e.getMessage());
        }
    }

    /**
     * Get notification statistics - Called by other services
     */
    @Transactional(readOnly = true)
    public NotificationStats getNotificationStats(Long userId) {
        long totalSent = notificationLogRepository.countByUserIdAndStatus(userId, "SENT");
        long totalFailed = notificationLogRepository.countByUserIdAndStatus(userId, "FAILED");
        long emailsSent = notificationLogRepository.countByUserIdAndTypeAndStatus(userId, "EMAIL", "SENT");
        long smsSent = notificationLogRepository.countByUserIdAndTypeAndStatus(userId, "SMS", "SENT");
        long pushSent = notificationLogRepository.countByUserIdAndTypeAndStatus(userId, "PUSH", "SENT");
        
        return new NotificationStats(userId, totalSent, totalFailed, emailsSent, smsSent, pushSent);
    }

    // Helper methods for other event types
    private void handleUserUpdatedEvent(Map<String, Object> eventData) {
        // Handle user profile updates
    }

    private void handleEmailVerifiedEvent(Map<String, Object> eventData) {
        // Send email verification confirmation
    }

    private void handleOrderConfirmedEvent(Map<String, Object> eventData) {
        // Send order confirmation notification
    }

    private void handleOrderPreparingEvent(Map<String, Object> eventData) {
        // Send order preparation notification
    }

    private void handleOrderOutForDeliveryEvent(Map<String, Object> eventData) {
        // Send out for delivery notification
    }

    /**
     * Notification statistics DTO
     */
    public static class NotificationStats {
        private Long userId;
        private Long totalSent;
        private Long totalFailed;
        private Long emailsSent;
        private Long smsSent;
        private Long pushSent;

        public NotificationStats(Long userId, Long totalSent, Long totalFailed, 
                               Long emailsSent, Long smsSent, Long pushSent) {
            this.userId = userId;
            this.totalSent = totalSent;
            this.totalFailed = totalFailed;
            this.emailsSent = emailsSent;
            this.smsSent = smsSent;
            this.pushSent = pushSent;
        }

        // Getters and setters
        public Long getUserId() { return userId; }
        public void setUserId(Long userId) { this.userId = userId; }
        
        public Long getTotalSent() { return totalSent; }
        public void setTotalSent(Long totalSent) { this.totalSent = totalSent; }
        
        public Long getTotalFailed() { return totalFailed; }
        public void setTotalFailed(Long totalFailed) { this.totalFailed = totalFailed; }
        
        public Long getEmailsSent() { return emailsSent; }
        public void setEmailsSent(Long emailsSent) { this.emailsSent = emailsSent; }
        
        public Long getSmsSent() { return smsSent; }
        public void setSmsSent(Long smsSent) { this.smsSent = smsSent; }
        
        public Long getPushSent() { return pushSent; }
        public void setPushSent(Long pushSent) { this.pushSent = pushSent; }
    }
}

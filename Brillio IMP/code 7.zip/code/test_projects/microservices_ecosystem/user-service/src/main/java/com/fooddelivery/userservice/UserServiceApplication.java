package com.fooddelivery.userservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * User Service Application - Microservice for user management
 * 
 * Responsibilities:
 * - User registration and authentication
 * - Profile management
 * - JWT token generation
 * - User events publishing to Kafka
 * - Shared database access with Order Service
 */
@SpringBootApplication
@EnableEurekaClient
@EnableJpaAuditing
@EnableCaching
@EnableKafka
@EnableAsync
@EnableTransactionManagement
public class UserServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(UserServiceApplication.class, args);
    }
}

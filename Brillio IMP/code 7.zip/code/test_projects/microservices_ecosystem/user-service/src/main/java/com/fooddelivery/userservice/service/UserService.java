package com.fooddelivery.userservice.service;

import com.fooddelivery.userservice.entity.User;
import com.fooddelivery.userservice.repository.UserRepository;
import com.fooddelivery.userservice.dto.UserRegistrationRequest;
import com.fooddelivery.userservice.dto.UserResponse;
import com.fooddelivery.userservice.events.UserCreatedEvent;
import com.fooddelivery.userservice.events.UserUpdatedEvent;
import com.fooddelivery.userservice.exception.UserNotFoundException;
import com.fooddelivery.userservice.exception.EmailAlreadyExistsException;
import com.fooddelivery.userservice.client.NotificationServiceClient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * User Service - Core business logic for user management
 * 
 * Cross-service interactions:
 * 1. Database: Shared database with Order Service
 * 2. Kafka: Publishes user events for other services
 * 3. REST API: Calls Notification Service for welcome emails
 * 4. Cache: Redis for user profile caching
 */
@Service
@Transactional
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final NotificationServiceClient notificationClient;
    private final JwtTokenService jwtTokenService;

    @Autowired
    public UserService(UserRepository userRepository,
                      PasswordEncoder passwordEncoder,
                      KafkaTemplate<String, Object> kafkaTemplate,
                      NotificationServiceClient notificationClient,
                      JwtTokenService jwtTokenService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.kafkaTemplate = kafkaTemplate;
        this.notificationClient = notificationClient;
        this.jwtTokenService = jwtTokenService;
    }

    /**
     * Register new user - Demonstrates cross-service communication
     * 
     * Data Flow:
     * 1. Save user to shared database
     * 2. Publish UserCreatedEvent to Kafka (consumed by Order Service)
     * 3. Call Notification Service REST API for welcome email
     * 4. Cache user profile in Redis
     */
    @Transactional
    public UserResponse registerUser(UserRegistrationRequest request) {
        // Check if email already exists in shared database
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new EmailAlreadyExistsException("Email already registered: " + request.getEmail());
        }

        // Create new user entity
        User user = new User();
        user.setFullName(request.getFullName());
        user.setEmail(request.getEmail());
        user.setPhoneNumber(request.getPhoneNumber());
        user.setPasswordHash(passwordEncoder.encode(request.getPassword()));

        // Save to shared database (accessible by Order Service)
        User savedUser = userRepository.save(user);

        // Publish event to Kafka - Order Service will consume this
        UserCreatedEvent event = new UserCreatedEvent(
            savedUser.getUserId(),
            savedUser.getEmail(),
            savedUser.getFullName(),
            savedUser.getCreatedAt()
        );
        kafkaTemplate.send("user-events", "user.created", event);

        // Call Notification Service via REST API
        try {
            notificationClient.sendWelcomeEmail(savedUser.getEmail(), savedUser.getFullName());
        } catch (Exception e) {
            // Log error but don't fail registration
            System.err.println("Failed to send welcome email: " + e.getMessage());
        }

        return convertToUserResponse(savedUser);
    }

    /**
     * Authenticate user - Demonstrates JWT token generation
     */
    @Transactional
    public String authenticateUser(String email, String password) {
        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new UserNotFoundException("User not found: " + email));

        // Check if account is locked
        if (user.isAccountLocked()) {
            throw new RuntimeException("Account is locked until: " + user.getAccountLockedUntil());
        }

        // Verify password
        if (!passwordEncoder.matches(password, user.getPasswordHash())) {
            user.incrementFailedLoginAttempts();
            
            // Lock account after 5 failed attempts
            if (user.getFailedLoginAttempts() >= 5) {
                user.lockAccount(1800); // 30 minutes
            }
            
            userRepository.save(user);
            throw new RuntimeException("Invalid credentials");
        }

        // Successful login
        user.updateLastLogin();
        userRepository.save(user);

        // Generate JWT token
        return jwtTokenService.generateToken(user);
    }

    /**
     * Get user profile with caching
     */
    @Cacheable(value = "user-profiles", key = "#userId")
    @Transactional(readOnly = true)
    public UserResponse getUserProfile(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException("User not found: " + userId));
        
        return convertToUserResponse(user);
    }

    /**
     * Update user profile - Demonstrates cache eviction and event publishing
     */
    @CacheEvict(value = "user-profiles", key = "#userId")
    @Transactional
    public UserResponse updateUserProfile(Long userId, UserRegistrationRequest updateRequest) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException("User not found: " + userId));

        // Update user fields
        if (updateRequest.getFullName() != null) {
            user.setFullName(updateRequest.getFullName());
        }
        
        if (updateRequest.getPhoneNumber() != null) {
            user.setPhoneNumber(updateRequest.getPhoneNumber());
        }

        User updatedUser = userRepository.save(user);

        // Publish update event to Kafka
        UserUpdatedEvent event = new UserUpdatedEvent(
            updatedUser.getUserId(),
            updatedUser.getEmail(),
            updatedUser.getFullName(),
            updatedUser.getUpdatedAt()
        );
        kafkaTemplate.send("user-events", "user.updated", event);

        return convertToUserResponse(updatedUser);
    }

    /**
     * Verify email - Called by Notification Service callback
     */
    @CacheEvict(value = "user-profiles", key = "#userId")
    @Transactional
    public void verifyEmail(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException("User not found: " + userId));

        user.setEmailVerified(true);
        userRepository.save(user);

        // Publish verification event
        kafkaTemplate.send("user-events", "user.email.verified", 
            new UserUpdatedEvent(user.getUserId(), user.getEmail(), user.getFullName(), LocalDateTime.now()));
    }

    /**
     * Get user by email - Used by Order Service for cross-service queries
     */
    @Transactional(readOnly = true)
    public Optional<UserResponse> getUserByEmail(String email) {
        return userRepository.findByEmail(email)
            .map(this::convertToUserResponse);
    }

    /**
     * Check if user exists - Used by Order Service before creating orders
     */
    @Transactional(readOnly = true)
    public boolean userExists(Long userId) {
        return userRepository.existsById(userId);
    }

    /**
     * Get user statistics for analytics
     */
    @Transactional(readOnly = true)
    public UserStats getUserStats(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new UserNotFoundException("User not found: " + userId));

        // This would typically call Order Service to get order count
        // For now, we'll simulate it
        long totalOrders = 0; // Would be: orderServiceClient.getUserOrderCount(userId);
        
        return new UserStats(
            userId,
            totalOrders,
            user.getAddresses() != null ? user.getAddresses().size() : 0,
            user.getCreatedAt(),
            user.getLastLoginAt()
        );
    }

    /**
     * Convert User entity to UserResponse DTO
     */
    private UserResponse convertToUserResponse(User user) {
        UserResponse response = new UserResponse();
        response.setUserId(user.getUserId());
        response.setFullName(user.getFullName());
        response.setEmail(user.getEmail());
        response.setPhoneNumber(user.getPhoneNumber());
        response.setStatus(user.getStatus().toString());
        response.setEmailVerified(user.getEmailVerified());
        response.setPhoneVerified(user.getPhoneVerified());
        response.setProfileImageUrl(user.getProfileImageUrl());
        response.setLastLoginAt(user.getLastLoginAt());
        response.setCreatedAt(user.getCreatedAt());
        response.setUpdatedAt(user.getUpdatedAt());
        
        return response;
    }

    /**
     * User statistics DTO
     */
    public static class UserStats {
        private Long userId;
        private Long totalOrders;
        private Long totalAddresses;
        private LocalDateTime memberSince;
        private LocalDateTime lastLogin;

        public UserStats(Long userId, Long totalOrders, Long totalAddresses, 
                        LocalDateTime memberSince, LocalDateTime lastLogin) {
            this.userId = userId;
            this.totalOrders = totalOrders;
            this.totalAddresses = totalAddresses;
            this.memberSince = memberSince;
            this.lastLogin = lastLogin;
        }

        // Getters and setters
        public Long getUserId() { return userId; }
        public void setUserId(Long userId) { this.userId = userId; }
        
        public Long getTotalOrders() { return totalOrders; }
        public void setTotalOrders(Long totalOrders) { this.totalOrders = totalOrders; }
        
        public Long getTotalAddresses() { return totalAddresses; }
        public void setTotalAddresses(Long totalAddresses) { this.totalAddresses = totalAddresses; }
        
        public LocalDateTime getMemberSince() { return memberSince; }
        public void setMemberSince(LocalDateTime memberSince) { this.memberSince = memberSince; }
        
        public LocalDateTime getLastLogin() { return lastLogin; }
        public void setLastLogin(LocalDateTime lastLogin) { this.lastLogin = lastLogin; }
    }
}

-- Shared Database Migration Script
-- Database: fooddelivery_shared_db
-- 
-- This database is shared between User Service and Order Service
-- Demonstrates cross-service data relationships and shared data access patterns

-- Create schemas for different services
CREATE SCHEMA IF NOT EXISTS user_schema;
CREATE SCHEMA IF NOT EXISTS order_schema;

-- =====================================================
-- USER SCHEMA - Managed by User Service
-- =====================================================

-- Users table - Primary table managed by User Service
CREATE TABLE user_schema.users (
    user_id BIGSERIAL PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone_number VARCHAR(15) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    email_verified BOOLEAN DEFAULT FALSE,
    phone_verified BOOLEAN DEFAULT FALSE,
    profile_image_url VARCHAR(500),
    last_login_at TIMESTAMP,
    failed_login_attempts INTEGER DEFAULT 0,
    account_locked_until TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_user_status CHECK (status IN ('ACTIVE', 'INACTIVE', 'SUSPENDED', 'DELETED')),
    CONSTRAINT chk_email_format CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'),
    CONSTRAINT chk_phone_format CHECK (phone_number ~* '^\+?[1-9]\d{1,14}$')
);

-- User addresses table - Managed by User Service
CREATE TABLE user_schema.user_addresses (
    address_id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES user_schema.users(user_id) ON DELETE CASCADE,
    address_line1 VARCHAR(200) NOT NULL,
    address_line2 VARCHAR(200),
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    postal_code VARCHAR(10) NOT NULL,
    landmark VARCHAR(200),
    address_type VARCHAR(20) NOT NULL DEFAULT 'HOME',
    is_default BOOLEAN DEFAULT FALSE,
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_address_type CHECK (address_type IN ('HOME', 'WORK', 'OTHER')),
    CONSTRAINT chk_postal_code CHECK (postal_code ~ '^[0-9]{5,6}$')
);

-- =====================================================
-- ORDER SCHEMA - Managed by Order Service
-- =====================================================

-- Orders table - Managed by Order Service, references User Service data
CREATE TABLE order_schema.orders (
    order_id BIGSERIAL PRIMARY KEY,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    
    -- Cross-service foreign key reference
    -- References user_schema.users.user_id (managed by User Service)
    user_id BIGINT NOT NULL,
    
    restaurant_id BIGINT NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'PLACED',
    subtotal DECIMAL(10,2) NOT NULL,
    delivery_fee DECIMAL(8,2),
    tax_amount DECIMAL(8,2),
    discount_amount DECIMAL(8,2) DEFAULT 0.00,
    total_amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50),
    payment_status VARCHAR(20) DEFAULT 'PENDING',
    delivery_address TEXT,
    delivery_latitude DECIMAL(10,8),
    delivery_longitude DECIMAL(11,8),
    estimated_delivery_time TIMESTAMP,
    actual_delivery_time TIMESTAMP,
    special_instructions TEXT,
    driver_id BIGINT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_order_status CHECK (status IN ('PLACED', 'CONFIRMED', 'PREPARING', 'READY_FOR_PICKUP', 'OUT_FOR_DELIVERY', 'DELIVERED', 'CANCELLED')),
    CONSTRAINT chk_payment_status CHECK (payment_status IN ('PENDING', 'PAID', 'FAILED', 'REFUNDED')),
    CONSTRAINT chk_positive_amounts CHECK (subtotal > 0 AND total_amount > 0),
    
    -- Foreign key constraint across schemas (cross-service reference)
    CONSTRAINT fk_order_user FOREIGN KEY (user_id) REFERENCES user_schema.users(user_id)
);

-- Order items table - Managed by Order Service
CREATE TABLE order_schema.order_items (
    order_item_id BIGSERIAL PRIMARY KEY,
    order_id BIGINT NOT NULL REFERENCES order_schema.orders(order_id) ON DELETE CASCADE,
    menu_item_id BIGINT NOT NULL,
    item_name VARCHAR(200) NOT NULL,
    quantity INTEGER NOT NULL,
    unit_price DECIMAL(8,2) NOT NULL,
    total_price DECIMAL(8,2) NOT NULL,
    special_requests TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_positive_quantity CHECK (quantity > 0),
    CONSTRAINT chk_positive_unit_price CHECK (unit_price > 0),
    CONSTRAINT chk_correct_total CHECK (total_price = unit_price * quantity)
);

-- Payments table - Managed by Order Service
CREATE TABLE order_schema.payments (
    payment_id BIGSERIAL PRIMARY KEY,
    order_id BIGINT NOT NULL REFERENCES order_schema.orders(order_id) ON DELETE CASCADE,
    payment_method VARCHAR(50) NOT NULL,
    payment_provider VARCHAR(50) NOT NULL,
    transaction_id VARCHAR(100) UNIQUE,
    amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'USD',
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    gateway_response JSONB,
    processed_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_payment_status CHECK (status IN ('PENDING', 'PROCESSING', 'COMPLETED', 'FAILED', 'REFUNDED')),
    CONSTRAINT chk_positive_amount CHECK (amount > 0)
);

-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================

-- User schema indexes
CREATE INDEX idx_users_email ON user_schema.users(email);
CREATE INDEX idx_users_phone ON user_schema.users(phone_number);
CREATE INDEX idx_users_status ON user_schema.users(status);
CREATE INDEX idx_users_created_at ON user_schema.users(created_at);

CREATE INDEX idx_user_addresses_user ON user_schema.user_addresses(user_id);
CREATE INDEX idx_user_addresses_default ON user_schema.user_addresses(user_id, is_default) WHERE is_default = TRUE;

-- Order schema indexes
CREATE INDEX idx_orders_user_id ON order_schema.orders(user_id);
CREATE INDEX idx_orders_status ON order_schema.orders(status);
CREATE INDEX idx_orders_created_at ON order_schema.orders(created_at DESC);
CREATE INDEX idx_orders_number ON order_schema.orders(order_number);

CREATE INDEX idx_order_items_order ON order_schema.order_items(order_id);
CREATE INDEX idx_order_items_menu ON order_schema.order_items(menu_item_id);

CREATE INDEX idx_payments_order ON order_schema.payments(order_id);
CREATE INDEX idx_payments_transaction ON order_schema.payments(transaction_id);
CREATE INDEX idx_payments_status ON order_schema.payments(status);

-- =====================================================
-- CROSS-SERVICE VIEWS
-- =====================================================

-- View for Order Service to get user details with orders
CREATE VIEW order_schema.user_order_summary AS
SELECT 
    u.user_id,
    u.full_name,
    u.email,
    u.phone_number,
    u.status as user_status,
    COUNT(o.order_id) as total_orders,
    COALESCE(SUM(o.total_amount), 0) as total_spent,
    MAX(o.created_at) as last_order_date
FROM user_schema.users u
LEFT JOIN order_schema.orders o ON u.user_id = o.user_id
GROUP BY u.user_id, u.full_name, u.email, u.phone_number, u.status;

-- View for User Service to get user order statistics
CREATE VIEW user_schema.user_order_stats AS
SELECT 
    u.user_id,
    COUNT(o.order_id) as total_orders,
    COUNT(CASE WHEN o.status = 'DELIVERED' THEN 1 END) as completed_orders,
    COUNT(CASE WHEN o.status = 'CANCELLED' THEN 1 END) as cancelled_orders,
    COALESCE(AVG(o.total_amount), 0) as average_order_value,
    COALESCE(SUM(o.total_amount), 0) as total_spent,
    MAX(o.created_at) as last_order_date
FROM user_schema.users u
LEFT JOIN order_schema.orders o ON u.user_id = o.user_id
GROUP BY u.user_id;

-- =====================================================
-- TRIGGERS FOR AUDIT TRAILS
-- =====================================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers for updated_at
CREATE TRIGGER update_users_updated_at 
    BEFORE UPDATE ON user_schema.users 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_addresses_updated_at 
    BEFORE UPDATE ON user_schema.user_addresses 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_orders_updated_at 
    BEFORE UPDATE ON order_schema.orders 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_payments_updated_at 
    BEFORE UPDATE ON order_schema.payments 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- PERMISSIONS FOR CROSS-SERVICE ACCESS
-- =====================================================

-- Grant User Service permissions
GRANT ALL PRIVILEGES ON SCHEMA user_schema TO fooddelivery_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA user_schema TO fooddelivery_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA user_schema TO fooddelivery_user;

-- Grant Order Service permissions
GRANT ALL PRIVILEGES ON SCHEMA order_schema TO fooddelivery_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA order_schema TO fooddelivery_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA order_schema TO fooddelivery_user;

-- Grant Order Service read access to User schema (for cross-service queries)
GRANT SELECT ON user_schema.users TO fooddelivery_user;
GRANT SELECT ON user_schema.user_addresses TO fooddelivery_user;
GRANT SELECT ON user_schema.user_order_stats TO fooddelivery_user;

-- Grant User Service read access to Order schema (for user statistics)
GRANT SELECT ON order_schema.orders TO fooddelivery_user;
GRANT SELECT ON order_schema.user_order_summary TO fooddelivery_user;

-- Comments for documentation
COMMENT ON SCHEMA user_schema IS 'Schema managed by User Service - contains user profiles and addresses';
COMMENT ON SCHEMA order_schema IS 'Schema managed by Order Service - contains orders, payments, and order items';

COMMENT ON TABLE user_schema.users IS 'Users table - shared read access with Order Service for order processing';
COMMENT ON TABLE order_schema.orders IS 'Orders table - references users across service boundary';

COMMENT ON VIEW order_schema.user_order_summary IS 'Cross-service view for Order Service to access user data with order statistics';
COMMENT ON VIEW user_schema.user_order_stats IS 'Cross-service view for User Service to access order statistics';

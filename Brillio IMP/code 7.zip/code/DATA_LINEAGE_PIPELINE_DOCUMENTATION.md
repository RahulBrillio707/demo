# Data Lineage Pipeline - Complete Documentation

## Overview

This is a comprehensive **7-agent data lineage pipeline** that analyzes Java applications to create detailed code and data lineage graphs. The pipeline uses **AST-based parsing** with **LLM-powered variable transformation analysis** to track data flow from application level down to individual variables and database operations.

## Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Agent 1       │    │   Agent 2       │    │   Agent 3       │
│   Collector     │───▶│   AST Parser    │───▶│   Framework     │
│                 │    │                 │    │   Detection     │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Agent 4       │    │   Agent 5       │    │   Agent 6       │
│   Symbol Tables │    │   Variable      │    │   Normalization │
│                 │    │   Transformations│    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         └───────────────────────┼───────────────────────┘
                                 ▼
                    ┌─────────────────┐
                    │   Agent 7       │
                    │   Neo4j Graph   │
                    │   Builder       │
                    └─────────────────┘
```

## Pipeline Flow

### Stage 1: File Collection
**Agent 1 - Collector** → `collection.json`

### Stage 2: AST Parsing & Chunking  
**Agent 2 - AST Parser** → `chunks.json` + `parsing.json`

### Stage 3: Framework Detection
**Agent 3 - Framework Detection** → Updates `parsing.json`

### Stage 4: Symbol Table Generation
**Agent 4 - Symbol Tables** → `symbols.csv`, `operations.csv`, `variables.csv`

### Stage 5: Variable Transformation Analysis
**Agent 5 - LLM Transformations** → `variable_transformations.json` + `merged_lineage.json`

### Stage 6: Data Normalization
**Agent 6 - Normalization** → `final_lineage.json`

### Stage 7: Graph Database Loading
**Agent 7 - Neo4j Builder** → Neo4j Database + `neo4j_load_summary.json`

---

## Detailed Agent Documentation

## Agent 1: File Collector

### Purpose
Scans the repository and collects all relevant files for processing.

### Input
- Repository path (local or git)

### Processing
1. **Recursive file scanning** with directory filtering
2. **File type classification**:
   - `.java` → Java source files
   - `.sql` → Database migration files  
   - `.yml`, `.properties`, `pom.xml` → Configuration files
3. **Metadata extraction**: file size, path, type

### Output: `collection.json`
```json
{
  "repository_path": "path/to/repo",
  "total_files": 15,
  "files": [
    {
      "name": "UserController.java",
      "path": "src/main/java/com/swiggy/controller/UserController.java", 
      "relative_path": "src/main/java/com/swiggy/controller/UserController.java",
      "type": "java",
      "size": 2048
    }
  ],
  "file_types": {
    "java": 9,
    "sql": 2, 
    "config": 4
  }
}
```

### Key Features
- ✅ Filters out build directories (`target`, `build`, `node_modules`)
- ✅ Handles both local and git repositories
- ✅ Comprehensive file type detection

---

## Agent 2: AST Parser & Method Chunking

### Purpose
**Revolutionary AST-based parsing** that replaces unreliable regex with accurate Java syntax tree analysis.

### Input
- `collection.json` (file list)

### Processing

#### 1. **AST-Based Java Parsing** (Primary)
- Uses **javalang** library for accurate Java parsing
- Extracts: packages, classes, interfaces, methods, fields, parameters
- Handles: inheritance, annotations, modifiers, generics

#### 2. **Fallback Regex Parsing** (For Complex Files)
- Handles files that AST can't parse (e.g., complex SQL annotations)
- Graceful degradation with regex-based extraction

#### 3. **Method Chunking**
- Extracts method body content using AST position information
- **Enhanced variable extraction** with comprehensive patterns:
  ```regex
  # Variable declarations: Type var = value
  # Field access: this.field, object.method
  # Method parameters: method(param1, param2)
  # Return statements: return variable
  # Assignments: variable = value
  ```

#### 4. **Operation Detection**
- `RETURN`, `ASSIGNMENT`, `SAVE`, `READ`, `DELETE`, `ANNOTATION`

### Output: `chunks.json` + `parsing.json`

#### `chunks.json` - Method Chunks
```json
{
  "total_chunks": 286,
  "method_chunks": [
    {
      "chunk_id": "uuid",
      "file_path": "src/main/java/com/swiggy/controller/UserController.java",
      "method_name": "registerUser", 
      "class_name": "UserController",
      "content": "UserResponse userResponse = userService.registerUser(request);\nreturn new ResponseEntity<>(userResponse, HttpStatus.CREATED);",
      "variables": ["userResponse", "request"],
      "operations": ["RETURN", "ASSIGNMENT"],
      "dependencies": []
    }
  ]
}
```

#### `parsing.json` - AST Structure
```json
{
  "total_nodes": 536,
  "nodes": [
    {
      "node_id": "uuid",
      "node_type": "Class",
      "name": "UserController", 
      "properties": {
        "file_path": "src/main/java/com/swiggy/controller/UserController.java",
        "package_name": "com.swiggy.controller",
        "full_name": "com.swiggy.controller.UserController"
      }
    }
  ],
  "total_relationships": 535,
  "relationships": [
    {
      "relationship_id": "uuid",
      "source_id": "class_uuid",
      "target_id": "method_uuid", 
      "relationship_type": "contains",
      "properties": {}
    }
  ]
}
```

### Key Improvements Over Regex
- ✅ **Fixed "class for" bug** - No more false matches from comments
- ✅ **Accurate class/interface detection** - Proper Java syntax understanding  
- ✅ **Better variable extraction** - 15+ patterns vs 3 basic regex patterns
- ✅ **Interface method support** - Handles Spring Data repositories
- ✅ **Graceful error handling** - Fallback parsing for complex files

---

## Agent 3: Framework Detection

### Purpose
Identifies Java frameworks and technologies used in the codebase.

### Input
- `parsing.json` (AST structure)

### Processing
1. **Annotation-based detection**:
   - `@RestController`, `@Service`, `@Repository`, `@Entity`
   - `@SpringBootApplication`, `@EnableJpaAuditing`
2. **Import-based detection**:
   - Spring Boot, Spring Data JPA, Kafka, Redis
3. **Configuration analysis**:
   - `application.yml`, `pom.xml` dependencies

### Output
Updates `parsing.json` with framework information:
```json
{
  "frameworks": {
    "detected_frameworks": [
      "Spring Boot",
      "Spring Data JPA", 
      "Apache Kafka",
      "Redis",
      "PostgreSQL"
    ],
    "framework_details": {
      "spring_boot": {
        "version": "2.7.0",
        "components": ["web", "data-jpa", "security"]
      }
    }
  }
}
```

### Key Features
- ✅ Multi-layer detection (annotations + imports + config)
- ✅ Version extraction from build files
- ✅ Component-level framework analysis

---

## Agent 4: Symbol Table Generation

### Purpose
Creates comprehensive symbol tables for methods, variables, and operations.

### Input
- `chunks.json` (method chunks)
- `parsing.json` (AST structure)

### Processing
1. **Method Symbol Extraction**:
   - Method signatures, parameters, return types
   - Access modifiers, static/instance classification
2. **Variable Symbol Analysis**:
   - Local variables, parameters, field references
   - Data types, scope analysis
3. **Operation Mapping**:
   - CRUD operations, method calls, assignments
   - Database operations, API calls

### Output: 4 CSV Files

#### `symbols.csv` - Method Symbols
```csv
symbol_id,symbol_name,symbol_type,class_name,file_path,visibility,is_static
uuid,registerUser,method,UserController,src/main/java/.../UserController.java,public,false
```

#### `operations.csv` - Operations
```csv
operation_id,operation_name,operation_type,method_id,line_number
uuid,ASSIGNMENT,variable_assignment,method_uuid,1
```

#### `variables.csv` - Variables
```csv
variable_id,variable_name,data_type,scope,method_id,line_number
uuid,userResponse,UserResponse,local,method_uuid,1
```

#### `lineage.csv` - Basic Lineage
```csv
lineage_id,source_id,target_id,relationship_type,confidence
uuid,method_uuid,variable_uuid,declares,0.9
```

### Key Features
- ✅ Comprehensive symbol extraction
- ✅ Cross-reference mapping
- ✅ Structured CSV output for analysis

---

## Agent 5: Variable Transformation Analysis (LLM-Powered)

### Purpose
**The heart of the pipeline** - Uses LLM to analyze detailed variable transformations within methods.

### Input
- `chunks.json` (method chunks with variables)
- `parsing.json` (for merging)

### Processing

#### 1. **LLM Analysis Per Method Chunk**
For each method chunk, sends detailed prompt to **Gemini LLM**:

```
Analyze this Java method for detailed variable transformations and create nodes and relationships.

Method: registerUser
Class: UserController
Variables: ['userResponse', 'request']

Code:
UserResponse userResponse = userService.registerUser(request);
return new ResponseEntity<>(userResponse, HttpStatus.CREATED);

Create detailed variable lineage with these patterns:
1. method → declares → variable
2. variable → flows_to → operation → transforms_to → variable
3. variable → pass_to → method → transforms_to → variable

Return ONLY a JSON object with nodes and relationships...
```

#### 2. **LLM Response Processing**
Parses LLM JSON response into structured nodes and relationships:

```json
{
  "nodes": [
    {
      "node_id": "uuid",
      "node_type": "variable",
      "name": "userResponse",
      "properties": {
        "data_type": "UserResponse",
        "scope": "local",
        "line_number": 1
      }
    },
    {
      "node_id": "uuid",
      "node_type": "operation",
      "name": "registerUser_call",
      "properties": {
        "operation_type": "method_call"
      }
    }
  ],
  "relationships": [
    {
      "relationship_id": "uuid",
      "source_id": "method_uuid",
      "target_id": "variable_uuid",
      "relationship_type": "declares",
      "properties": {
        "line_number": 1
      }
    },
    {
      "relationship_id": "uuid",
      "source_id": "variable_uuid",
      "target_id": "operation_uuid",
      "relationship_type": "flows_to",
      "properties": {
        "flow_type": "data_flow"
      }
    }
  ]
}
```

#### 3. **Intelligent Merging**
Combines LLM-generated variable nodes/relationships with existing parser output:

- **Preserves** application → class → method structure from Agent 2
- **Adds** detailed variable → operation → variable transformations
- **Avoids duplicates** using node_id and relationship_id matching

### Output: `variable_transformations.json` + `merged_lineage.json`

#### `variable_transformations.json` - LLM Analysis Results
```json
{
  "total_transformations": 286,
  "total_variable_nodes": 1247,
  "total_variable_relationships": 1893,
  "transformations": [
    {
      "transformation_id": "uuid",
      "method_id": "method_uuid",
      "method_name": "registerUser",
      "class_name": "UserController",
      "nodes": [...],
      "relationships": [...],
      "analysis_type": "llm_detailed",
      "confidence": 0.9
    }
  ]
}
```

#### `merged_lineage.json` - Complete Application-to-Variable Lineage
```json
{
  "total_nodes": 1783,
  "total_relationships": 2428,
  "nodes": [...], // Original 536 + Variable 1247 = 1783
  "relationships": [...], // Original 535 + Variable 1893 = 2428
  "merge_stats": {
    "original_nodes": 536,
    "added_variable_nodes": 1247,
    "final_nodes": 1783
  }
}
```

### Key Breakthrough Features
- ✅ **LLM-powered analysis** - Understands complex Java semantics
- ✅ **Variable-level granularity** - Tracks individual variable transformations
- ✅ **Pattern recognition** - Identifies declares, flows_to, transforms_to, pass_to patterns
- ✅ **Intelligent merging** - Combines with existing AST structure
- ✅ **Complete lineage** - Application → Package → Class → Method → Variable → Operation

---

## Agent 6: Data Normalization

### Purpose
Creates the final normalized lineage by combining all previous outputs and removing duplicates.

### Input
- `variable_transformations.json` (with merged_lineage)
- `parsing.json` (fallback if no merged data)

### Processing
1. **Smart Data Selection**:
   - Uses `merged_lineage` if available (preferred)
   - Falls back to separate parsing + transformation files
2. **Duplicate Removal**:
   - Node deduplication by `node_id`
   - Relationship deduplication by `relationship_id`
3. **Metadata Enhancement**:
   - Adds transformation statistics
   - Calculates confidence scores
   - Creates method flow summaries

### Output: `final_lineage.json`
```json
{
  "repository_path": "test_projects/swiggy_backend",
  "metadata": {
    "total_nodes": 1783,
    "total_relationships": 2428,
    "total_transformations": 286,
    "total_variable_nodes": 1247,
    "total_variable_relationships": 1893,
    "analysis_method": "LLM"
  },
  "nodes": [...],
  "relationships": [...],
  "method_flows": {...},
  "data_lineage_summary": {...}
}
```

### Key Features
- ✅ Intelligent data source selection
- ✅ Comprehensive deduplication
- ✅ Rich metadata generation
- ✅ Ready for graph database loading

---

## Agent 7: Neo4j Graph Builder

### Purpose
Loads the complete lineage data into Neo4j graph database with proper node labels and relationship types.

### Input
- `final_lineage.json` (normalized lineage)

### Processing
1. **Database Connection**:
   - Connects to Neo4j: `bolt://localhost:7687`
   - Authenticates with credentials
   - Clears existing data for fresh load

2. **Node Creation**:
   - **Proper capitalization**: `Application`, `Class`, `Method`, `Variable`
   - **Dynamic labels**: Uses actual node_type as Neo4j label
   - **Property mapping**: All node properties preserved

3. **Relationship Creation**:
   - **Specific relationship types**: `CONTAINS`, `DECLARES`, `FLOWS_TO`, `TRANSFORMS_TO`
   - **No generic labels**: Each relationship uses its actual type
   - **Property preservation**: Maintains all relationship metadata

### Output: Neo4j Database + `neo4j_load_summary.json`

#### Neo4j Graph Structure
```
Nodes (1,783):
├── Application (1)
├── Package (3)
├── File (15)
├── Class (8)
├── Interface (3)
├── Method (286)
├── Field (45)
├── Parameter (89)
├── Variable (1,247)
└── Operation (86)

Relationships (2,428):
├── CONTAINS (542)
├── HAS_PARAMETER (89)
├── HAS_FIELD (45)
├── DECLARES (1,247)
├── FLOWS_TO (425)
├── TRANSFORMS_TO (67)
└── PASS_TO (13)
```

#### `neo4j_load_summary.json`
```json
{
  "load_timestamp": "2024-01-15T10:30:00Z",
  "database_info": {
    "uri": "bolt://localhost:7687",
    "database": "data-lineage"
  },
  "load_results": {
    "nodes_created": 1783,
    "relationships_created": 2428,
    "load_time_seconds": 12.5
  },
  "node_types": {
    "Application": 1,
    "Variable": 1247,
    "Method": 286
  },
  "relationship_types": {
    "DECLARES": 1247,
    "CONTAINS": 542,
    "FLOWS_TO": 425
  }
}
```

### Key Features
- ✅ **Fixed relationship types** - No more generic "RELATIONSHIP" labels
- ✅ **Clean node names** - Proper capitalization, no duplicates
- ✅ **Complete lineage** - Application-to-variable traceability
- ✅ **Performance optimized** - Batch operations, efficient queries

---

## Complete Pipeline Results

### Final Neo4j Graph Contains:

#### **End-to-End Lineage Flow:**
```
Application → Package → File → Class → Method → Variable → Operation → Variable
```

#### **Variable Transformation Patterns:**
- `method → declares → variable` (1,247 relationships)
- `variable → flows_to → operation → transforms_to → variable` (425 + 67 relationships)
- `variable → pass_to → method → transforms_to → variable` (13 relationships)

#### **Queryable Relationships:**
- **Code Structure**: How classes contain methods, methods have parameters
- **Data Flow**: How variables flow through operations and transform
- **Cross-Method**: How variables pass between methods
- **Database Operations**: How variables connect to database columns

---

## Usage Instructions

### Prerequisites
```bash
# Install dependencies
pip install javalang google-generativeai neo4j python-dotenv

# Set up Neo4j database
# Start Neo4j server on bolt://localhost:7687
# Create database: data-lineage
# Set credentials: neo4j / Test@7889

# Set up Gemini API key in .env
echo "GEMINI_API_KEY=your_api_key_here" > .env
```

### Running Individual Agents
```bash
# Agent 1: Collect files
python agents/agent_01_collector.py

# Agent 2: AST parsing and chunking
python agents/agent_02_parser.py

# Agent 3: Framework detection
python agents/agent_03_frameworks.py

# Agent 4: Symbol tables
python agents/agent_04_metadata.py

# Agent 5: Variable transformations (LLM)
python agents/agent_05_transformations.py

# Agent 6: Normalization
python agents/agent_06_normalization.py

# Agent 7: Neo4j loading
python agents/agent_07_neo4j.py
```

### Running Complete Pipeline
```bash
python main.py
```

### Output Files Structure
```
output/
├── collection.json          # Agent 1: File collection
├── chunks.json             # Agent 2: Method chunks
├── parsing.json            # Agent 2: AST structure
├── variable_transformations.json  # Agent 5: LLM analysis
├── merged_lineage.json     # Agent 5: Complete lineage
├── final_lineage.json      # Agent 6: Normalized data
├── neo4j_load_summary.json # Agent 7: Load results
└── csv/
    ├── symbols.csv         # Agent 4: Method symbols
    ├── operations.csv      # Agent 4: Operations
    ├── variables.csv       # Agent 4: Variables
    └── lineage.csv         # Agent 4: Basic lineage
```

---

